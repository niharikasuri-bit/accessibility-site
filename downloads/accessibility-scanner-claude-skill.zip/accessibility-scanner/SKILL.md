---
name: accessibility-scanner
description: Check code for accessibility against WCAG 2.2 AA, ADA, GIGW 3.0 and SESMag. Reads source files (HTML, JSX / TSX, Vue, Svelte, Angular, templates, CSS) and reports each problem by file and line, by severity, with the WCAG criterion and a fix. Use when the user asks to check, review or audit code, components, a folder or a pull request for accessibility, WCAG, ADA, GIGW, screen reader or keyboard problems.
---

# DIGIT Accessibility Scanner: code check

Check the user's **code** for accessibility. Read the source and report problems by file and line, using the developer
checklist in `checklists.js` next to this file. Nothing needs installing.

This skill checks code only. To test pages as people use them (a live site, or the user's app running on
`localhost`), point the user to the **DIGIT Accessibility Scanner Chrome extension**: it runs real key presses, measures
contrast on screen, and shows what a screen reader announces.

## 1. Scope

- Check only the files or folders the user names. If they name none, ask which part of the codebase to check; for a
  pull request or "my changes", use the changed files (`git diff --name-only`).
- Look at markup and the code that renders it: HTML, JSX / TSX, Vue, Svelte, Angular templates, Razor, Jinja and
  other templates, and the CSS / styles they use. Skip tests, build output, `node_modules` and vendored code.
- If the project uses a component library, check how its components are used (for example a `Button` given only an
  icon) and, when the library's source is in the repo, the components themselves.

## 2. What to check

Work through `checklists.js`: the `developer` list (and the `design` list for colour and states). Each item gives the
standards it supports; WCAG 2.1 A/AA items count for ADA and GIGW 3.0 too. Report only WCAG 2.2 Level A and AA and these standards' own requirements: no AAA, no best practice. In code, these are the usual signs:

| Look for | Problem | WCAG |
|---|---|---|
| `<img>` / `Image` with no `alt`; `alt` that repeats the file name or says "image" | Image has no text alternative | 1.1.1 |
| A button or link whose only content is an icon or SVG, with no `aria-label` / visually hidden text | Control has no name | 4.1.2, 2.4.4 |
| `onClick` on a `div`, `span`, `li`, `img`, with no `role`, `tabIndex` and key handler | Works with a mouse only | 2.1.1, 4.1.2 |
| `<a>` with no `href` used as a button, or `href="#"` / `javascript:` | Not a real link or button | 2.1.1, 4.1.2 |
| `<input>`, `<select>`, `<textarea>` with no `<label for>`, wrapping `<label>`, `aria-label` or `aria-labelledby`; `placeholder` used as the only label | Field has no label | 1.3.1, 3.3.2 |
| Error text shown near a field but not joined with `aria-describedby`, and no `role="alert"` / live region | Errors not announced | 3.3.1, 4.1.3 |
| Email, phone, name and address fields without `type` / `autocomplete` | Input purpose missing | 1.3.5 |
| `tabIndex` / `tabindex` above 0 | Tab order changed | 2.4.3 |
| `outline: none` / `outline: 0` with no `:focus-visible` style in its place | Focus not visible | 2.4.7 |
| A modal or dialog with no focus move on open, no Escape close, no focus return | Keyboard trap or lost focus | 2.1.2, 2.4.3 |
| Menus, tabs, accordions, toggles without `aria-expanded` / `aria-selected` / `aria-pressed`, or with ARIA roles that don't match their keys | Wrong role or state | 4.1.2 |
| Toasts, "Saved", result counts that appear with no `aria-live` region | Status not announced | 4.1.3 |
| Headings chosen for size (`h4` after `h1`), more than one `h1`, text styled as a heading with no heading tag | Structure lost | 1.3.1, 2.4.6 |
| No `lang` on `<html>`; text in another language with no `lang` | Language not set | 3.1.1, 3.1.2 |
| Pages with no `<main>`, `<nav>`, `<header>`, `<footer>`; no skip link | No landmarks or skip link | 1.3.1, 2.4.1 |
| Layout tables; data tables with no `<th>` / `scope` | Table structure lost | 1.3.1 |
| Fixed `width` / `height` in px on text boxes with `overflow: hidden`; `user-scalable=no` or `maximum-scale=1` | Text cut off when zoomed or narrow | 1.4.4, 1.4.10 |
| Clickable areas under 24 × 24 px | Target too small | 2.5.8 |
| `onMouseDown` / `onPointerDown` doing the action; drag or swipe with no button alternative | Pointer problems | 2.5.2, 2.5.7 |
| Autoplaying video or audio, animations with no `prefers-reduced-motion` and no pause | Motion can't be stopped | 2.2.2, 1.4.2 |
| Colour pairs in the code (text colour on its background) | Check the contrast: 4.5:1 for text, 3:1 for large text and UI parts | 1.4.3, 1.4.11 |
| Meaning given only by colour (a red class on errors with no text or icon) | Colour alone | 1.4.1 |

Don't report a pattern that the code handles another way (for example a `div` with `role="button"`, `tabIndex={0}`
and an Enter / Space handler is fine). Read the surrounding code before reporting.

Report a problem only when the code you read shows it. When it depends on code you can't see (what an `onClick`
opens, whether an `id` exists in another file, how a parent uses a component), it isn't a problem yet: list it under
**To check** with the question to answer, for example "If `onMenu` opens a menu, does the button get `aria-expanded`?"
Code that meets the criterion is not a problem, even if it could break in some other use (a generic `id` that might
clash elsewhere, a label that might change): don't list it as a problem, a "consider" or a low-risk note.

## Findings pasted from the Chrome extension

If the user pastes findings from the DIGIT Accessibility Scanner extension (a title, the WCAG criterion, the element's
HTML, the page address and sometimes the step, like "Recorded step 3: Pressed “Assign”"), find where each element comes
from in the code and fix it there:

- Search for what the HTML shows that the code keeps: visible text, `id`, `aria-label`, `name`, `href`, `data-*`
  attributes, and readable class names. Generated class names (`css-1x2y3z`, `sc-abc123`) are not in the source: don't
  search for them.
- Use the page address and the step to narrow it down: the route, the screen or the component that renders that page,
  and the dialog or button the step names.
- Report `file:line` only when you are sure it is the source. When a match is uncertain, say so and list the likely
  files instead of guessing.
- Then report and offer fixes as in section 3.

## 3. Report back

1. The files you checked.
2. **Problems by severity** (Severe: blocks a task for keyboard or screen reader users; High; Medium; Low). For each:
   `file:line`, what is wrong, the WCAG criterion and the standards from `checklists.js`, and the fix as a short code
   change.
3. **To check**: what depends on code outside the files checked, one line each with the question to answer. Not
   counted as problems.
4. Offer to make the fixes. Change code only when the user agrees.
5. Say what reading code can't prove: real contrast on screen, focus order and traps as they happen, how a screen
   reader announces things, and layouts at 320px. For those, suggest testing the running pages with the Accessibility
   Scanner Chrome extension.

A code check can't prove conformance: "no problems found" means none of these signs were found in the files checked.

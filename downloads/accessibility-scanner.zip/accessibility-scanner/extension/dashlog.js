// Dashboard pages: the Scan log (every scan from the side panel, as a table), one scan's dashboard (its sections are
// filled by sidepanel.js from the same scan), and — in the admin's copy only — Scheduled emails and Sender details.
import { getScans, getScan, deleteScans, testsLabel, MAX_SCANS } from './lib/scanlog.js';
import { isAdminCopy } from './lib/admin.js';
import { TEST_ORDER } from './lib/runner.js';
import { capturedCount } from './lib/screens.js';

const $ = id => document.getElementById(id);
const ADMIN = await isAdminCopy();
if (ADMIN) document.querySelectorAll('.admin-only').forEach(el => { if (el.tagName === 'LI') el.hidden = false; });
else document.querySelectorAll('.admin-only').forEach(el => el.remove());

const SEV = [['critical', 'Severe'], ['serious', 'High'], ['moderate', 'Medium'], ['minor', 'Low']];
const TEST_NAMES = {
  scan: 'Page scan', ai: 'AI review', screenreader: 'Screen reader preview', spacing: 'Text spacing', keyboard: 'Keyboard walk',
  reflow: 'Reflow at 320px', mobile: 'Phone (touch, both orientations)', motion: 'Motion', explore: 'Use the app (Safe)', deep: 'Use the app (Deep)', context: 'Keyboard interactions',
  record: 'Recorded actions',
};
// The tests that actually ran on the scan's pages (AI review only when the AI really judged something); a recorded
// workflow covers several pages.
function testsRan(scan) {
  const pages = scan.session?.pages || [];
  return [...TEST_ORDER, 'record'].filter(t => pages.some(page => t in (page.results || {}) && (t !== 'ai' || page.aiRan)));
}
const filter = { q: '', tests: '', severe: '' };
const selected = new Set();
let scans = [];

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c != null && c !== false) el.append(c.nodeType ? c : String(c));
  return el;
}
const svg = (id, size = 16) => {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('width', size); s.setAttribute('height', size); s.setAttribute('aria-hidden', 'true');
  const u = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  u.setAttribute('href', `#${id}`);
  s.append(u);
  return s;
};
const when = t => new Date(t).toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const shortUrl = url => { try { const u = new URL(url); return u.host + u.pathname + u.hash; } catch { return url || ''; } };
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
// The pages a scan covered, as links to them: the first three, then how many more.
function pageLinks(s) {
  const urls = [...new Set((s.session?.pages || []).map(p => p.url).filter(Boolean))];
  if (!urls.length && s.url) urls.push(s.url);
  const links = urls.slice(0, 3).map(u => h('a', { class: 'pg-url', href: u, target: '_blank', rel: 'noopener' }, shortUrl(u)));
  return urls.length > 3 ? [...links, h('span', { class: 'pg-more' }, `+ ${plural(urls.length - 3, 'more page')}`)] : links;
}

let toastTimer;
function toast(text) {
  const t = $('toast');
  t.textContent = text; t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3500);
}

function download(name, html) {
  const a = h('a', { href: URL.createObjectURL(new Blob([html], { type: 'text/html' })), download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
const fileName = s => `${s.name.replace(/[\\/:*?"<>|]+/g, ' ').trim()} - accessibility report.html`;
async function downloadReport(scan) {
  const html = window.scannerReportHtml?.(scan.session);
  if (!html) return toast('The report could not be made. Reload the page and try again.');
  download(fileName(scan), html);
}

// ── Scan log ─────────────────────────────────────────────────────────────────

const testsKind = s => (['full', 'quick', 'record'].includes(s.tests) ? s.tests : 'some');
function shown() {
  const q = filter.q.trim().toLowerCase();
  return scans.filter(s => (!q || [s.name, s.title, s.url, s.product].some(x => (x || '').toLowerCase().includes(q)))
    && (!filter.tests || testsKind(s) === filter.tests)
    && (!filter.severe || (filter.severe === 'yes' ? s.counts?.critical > 0 : !s.counts?.critical)));
}

function sevCell(s) {
  const c = s.counts || {};
  return h('ul', { class: 'sev-pills', 'aria-label': SEV.map(([k, l]) => `${c[k] || 0} ${l}`).join(', ') },
    ...SEV.map(([k, l]) => h('li', { class: `sp ${k}${c[k] ? '' : ' zero'}`, title: l }, h('i', { 'aria-hidden': 'true' }), String(c[k] || 0))));
}
function adherenceCell(s) {
  if (s.adherence == null) return h('span', { class: 'muted' }, '–');
  return h('div', { class: 'adh' }, h('span', { class: 'adh-bar', 'aria-hidden': 'true' }, h('i', { style: `width:${s.adherence}%` })), h('b', {}, `${s.adherence}%`));
}

function renderRows() {
  const list = shown();
  for (const id of [...selected]) if (!scans.some(s => s.id === id)) selected.delete(id);
  $('log-count').textContent = list.length === scans.length ? plural(scans.length, 'scan') : `${list.length} of ${plural(scans.length, 'scan')}`;
  $('log-rows').replaceChildren(...list.map(s => h('tr', { class: selected.has(s.id) ? 'is-selected' : null },
    h('td', { class: 'c-check' }, h('input', {
      type: 'checkbox', 'aria-label': `Select ${s.name}`, checked: selected.has(s.id),
      onchange: e => { e.target.checked ? selected.add(s.id) : selected.delete(s.id); renderRows(); },
    })),
    h('td', { class: 'c-scan' }, h('a', { class: 'scan-link', href: `#/scan/${s.id}` }, s.name), h('span', { class: 'scan-date' }, when(s.at))),
    h('td', { class: 'c-page' }, ...pageLinks(s)),
    h('td', { class: 'c-tests', title: testsRan(s).map(t => TEST_NAMES[t] || t).join(', ') }, testsLabel(s.tests), s.mode ? h('span', { class: 'mode-pill' }, s.mode === 'deep' ? 'Deep' : 'Safe') : null),
    h('td', {}, sevCell(s)),
    h('td', {}, adherenceCell(s)),
    h('td', { class: 'c-report' }, h('button', { type: 'button', class: 'btn small', onclick: () => downloadReport(s) }, svg('i-down'), 'Download report', h('span', { class: 'visually-hidden' }, ` for ${s.name}`))),
  )));
  const allBox = $('log-all');
  const picked = list.filter(s => selected.has(s.id)).length;
  allBox.checked = !!list.length && picked === list.length;
  allBox.indeterminate = picked > 0 && picked < list.length;
  allBox.disabled = !list.length;
  $('log-download').disabled = !selected.size;
  $('log-delete').disabled = !selected.size;
  $('log-download').lastChild.textContent = selected.size ? `Download (${selected.size})` : 'Download';
  $('log-delete').lastChild.textContent = selected.size ? `Delete (${selected.size})` : 'Delete';

  const empty = $('log-empty');
  empty.hidden = !!list.length;
  document.querySelector('.log-table').hidden = !list.length;
  if (!list.length) {
    empty.replaceChildren(...(scans.length
      ? [h('b', {}, 'No scans match these filters.'), h('p', {}, h('button', { type: 'button', class: 'btn small', onclick: clearFilters }, 'Clear filters'))]
      : [h('b', {}, 'No scans yet'), h('p', {}, 'Open the scanner from the browser toolbar, tick the tests you want and press “Scan this page”. Each scan appears here with its report.')]));
  }
}

function renderLog() {
  renderRows();
}

function clearFilters() {
  Object.assign(filter, { q: '', tests: '', severe: '' });
  $('log-q').value = ''; $('log-tests').value = ''; $('log-severe').value = '';
  renderRows();
}

$('log-q').addEventListener('input', e => { filter.q = e.target.value; renderRows(); });
$('log-tests').addEventListener('change', e => { filter.tests = e.target.value; renderRows(); });
$('log-severe').addEventListener('change', e => { filter.severe = e.target.value; renderRows(); });
$('log-clear').addEventListener('click', clearFilters);
$('log-all').addEventListener('change', e => {
  for (const s of shown()) e.target.checked ? selected.add(s.id) : selected.delete(s.id);
  renderRows();
});
$('log-download').addEventListener('click', async () => {
  const list = scans.filter(s => selected.has(s.id));
  for (const s of list) { await downloadReport(s); await new Promise(r => setTimeout(r, 300)); }
  toast(`${plural(list.length, 'report')} downloaded.`);
});
$('log-delete').addEventListener('click', async () => {
  const n = selected.size;
  if (!confirm(`Delete ${plural(n, 'scan')}? ${n === 1 ? 'Its results' : 'Their results'} and ${n === 1 ? 'report' : 'reports'} can’t be brought back.`)) return;
  await deleteScans([...selected]);
  selected.clear();
  scans = await getScans();
  renderLog();
  toast(`${plural(n, 'scan')} deleted.`);
});

// ── One scan's header (its sections are filled by sidepanel.js) ─────────────

async function showScan(id) {
  const s = await getScan(id);
  if (!s) { location.replace('#/'); toast('That scan is no longer in the log (only the latest 25 are kept).'); return false; }
  document.title = `${s.name} – DIGIT Accessibility Scanner`;
  $('crumb-name').textContent = s.name;
  $('target-title').textContent = s.name;
  const secs = Math.round((s.durationMs || 0) / 1000);
  const ran = testsRan(s);
  const captured = capturedCount(s.session?.pages);
  $('tests-run-label').textContent = `${plural(ran.length, 'test')} run`;
  $('tests-run').replaceChildren(...ran.map(t => h('li', {}, TEST_NAMES[t] || t)));
  $('scan-meta').replaceChildren(...[s.title, `${plural(captured, 'page')} captured`, when(s.at), s.mode ? `${s.mode === 'deep' ? 'Deep' : 'Safe'} mode` : '', secs ? `Took ${secs < 60 ? `${secs} s` : `${Math.round(secs / 60)} min`}` : '']
    .filter(Boolean).map((t, i) => h('li', { class: i === 0 ? 'chip-page' : null }, t)));
  const c = s.counts || {};
  const stat = (value, label, tone = '') => h('li', { class: tone }, h('b', {}, value), h('span', {}, label));
  $('scan-stats').replaceChildren(
    stat(s.adherence == null ? '–' : `${s.adherence}%`, 'Average adherence'),
    stat(String(captured), captured === 1 ? 'Page captured' : 'Pages captured'),
    ...SEV.map(([k, l]) => stat(String(c[k] || 0), l, c[k] ? `sev-${k}` : '')),
  );
  $('target-url').textContent = s.url;
  $('target-url').href = s.url;
  $('status').textContent = '';
  return true;
}
$('btn-delete-scan').addEventListener('click', async () => {
  const id = location.hash.split('/')[2];
  const s = await getScan(id);
  if (!s || !confirm(`Delete ${s.name}? Its results and report can’t be brought back.`)) return;
  await deleteScans([id]);
  location.hash = '#/';
  toast(`${s.name} deleted.`);
});

// ── Routes: #/ (Scan log) · #/scan/<id> · #/schedules · #/sender (admin) ───

const PAGES = ['log', 'scan', 'schedules', 'sender'];
function frame(id, src) {
  const f = $(id);
  if (f && f.dataset.src !== src) { f.dataset.src = src; f.src = src; }
}
async function route() {
  const [, page = '', id] = (location.hash.replace(/^#/, '') || '/').split('/');
  let name = page === 'scan' && id ? 'scan' : PAGES.includes(page) && page !== 'scan' ? page : 'log';
  if ((name === 'schedules' || name === 'sender') && !ADMIN) name = 'log';
  if (name === 'scan' && !(await showScan(id))) return;
  for (const p of PAGES) { const el = $(`page-${p}`); if (el) el.hidden = p !== name; }
  const navOn = name === 'scan' ? 'log' : name;
  document.querySelectorAll('.main-nav a').forEach(a => (a.dataset.nav === navOn ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')));
  if (name === 'log') { document.title = 'Scan log – DIGIT Accessibility Scanner'; scans = await getScans(); renderLog(); }
  if (name === 'schedules') { document.title = 'Scheduled emails – DIGIT Accessibility Scanner'; frame('schedules-frame', chrome.runtime.getURL('projects.html?embed=1#/')); }
  if (name === 'sender') { document.title = 'Sender details – DIGIT Accessibility Scanner'; frame('sender-frame', chrome.runtime.getURL('projects.html?embed=1#/settings')); }
  $('dmain').scrollTop = 0;
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', route);
// A scan finished in the side panel while the log is open: show it straight away.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.scanLog && !$('page-log').hidden) { scans = changes.scanLog.newValue || []; renderLog(); }
});
$('log-count').title = `The latest ${MAX_SCANS} scans are kept`;
route();

import { STANDARDS, SEVERITY, labelOf, standardsFor, sessionIssues } from './lib/standards.js';
import { CRITERIA, PRINCIPLES, STATUS_LABELS, checklist } from './lib/wcag22.js';
import { buildReportHtml } from './lib/report.js';
import { createRunner, expandTests, FULL_TEST, CRAWL_TESTS, pageKey } from './lib/runner.js';
import { DEFAULT_SETTINGS, RESTRICTED, SESSION_VERSION, newSession, pageFor as sessionPageFor, withDefaults, withScheme, linkProblem, sortLinks } from './lib/defaults.js';
import { OWNERS, reviewIssues, forOwner, unsettledPart, elementKey } from './lib/review.js';
import { aiStatus, aiStart } from './lib/ai.js';
import { reviewTasksHtml, buildRunReport } from './lib/reporting.js';
import { acrHtml, issuesCsv } from './lib/acr.js';
import { dedupePageResults, dedupedPage } from './lib/dedupe.js';
import { STANDARD_LISTS, standardsChecklists } from './lib/standardsChecklist.js';
import { isAdminCopy } from './lib/admin.js';
import { addScan, getScan, updateScanSession } from './lib/scanlog.js';
import { screenOf, screensOf, MAIN_PAGE } from './lib/screens.js';
import { recordStep as recordAction, saveRecording, newRecordingId } from './lib/recorder.js';

const $ = id => document.getElementById(id);
// The same app runs in the side panel and as a full-page dashboard (the product opens in a background tab next to it).
const DASHBOARD = document.body.dataset.app === 'dashboard';
// Scheduled scans are the admin's: the public download (no admin page) shows no Scheduled scans tab or button.
const ADMIN_COPY = await isAdminCopy();
if (!ADMIN_COPY) for (const id of ['tab-schedules', 'view-schedules', 'btn-projects']) document.getElementById(id)?.remove();
// The Admin copy's header matches its icon and name: "N", DIGIT Accessibility Scanner Admin (the download keeps "A").
else {
  document.querySelectorAll('.logo').forEach(l => { l.textContent = 'N'; });
  document.querySelectorAll('.app-header h1, .brand b').forEach(b => { b.textContent = chrome.runtime.getManifest().name; });
}

const IMPACTS = ['critical', 'serious', 'moderate', 'minor'];
const MAX_SHOWN_NODES = 50;
const KIND_LABEL = { violation: null, unverified: 'Couldn’t verify', advice: 'Advice' };

const state = {
  tab: null,
  session: newSession(),
  recording: false,
  recordingId: null, // the recording being made: its pages go to the Scan log together
  busy: false,
  starting: false, // a run is being prepared (before busy)
  stop: false,
  runTabId: null,
  view: 'issues',
  filter: { standard: 'all', test: 'all', kind: 'all', page: 'all', screen: 'all', sc: null },
  targetTabId: Number(new URLSearchParams(location.search).get('tab')) || null, // dashboard: the product's tab
  selfTabId: null,
  settings: { ...DEFAULT_SETTINGS },
  open: new Set(),
  projects: [], // dashboard projects (with the scheduled ones)
  currentId: null,
  sessions: {}, // each project's results
};

// ── Status ───────────────────────────────────────────────────────────────────

function setStatus(text, tone = '') {
  const el = $('status');
  el.textContent = text;
  el.className = `status ${tone}`;
  if (tone === 'busy') progress.detail(text);
}

// Side panel: while a scan runs, the footer shows which test is running (n of N), a progress bar, the current step
// ("AI review 1 of 10: image description") and Stop, in place of Record workflow and the Scan button.
const progress = {
  ordered: [], index: 0, sub: 0,
  start(ordered) {
    if (!$('run-progress')) return;
    Object.assign(this, { ordered, index: 0, sub: 0 });
    $('rp-detail').textContent = '';
    this.draw();
  },
  step(name, phase, ordered) {
    if (!$('run-progress')) return;
    if (ordered) this.ordered = ordered;
    const i = this.ordered.indexOf(name);
    if (i < 0) return;
    this.index = phase === 'done' ? i + 1 : i;
    this.sub = 0;
    if (phase === 'start') $('rp-title').textContent = TEST_LABEL[name] || name;
    this.draw();
  },
  detail(text) {
    if (!$('run-progress')) return;
    $('rp-detail').textContent = text;
    const m = text.match(/(\d+)\s+of\s+(\d+)/); // "AI review 3 of 10: …" moves the bar within the current test
    this.sub = m ? Math.min(1, Number(m[1]) / Math.max(1, Number(m[2]))) : this.sub;
    this.draw();
  },
  draw() {
    const total = Math.max(1, this.ordered.length);
    const pct = Math.round(Math.min(1, (this.index + this.sub) / total) * 100);
    $('rp-fill').style.width = `${pct}%`;
    $('rp-bar').setAttribute('aria-valuenow', String(pct));
    $('rp-count').textContent = this.ordered.length > 1 ? ` · test ${Math.min(this.index + 1, total)} of ${total}` : '';
  },
};

function setBusy(busy) {
  state.busy = busy;
  // A run stays on the tab it started in, even if another tab is selected meanwhile; every run starts un-stopped.
  state.runTabId = busy ? state.tab?.id ?? null : null;
  if (busy) state.stop = false;
  else refreshTab(); // back to following the selected tab
  document.querySelectorAll('.actions .btn, .actions .choice').forEach(b => { b.disabled = busy; });
  live.show(busy);
  // Highlight / Go to page would act on the tab being tested.
  document.querySelectorAll('#issues .btn.tiny:not(.ghost), #review .btn.tiny:not(.ghost)').forEach(b => { b.disabled = busy; });
  $('btn-stop').disabled = false;
  $('btn-continue').disabled = false;
  $('btn-stop').hidden = !busy; // every run can be stopped (Deep mode can run for minutes)
  if (!busy) $('btn-continue').hidden = true;
  if ($('run-progress')) {
    $('run-progress').hidden = !busy;
    document.querySelector('.app-footer').classList.toggle('is-busy', busy);
    if (busy) { $('rp-title').textContent = 'Scanning this page'; $('btn-stop').lastChild.textContent = ' Stop '; }
  }
}

// ── Tab tracking ─────────────────────────────────────────────────────────────

async function refreshTab() {
  if (DASHBOARD) { state.tab = null; return; } // the dashboard shows logged scans; it has no product tab
  let tab;
  if (state.runTabId != null) tab = await chrome.tabs.get(state.runTabId).catch(() => null);
  else if (!DASHBOARD) tab = (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  else {
    tab = state.targetTabId != null ? await chrome.tabs.get(state.targetTabId).catch(() => null) : null;
    if (!tab) { // the product's tab was closed: the page open in the last window used instead
      const [last] = (await chrome.tabs.query({ active: true, lastFocusedWindow: true })).filter(t => t.id !== state.selfTabId && /^https?:/.test(t.url || ''));
      tab = last || null;
      state.targetTabId = tab?.id ?? null;
    }
  }
  state.tab = tab || null;
  // The recording follows this tab; the background records it while the panel is closed.
  if (!DASHBOARD && state.recording && tab) chrome.storage.local.set({ recordTabId: tab.id });
  $('target-title').textContent = tab?.title || 'No page selected';
  $('target-url').textContent = tab?.url || '';
  if (DASHBOARD) showProduct(tab);
  renderSite();
}

// Dashboard: the product's icon (or its first letter) next to its name.
function showProduct(tab) {
  const icon = $('target-icon');
  const letter = $('target-letter');
  if (!icon || !letter) return;
  const fav = /^(https?|data):/.test(tab?.favIconUrl || '') ? tab.favIconUrl : '';
  icon.hidden = !fav;
  letter.hidden = !!fav;
  if (fav && icon.getAttribute('src') !== fav) {
    icon.onerror = () => { icon.hidden = true; letter.hidden = false; }; // no icon on the site: its first letter
    icon.src = fav;
  }
  letter.textContent = (tab?.title || 'A').trim().charAt(0).toUpperCase() || 'A';
}

chrome.tabs.onActivated.addListener(async ({ tabId }) => {
  // The dashboard follows the website the user switches to (not itself or other extension pages).
  if (DASHBOARD && state.runTabId == null && tabId !== state.selfTabId) {
    const t = await chrome.tabs.get(tabId).catch(() => null);
    if (t && /^https?:/.test(t.url || '')) state.targetTabId = tabId;
  }
  refreshTab();
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (!state.tab || tabId !== state.tab.id) return;
  if (info.url || info.title || info.status) refreshTab();
  if (state.recording && (info.status === 'complete' || info.url)) scheduleAutoScan();
});

let autoTimer;
function scheduleAutoScan() {
  clearTimeout(autoTimer);
  autoTimer = setTimeout(() => (state.busy || state.starting ? scheduleAutoScan() : runTests(['scan'], { recordedIn: state.recordingId }).then(listen)), 1500);
}

// ── Live recording: every action and every screen ──────────────────────────────
// The page reports each action the person takes; lib/recorder.js tests it and scans any new screen. Actions the scanner
// itself takes during a test are ignored. With the panel closed, the background records instead.
const listen = () => (state.recording ? engine('startRecording').catch(() => {}) : null);
let screenQueue = Promise.resolve();
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type !== 'ns-recorded' || !state.recording || state.busy || state.starting || sender.tab?.id !== state.tab?.id) return false;
  screenQueue = screenQueue.then(() => recordStep(msg)).catch(() => {});
  return false;
});
async function recordStep(msg) {
  const { n, problems } = await recordAction(pageFor(state.tab), msg, {
    engine, recordingId: state.recordingId,
    onScreen: (i, step) => setStatus(`Recording · step ${i}: ${step.text} · scanning the new screen…`, 'busy'),
  });
  const found = problems ? ` · ${problems} problem${problems === 1 ? '' : 's'} with this step` : '';
  setStatus(`Recording · step ${n}: ${msg.step.text}${found}`, problems ? 'error' : 'ok');
  await save();
  render();
}

// The background changed the session (it recorded while the panel was closed): show what it added. Only its writes
// count: a change notice for one of the panel's own saves can arrive late, and taking that older copy back would lose
// the results saved after it.
chrome.storage.onChanged.addListener((changes, area) => {
  if (DASHBOARD || area !== 'local' || !changes.session?.newValue) return;
  const next = changes.session.newValue;
  if (next.by !== 'background' || next.rev === state.session.rev || next.v !== SESSION_VERSION || state.busy || state.starting) return;
  state.session = next;
  render();
});

const pageFor = tab => sessionPageFor(state.session, tab);

const runner = createRunner({
  get tab() { return state.tab; },
  get settings() { return state.settings; },
  get stopped() { return state.stop; },
  status: setStatus,
  refreshTab,
  pageFor,
  dropPage: p => { state.session.pages = state.session.pages.filter(x => x !== p); },
  waitForSignIn,
  async progress() { await save(); render(); },
  step: (name, phase, ordered) => { live.step(name, phase, ordered); progress.step(name, phase, ordered); },
  crawlProgress: p => live.crawl(p),
});
const { engine, runOnPage } = runner;

async function confirmDeep(ordered, url) {
  if (!ordered.includes('deep')) return true;
  const origin = new URL(url).origin;
  if (state.settings.acknowledged.includes(origin)) return true;
  const ok = confirm(`Deep mode will open menus, tabs, popups and "Add" forms on ${origin}, and test each form by submitting it empty and with wrong values. It never saves anything, and never clicks: ${state.settings.neverClick.join(', ')}.\n\nAn app that accepts an empty or wrong form could still save it, so a test or UAT site is safest. Continue?`);
  if (!ok) return false;
  state.settings.acknowledged.push(origin);
  await saveSettings();
  return true;
}

function canScan(tab) {
  if (tab?.url && !RESTRICTED.test(tab.url)) return true;
  setStatus("This page can't be scanned. Open a website in this tab first.", 'error');
  return false;
}

// Claims the panel before the first await, so a second click or the auto-scan can't start a run at the same time.
async function prepareRun(names) {
  if (state.busy || state.starting) return null;
  state.starting = true;
  try {
    await refreshTab();
    const tab = state.tab;
    if (!canScan(tab)) return null;
    const ordered = expandTests(names, state.settings);
    if (!(await confirmDeep(ordered, tab.url))) return null;
    state.tab = tab;
    setBusy(true);
    return ordered;
  } finally {
    state.starting = false;
  }
}

// `log`: the side panel's Scan button saves the finished scan in the Scan log (single tests don't; a recording's page
// scans, marked `recordedIn`, are saved together when the recording stops).
async function runTests(names, { log = null, recordedIn = null } = {}) {
  const ordered = await prepareRun(names);
  if (!ordered) return;
  const started = performance.now();
  const startedAt = Date.now();
  const page = pageFor(state.tab);
  live.start({ kind: 'page', ordered });
  progress.start(ordered);
  try {
    const extra = await runOnPage(page, ordered);
    if (!page.scannedAt) state.session.pages = state.session.pages.filter(p => p !== page); // stopped before any test ran
    else if (recordedIn) page.recordedIn = recordedIn;
    const secs = ((performance.now() - started) / 1000).toFixed(1);
    if (!state.stop) await timings.record(names.length === 1 && names[0] === 'scan' ? 'scan' : names === FULL_TEST ? 'full' : null, performance.now() - started);
    setStatus(`${state.stop ? 'Stopped' : 'Done'} in ${secs}s${extra ? ' · ' + extra : ''}.`, 'ok');
    if (log && page.scannedAt) {
      const entry = await addScan({ page, tests: log, mode: ordered.some(t => t === 'deep' || t === 'explore') ? state.settings.mode : null, durationMs: performance.now() - started, startedAt });
      setStatus(`${$('status').textContent} Saved as ${entry.name}.`, 'ok');
    }
  } catch (e) {
    if (!page.scannedAt) state.session.pages = state.session.pages.filter(p => p !== page);
    else page.note = String(e?.message || e);
    setStatus(e.message || String(e), 'error');
  } finally {
    await save();
    render();
    setBusy(false);
  }
}

let resumeCrawl = null;
function waitForSignIn(message = 'You were signed out. Sign in again in the product’s tab, open any page of the product, then press Continue.') {
  $('btn-continue').hidden = false;
  setStatus(message, 'error');
  return new Promise(resolve => {
    // Carries on by itself once the tab shows a signed-in page (Continue does the same at once).
    let checking = false;
    const watch = setInterval(async () => {
      if (state.stop) return resumeCrawl?.();
      if (checking) return; // one check at a time (each waits for the app to finish loading)
      checking = true;
      try { if (await signedIn()) resumeCrawl?.(); } finally { checking = false; }
    }, 2000);
    resumeCrawl = () => { clearInterval(watch); $('btn-continue').hidden = true; resumeCrawl = null; resolve(true); };
  });
}

// The tab is on a website page that is not a sign-in page (password or one-time code form).
async function signedIn() {
  const tab = state.tab?.id != null ? await chrome.tabs.get(state.tab.id).catch(() => null) : null;
  if (!tab || tab.status !== 'complete' || RESTRICTED.test(tab.url || '') || !/^https?:/.test(tab.url || '')) return false;
  if ((await engine('isSignIn').catch(() => true)) !== false) return false;
  // Signed in: let the app finish loading (it shows a loading screen first), then check it is still signed in.
  await new Promise(r => setTimeout(r, 2500));
  await engine('settle').catch(() => {});
  return (await engine('isSignIn').catch(() => true)) === false;
}

// ── Projects (dashboard) ─────────────────────────────────────────────────────
//
// A project: its name, the links to scan, whether the product has a login and how to sign in, its own results and
// (under Scheduled scans) its schedule. Projects are kept with the scheduled ones (storage "projects"), so the
// schedule runs the same links and login; each project's results are kept in "sessions".

const NEW_LOGIN = () => ({ fields: [{ type: 'text', label: '', value: '' }, { type: 'password', label: '', value: '' }], button: '', successUrl: '' });
const newId = () => `proj_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
// The schedule fields the scheduler and Scheduled scans expect; no schedule until one is set there.
const NEW_PROJECT = ({ name, urls, hasLogin, loginUrl, login }) => ({
  id: newId(), name, urls, url: urls[0] || loginUrl || '', hasLogin, loginUrl, login, scanMode: 'site',
  productOwner: { name: '', email: '' }, members: [], ccList: [], uxTeam: [], qaTeam: [],
  frequency: 'none', time: '09:00', timezone: 'Asia/Kolkata', daysOfWeek: ['mon'],
  monthlyType: 'day', monthlyDay: 15, monthlyNth: 'first', monthlyWeekday: 'mon',
  endRepeat: 'never', endRepeatDate: '', endRepeatAfter: 10,
  emailEnabled: true, slackEnabled: false, slackChannel: '', slackWebhook: '', status: 'active', createdAt: Date.now(),
});
const listedUrls = p => (p?.urls || []).map(u => withScheme(u.trim())).filter(Boolean);
const currentProject = () => state.projects.find(p => p.id === state.currentId) || null;

// Saves the dashboard's own fields of a project onto the latest stored copy, so a schedule saved meanwhile under
// Scheduled scans is kept.
const OWN_FIELDS = ['name', 'urls', 'url', 'hasLogin', 'loginUrl', 'login'];
let projectTimer;
function saveProject(p) {
  p.url = listedUrls(p)[0] || p.loginUrl || p.url || '';
  clearTimeout(projectTimer);
  projectTimer = setTimeout(async () => {
    const stored = (await chrome.storage.local.get('projects')).projects || [];
    const i = stored.findIndex(x => x.id === p.id);
    const own = Object.fromEntries(OWN_FIELDS.map(k => [k, p[k]]));
    if (i >= 0) stored[i] = { ...stored[i], ...own }; else stored.push(p);
    await chrome.storage.local.set({ projects: stored });
  }, 300);
}

// Switches the dashboard to a project: its links, login and results.
async function setProject(id) {
  if (DASHBOARD && state.currentId) state.sessions[state.currentId] = state.session;
  state.currentId = id;
  state.session = (id && state.sessions[id]?.v === SESSION_VERSION) ? state.sessions[id] : newSession();
  await chrome.storage.local.set({ currentProject: id });
  renderProjects();
  render();
  if (state.view === 'schedules') loadSchedules();
}

// The product in a background tab next to the dashboard: nothing pops up in front of the user (scans in a background
// tab give the same results, a little slower). Open the product (show) brings that tab to the front.
async function openProduct(url, { show = false } = {}) {
  const me = await chrome.tabs.getCurrent();
  const tab = await chrome.tabs.create({ url, active: show, windowId: me?.windowId, index: me ? me.index + 1 : undefined });
  state.targetTabId = tab.id;
  for (let t = 0; t < 40; t++) { // up to 10 s for the first page to start loading
    const tab = state.targetTabId != null ? await chrome.tabs.get(state.targetTabId).catch(() => null) : null;
    if (tab && /^https?:/.test(tab.url || tab.pendingUrl || '')) break;
    await new Promise(r => setTimeout(r, 250));
  }
  await refreshTab();
}
const productUrl = p => (p.hasLogin && p.loginUrl) || listedUrls(p)[0] || '';
const productOpen = () => /^https?:/.test(state.tab?.url || '');

async function scanListedPages() {
  const project = currentProject();
  if (!project) return setStatus('Create a project first: New project, at the top left.', 'error');
  const { urls, bad, repeats } = sortLinks(listedUrls(project));
  if (!urls.length) return setStatus(bad.length ? `No link can be opened: ${bad[0].url} is ${bad[0].error}.` : 'Add the pages to scan first: one address per line under "Pages to scan".', 'error');
  if (!productOpen()) await openProduct(productUrl(project));
  const ordered = await prepareRun(CRAWL_TESTS[state.settings.crawlTests] || CRAWL_TESTS.standard);
  if (!ordered) return;
  live.start({ kind: 'product', ordered });
  const started = performance.now();
  const failed = [...bad];
  const login = project.hasLogin ? project.login : null;
  let tested = 0;
  // Page tested this run → the link that opened it: a second link landing on the same address is not tested over it.
  const openedBy = new Map();
  runner.startSharing();
  try {
    for (const [i, url] of urls.entries()) {
      if (state.stop) break;
      live.crawl({ tested, queued: urls.length - i - 1, similar: 0, failed: failed.length, url });
      setStatus(`Page ${i + 1} of ${urls.length}: ${shortUrl(url)}`, 'busy');
      let page = null;
      try {
        await runner.openPage(url, login);
        if (state.stop) break;
        await refreshTab();
        const same = openedBy.get(state.tab.url);
        if (same) {
          failed.push({ url, error: `opened ${shortUrl(state.tab.url)}, the page already tested for ${shortUrl(same)}` });
          await save();
          render();
          continue;
        }
        page = pageFor(state.tab);
        const before = page.scannedAt;
        await runOnPage(page, ordered);
        if (page.scannedAt && page.scannedAt !== before) { tested++; openedBy.set(page.url, url); await runner.shareOnce(page); }
        else if (!before) state.session.pages = state.session.pages.filter(p => p !== page);
      } catch (e) {
        if (page?.scannedAt) { page.note = String(e?.message || e); openedBy.set(page.url, url); }
        else {
          if (page) state.session.pages = state.session.pages.filter(p => p !== page);
          failed.push({ url, error: String(e?.message || e).slice(0, 200) });
        }
      }
      await save();
      render();
    }
    // A finished run is the project's result: pages from earlier runs that aren't in it (links since removed or
    // cut short) are dropped. A stopped run keeps them, so stopping never loses results.
    if (!state.stop) state.session.pages = state.session.pages.filter(p => openedBy.has(p.url));
    state.session.failedPages = failed;
    const minutes = (performance.now() - started) / 60000;
    if (!state.stop && tested) await timings.record(`page-${state.settings.crawlTests}`, (minutes * 60000) / tested);
    const total = urls.length + bad.length;
    setStatus(`${state.stop ? 'Stopped' : 'Done'}: ${tested} of ${total} page${total === 1 ? '' : 's'} tested in ${minutes.toFixed(1)} min` +
      `${failed.length ? ` · ${failed.length} could not be tested (${failed.slice(0, 3).map(f => `${shortUrl(f.url)}: ${f.error}`).join('; ')})` : ''}` +
      `${repeats ? ` · ${repeats} link${repeats === 1 ? '' : 's'} listed twice, tested once` : ''}.`, failed.length ? 'error' : 'ok');
  } catch (e) {
    setStatus(e.message || String(e), 'error');
  } finally {
    runner.stopSharing();
    await save();
    render();
    setBusy(false);
  }
}

// Tries the project's sign-in on the login page open in the product's tab.
async function testSignIn() {
  const project = currentProject();
  if (!project?.hasLogin || !runner.loginReady(project.login)) return setStatus('Fill in at least one field (the text shown on the page) and the button text first.', 'error');
  if (!productOpen() && project.loginUrl) await openProduct(project.loginUrl);
  if (!(await prepareRun(['scan']))) return;
  try {
    if (!(await engine('isSignIn').catch(() => false))) return setStatus('Open the login page in the product’s tab first (sign out if needed).', 'error');
    setStatus('Signing in…', 'busy');
    const ok = await runner.signInWith(project.login);
    setStatus(ok ? 'Signed in: the product opened the page after sign-in.' : `Sign-in did not reach ${project.login.successUrl || 'a page after sign-in'} within 30 s. Check the field texts, values and button text.`, ok ? 'ok' : 'error');
  } catch (e) {
    setStatus(e.message || String(e), 'error');
  } finally {
    setBusy(false);
  }
}

const FIELD_TYPES = [['text', 'Text'], ['password', 'Password'], ['dropdown', 'Dropdown'], ['checkbox', 'Checkbox']];
const LABEL_HINT = { text: 'e.g. Username', password: 'e.g. Password', dropdown: 'e.g. City', checkbox: 'e.g. I agree' };

// One row per login field: its type, the text shown with it on the page, and what to put in it.
function loginRows(box, login, prefix, changed) {
  const redraw = () => loginRows(box, login, prefix, changed);
  box.replaceChildren(...login.fields.map((f, i) => {
    const n = i + 1;
    const type = h('select', { id: `${prefix}-type-${n}`, onchange: e => { f.type = e.target.value; f.value = f.type === 'checkbox' ? true : ''; changed(); redraw(); } },
      FIELD_TYPES.map(([v, t]) => { const o = h('option', { value: v }, t); o.selected = f.type === v; return o; }));
    const label = h('input', { id: `${prefix}-label-${n}`, type: 'text', value: f.label, placeholder: LABEL_HINT[f.type], oninput: e => { f.label = e.target.value; changed(); } });
    let value;
    if (f.type === 'checkbox') {
      const cb = h('input', { id: `${prefix}-value-${n}`, type: 'checkbox', onchange: e => { f.value = e.target.checked; changed(); } });
      cb.checked = f.value !== false;
      value = h('label', { class: 'opt login-tick' }, cb, ' Tick it');
    } else {
      value = h('label', { class: 'field' }, f.type === 'dropdown' ? 'Option to choose (as shown)' : 'What to enter',
        h('input', { id: `${prefix}-value-${n}`, type: f.type === 'password' ? 'password' : 'text', autocomplete: 'off', value: f.value || '', oninput: e => { f.value = e.target.value; changed(); } }));
    }
    return h('div', { class: 'login-row', role: 'group', 'aria-label': `Login field ${n}` },
      h('label', { class: 'field' }, 'Type', type),
      h('label', { class: 'field' }, 'Text shown on the page', label),
      value,
      h('button', { type: 'button', class: 'btn small ghost', 'aria-label': `Remove login field ${n}`, onclick: () => { login.fields.splice(i, 1); changed(); redraw(); } }, 'Remove'));
  }));
}

// The project picker, and the current project's links and sign-in (dashboard only).
function renderProjects() {
  const sel = $('project-select');
  if (!sel) return;
  sel.replaceChildren(...(state.projects.length ? state.projects.map(p => { const o = h('option', { value: p.id }, p.name); o.selected = p.id === state.currentId; return o; })
    : [h('option', { value: '' }, 'No projects yet')]));
  sel.disabled = !state.projects.length;
  renderSite();
}

function renderSite() {
  const box = $('login-rows');
  if (!box) return;
  const p = currentProject();
  $('project-name').hidden = !p;
  $('project-name').textContent = p ? `Project: ${p.name}` : '';
  for (const id of ['page-list', 'login-url', 'login-button', 'login-success', 'btn-add-field', 'btn-add-page', 'btn-open-product', 'btn-login-test', 'has-login-yes', 'has-login-no']) $(id).disabled = !p;
  $('site-name').textContent = p ? p.name : 'this project (create one first: New project)';
  timings.show();
  if (!p) { box.replaceChildren(); $('page-list').value = ''; $('login-setup').hidden = true; return; }
  if (document.activeElement !== $('page-list')) $('page-list').value = (p.urls || []).join('\n');
  $('has-login-yes').checked = !!p.hasLogin;
  $('has-login-no').checked = !p.hasLogin;
  $('login-setup').hidden = !p.hasLogin;
  p.login ||= NEW_LOGIN();
  $('login-url').value = p.loginUrl || '';
  $('login-button').value = p.login.button;
  $('login-success').value = p.login.successUrl;
  loginRows(box, p.login, 'lf', () => saveProject(p));
}

$('project-select')?.addEventListener('change', e => setProject(e.target.value));
$('page-list')?.addEventListener('input', e => {
  const p = currentProject();
  if (!p) return;
  p.urls = e.target.value.split('\n');
  saveProject(p);
  timings.show();
  const cut = sortLinks(p.urls).bad.filter(b => b.error.startsWith('cut short'));
  if (cut.length) setStatus(`${cut.length} link${cut.length === 1 ? ' is' : 's are'} cut short (… in the address), so they can't be scanned: copy the full addresses from the browser address bar.`, 'error');
});
for (const id of ['has-login-yes', 'has-login-no']) {
  $(id)?.addEventListener('change', () => { const p = currentProject(); if (!p) return; p.hasLogin = $('has-login-yes').checked; saveProject(p); renderSite(); });
}
$('login-url')?.addEventListener('input', e => { const p = currentProject(); if (p) { p.loginUrl = e.target.value.trim(); saveProject(p); } });
$('login-button')?.addEventListener('input', e => { const p = currentProject(); if (p) { p.login.button = e.target.value; saveProject(p); } });
$('login-success')?.addEventListener('input', e => { const p = currentProject(); if (p) { p.login.successUrl = e.target.value.trim(); saveProject(p); } });
$('btn-add-field')?.addEventListener('click', () => {
  const p = currentProject();
  if (!p) return;
  p.login.fields.push({ type: 'text', label: '', value: '' });
  saveProject(p);
  renderSite();
  $(`lf-label-${p.login.fields.length}`)?.focus();
});
// Adds the page open in the product's tab to the project's links.
$('btn-add-page')?.addEventListener('click', () => {
  const p = currentProject();
  if (!p) return;
  if (!productOpen()) return setStatus('Open the product first.', 'error');
  const urls = listedUrls(p);
  if (!urls.includes(state.tab.url)) p.urls = [...urls, state.tab.url];
  saveProject(p);
  renderSite();
  setStatus(`Added ${shortUrl(state.tab.url)} to the pages to scan.`, 'ok');
});
$('btn-open-product')?.addEventListener('click', async () => {
  const p = currentProject();
  if (!p || !productUrl(p)) return setStatus('Add the product link first.', 'error');
  await openProduct(productUrl(p), { show: true });
});
$('btn-login-test')?.addEventListener('click', testSignIn);

// ── New project ──
const npLogin = { value: NEW_LOGIN() };
function npError(id, text) {
  const input = $(id);
  const err = $(`${id}-error`);
  input.setAttribute('aria-invalid', text ? 'true' : 'false');
  err.hidden = !text;
  err.textContent = text || '';
  return !text;
}
function openNewProject() {
  const dlg = $('new-project');
  if (!dlg) return;
  $('np-form').reset();
  npLogin.value = NEW_LOGIN();
  for (const id of ['np-name', 'np-login-url', 'np-links']) npError(id, '');
  $('np-login').hidden = true;
  loginRows($('np-login-rows'), npLogin.value, 'np', () => {});
  dlg.showModal();
  $('np-name').focus();
}
$('btn-new-project')?.addEventListener('click', openNewProject);
$('np-cancel')?.addEventListener('click', () => $('new-project').close());
for (const id of ['np-login-yes', 'np-login-no']) $(id)?.addEventListener('change', () => { $('np-login').hidden = !$('np-login-yes').checked; });
$('np-add-field')?.addEventListener('click', () => {
  npLogin.value.fields.push({ type: 'text', label: '', value: '' });
  loginRows($('np-login-rows'), npLogin.value, 'np', () => {});
  $(`np-label-${npLogin.value.fields.length}`)?.focus();
});
$('np-form')?.addEventListener('submit', async e => {
  e.preventDefault();
  const name = $('np-name').value.trim();
  const hasLogin = $('np-login-yes').checked;
  const loginUrl = withScheme($('np-login-url').value.trim());
  const urls = $('np-links').value.split('\n').map(u => withScheme(u.trim())).filter(Boolean);
  const web = u => !linkProblem(u);
  const badLink = urls.find(u => !web(u));
  const ok = [
    npError('np-name', name ? '' : 'Enter a project name, for example HCM Console'),
    npError('np-login-url', !hasLogin || web(loginUrl) ? '' : 'Enter the login page link, starting with https://'),
    npError('np-links', !urls.length ? 'Add at least one link: the product link' : badLink ? `This link is ${linkProblem(badLink)}: ${badLink}` : ''),
  ];
  if (!ok.every(Boolean)) { $(['np-name', 'np-login-url', 'np-links'][ok.indexOf(false)]).focus(); return; }
  const login = npLogin.value;
  login.button = $('np-button').value.trim();
  login.successUrl = $('np-success').value.trim();
  const p = NEW_PROJECT({ name, urls, hasLogin, loginUrl: hasLogin ? loginUrl : '', login });
  state.projects.push(p);
  const stored = (await chrome.storage.local.get('projects')).projects || [];
  await chrome.storage.local.set({ projects: [...stored, p] });
  $('new-project').close();
  await setProject(p.id);
  setView('home');
  setStatus(`Project “${name}” created. Its product is open in a tab next to this one: press Scan listed pages${ADMIN_COPY ? ', or schedule scans under Scheduled scans' : ''}.`, 'ok');
  await openProduct(productUrl(p));
});

// A schedule saved under Scheduled scans (or a project added there) updates the dashboard's list.
chrome.storage.onChanged.addListener((changes, area) => {
  if (!DASHBOARD || !$('project-select') || area !== 'local' || !changes.projects) return; // the dashboard no longer has a project picker
  const stored = changes.projects.newValue || [];
  const mine = new Map(state.projects.map(p => [p.id, p]));
  // The dashboard's own fields of the project being edited here stay as typed.
  state.projects = stored.map(p => (p.id === state.currentId && mine.has(p.id) ? { ...p, ...Object.fromEntries(OWN_FIELDS.map(k => [k, mine.get(p.id)[k]])) } : p));
  if (state.currentId && !state.projects.some(p => p.id === state.currentId)) setProject(state.projects[0]?.id ?? null);
  else renderProjects();
});

// ── Grouping & filters ───────────────────────────────────────────────────────

function allIssues(session = state.session) {
  const out = [];
  for (const p of session.pages) {
    for (const [test, list] of Object.entries(dedupePageResults(p.results))) for (const i of list) { const open = unsettledPart(p, i); if (open) out.push({ ...open, pageId: p.id, test }); }
    for (const i of reviewIssues(p)) out.push({ ...i, pageId: p.id, test: 'review' });
  }
  for (const i of sessionIssues(session.pages)) out.push({ ...i, pageId: null, test: 'scan' });
  return out;
}

// The downloadable report for a session (the side panel's, or a logged scan's on the dashboard).
function reportHtmlFor(session) {
  const issues = allIssues(session);
  return buildReportHtml({ pages: session.pages, groups: groupIssues(issues), criteria: checklist(session.pages, issues), standards: standardsChecklists(session.pages, issues), generatedAt: Date.now(), failedPages: session.failedPages || [] });
}
if (DASHBOARD) window.scannerReportHtml = reportHtmlFor; // the Scan log's Download report buttons

function groupIssues(issues) {
  const groups = new Map();
  for (const i of issues) {
    const key = `${i.kind}:${i.ruleId}`;
    let g = groups.get(key);
    if (!g) groups.set(key, g = { key, meta: i, title: i.title, nodes: [], pageIds: new Set(), tests: new Set() });
    g.pageIds.add(i.pageId);
    if (i.test) g.tests.add(i.test);
    for (const n of i.nodes) {
      const pageId = n.pageId ?? i.pageId;
      if (!g.nodes.some(m => m.target && m.target === n.target && m.pageId === pageId)) g.nodes.push({ ...n, pageId, state: n.state || i.state });
    }
  }
  const rank = g => ({ violation: 0, unverified: 10, advice: 20 }[g.meta.kind] ?? 10) + IMPACTS.indexOf(g.meta.impact);
  return [...groups.values()].sort((a, b) => rank(a) - rank(b) || b.nodes.length - a.nodes.length);
}

function filtered({ ignoreStandard = false, ignoreKind = false, ignoreTest = false, ignoreScreen = false } = {}) {
  const f = state.filter;
  return allIssues().filter(i =>
    (f.page === 'all' || i.pageId === f.page || i.pageId === null) &&
    (ignoreTest || f.test === 'all' || i.test === f.test) &&
    (ignoreKind || f.kind === 'all' || i.kind === f.kind) &&
    (ignoreStandard || f.standard === 'all' || standardsFor(i).includes(f.standard)) &&
    (!f.sc || i.wcag?.includes(f.sc)))
    .flatMap(i => (ignoreScreen || f.screen === 'all' ? [i] : inScreen(i, f.screen)));
}

// An issue narrowed to one captured page: only its elements found there (page-wide findings belong to the main page).
function inScreen(i, screen) {
  if (!i.nodes?.length) return screen === MAIN_PAGE ? [i] : [];
  const nodes = i.nodes.filter(n => screenOf(n.state || i.state) === screen);
  return nodes.length ? [{ ...i, nodes }] : [];
}

// Dashboard: the Page dropdown lists each captured page that has issues, with its issue count (hidden with only one).
function renderScreenChips() {
  const sel = $('f-screen');
  if (!sel) return;
  const pages = screensOf(state.session.pages);
  if (state.filter.screen !== 'all' && !pages.includes(state.filter.screen)) state.filter.screen = 'all';
  const count = s => groupIssues(filtered({ ignoreScreen: true }).flatMap(i => (s === 'all' ? [i] : inScreen(i, s)))).length;
  const withIssues = pages.filter(s => s === state.filter.screen || count(s) > 0); // pages with no issues: nothing to filter to
  sel.replaceChildren(h('option', { value: 'all' }, `All pages · ${count('all')}`), ...withIssues.map(s => h('option', { value: s }, `${s} · ${count(s)}`)));
  sel.value = state.filter.screen;
  sel.closest('label').hidden = withIssues.length < 2;
}
$('f-screen')?.addEventListener('change', e => { state.filter.screen = e.target.value; render(); });

function currentChecklist() {
  const pages = state.filter.page === 'all' ? state.session.pages : state.session.pages.filter(p => p.id === state.filter.page);
  return checklist(pages, filtered({ ignoreStandard: true, ignoreKind: true, ignoreTest: true }));
}

// ── Rendering ────────────────────────────────────────────────────────────────

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c != null && c !== false && c !== '') el.append(c instanceof Node ? c : String(c));
  return el;
}

const pageById = id => state.session.pages.find(p => p.id === id);
const shortUrl = url => { try { const u = new URL(url); return u.host + u.pathname + u.hash; } catch { return url; } };

function render() {
  const ic = $('issues-count');
  if (ic) { const n = groupIssues(allIssues()).length; ic.textContent = state.session.pages.length ? ` · ${n}` : ''; }
  renderSkipped();
  renderTestData();
  renderPageFilter();
  renderSummary();
  renderIssues();
  renderChecklist();
  renderReview();
  renderScreenReader();
}

function renderScreenReader() {
  const pages = state.session.pages.filter(p => p.screenReader);
  const box = $('sr');
  const sel = $('f-sr-page');
  sel.closest('.filters').hidden = !pages.length; // nothing to choose from: no dropdowns
  if (!pages.length) {
    sel.replaceChildren();
    $('sr-sum').textContent = '';
    box.replaceChildren(h('p', { class: 'checklist-sum' }, DASHBOARD
      ? 'This scan didn’t include “Screen reader preview”. Tick it in the side panel and scan the page again to see what a screen reader announces.'
      : 'Tick “Screen reader preview” and press Scan this page to see what a screen reader announces.'));
    return;
  }
  const page = pages.find(p => p.id === state.srPage) || pages.find(p => state.tab && p.url === state.tab.url) || pages[0];
  sel.replaceChildren(...pages.map(p => h('option', { value: p.id }, p.title ? `${p.title} — ${shortUrl(p.url)}` : shortUrl(p.url))));
  sel.value = page.id;
  const kind = $('f-sr-kind').value;
  const { lines, stats } = page.screenReader;
  const shown = lines.filter(l => kind === 'all' || (kind === 'problems' ? l.unnamed : l.kind === kind));
  $('sr-sum').textContent = `${stats.landmarks} landmarks · ${stats.headings} headings · ${stats.links} links · ${stats.buttons} buttons · ${stats.fields} form fields · ${stats.images} images` +
    `${stats.unnamed ? ` · ${stats.unnamed} with no name` : ''}${stats.truncated ? ' · first 600 announcements shown' : ''}`;
  box.replaceChildren(shown.length
    ? h('ol', { class: 'sr-lines' }, ...shown.map(l => h('li', { class: `sr-${l.kind}${l.unnamed ? ' sr-unnamed' : ''}` }, l.text)))
    : h('p', { class: 'checklist-sum' }, 'Nothing of this kind on the page.'));
}

function renderPageFilter() {
  const sel = $('f-page');
  const pages = state.session.pages;
  if (state.filter.page !== 'all' && !pageById(state.filter.page)) state.filter.page = 'all';
  sel.replaceChildren(
    h('option', { value: 'all' }, `All pages (${pages.length})`),
    ...pages.map(p => h('option', { value: p.id }, p.title ? `${p.title} — ${shortUrl(p.url)}` : shortUrl(p.url))),
  );
  sel.value = state.filter.page;
}

function renderSummary() {
  renderScreenChips();
  const groups = groupIssues(filtered({ ignoreStandard: true, ignoreKind: true }));
  renderTestChips();
  renderOverview();
  const v = groups.filter(g => g.meta.kind === 'violation');
  // Issue types by severity, then how many elements they affect (so fixing 50 of 51 still shows).
  const elements = v.reduce((s, g) => s + g.nodes.length, 0);
  $('counts').replaceChildren(
    ...IMPACTS.map(imp => h('li', { class: imp }, h('b', {}, String(v.filter(g => g.meta.impact === imp).length)), SEVERITY[imp])),
    h('li', { class: 'elements' }, h('b', {}, String(elements)), 'Elements'),
  );
  const crit = currentChecklist();
  const n = s => crit.filter(c => c.status === s).length;
  $('crit-line').replaceChildren(...(state.session.pages.length
    ? [h('b', {}, `${n('fail')} of ${CRITERIA.length}`), ' WCAG 2.2 AA criteria fail · ', h('b', {}, String(n('pass') + n('reviewed'))), ' passed · ', h('b', {}, String(n('judgement') + n('unverified'))), ' need review']
    : []));
  const chip = (key, label, count) => h('button', {
    type: 'button', class: 'std-chip', 'aria-pressed': String(state.filter.standard === key),
    onclick: () => { state.filter.standard = key; $('f-standard').value = key; render(); },
  }, `${label} · ${count}`);
  const active = $('active-filters');
  if (active) {
    const shown = groupIssues(filtered()).length;
    const all = groupIssues(allIssues()).length;
    const tags = [];
    if (state.filter.standard !== 'all') tags.push([labelOf(state.filter.standard), () => { state.filter.standard = 'all'; $('f-standard').value = 'all'; }]);
    if (state.filter.test !== 'all') tags.push([TEST_LABEL[state.filter.test] || state.filter.test, () => { state.filter.test = 'all'; }]);
    active.replaceChildren(...(tags.length ? [`Showing ${shown} of ${all}: `, ...tags.map(([label, clear]) => h('span', { class: 'tag' }, label,
      h('button', { type: 'button', 'aria-label': `Remove filter ${label}`, onclick: () => { clear(); render(); } }, '×')))] : []));
  }
  $('std-counts').replaceChildren(
    chip('all', 'All', groups.length),
    ...STANDARDS.map(s => chip(s.key, s.label, groups.filter(g => standardsFor(g.meta).includes(s.key)).length)),
  );
}

function renderIssues() {
  const box = $('issues');
  const sc = state.filter.sc;
  const scBox = $('sc-filter');
  scBox.hidden = !sc;
  if (sc) {
    const c = CRITERIA.find(x => x.id === sc);
    scBox.replaceChildren(h('span', {}, `Showing ${sc} ${c?.name ?? ''}`),
      h('button', { type: 'button', class: 'btn tiny', onclick: () => { state.filter.sc = null; render(); } }, 'Show all'));
  }
  const groups = groupIssues(filtered());
  if (!state.session.pages.length) {
    box.replaceChildren(h('p', { class: 'empty' }, 'Open a page and press "Scan page", or switch on "Record workflow" and use the site normally.'));
    return;
  }
  if (!groups.length) {
    box.replaceChildren(h('p', { class: 'empty' }, 'No issues match these filters.'));
    return;
  }
  box.replaceChildren(...groups.map(renderGroup));
}

function renderGroup(g) {
  const i = g.meta;
  const count = g.nodes.length || g.pageIds.size;
  const sev = KIND_LABEL[i.kind] || SEVERITY[i.impact] || i.impact;
  const where = i.wcag.length ? i.wcag.join(', ') : standardsFor(i).map(labelOf).join(', ');
  const det = h('details', { class: 'issue', open: state.open.has(g.key) },
    DASHBOARD
      ? h('summary', {},
        h('span', { class: `pill ${i.kind === 'violation' ? i.impact : i.kind}` }, sev),
        h('span', { class: 'issue-title' }, g.title),
        h('span', { class: 'count' }, h('span', { class: 'visually-hidden' }, 'Occurrences: '), String(count)))
      : h('summary', { class: 'row-sum' },
        h('span', { class: `dot ${i.kind === 'violation' ? i.impact : i.kind}`, 'aria-hidden': 'true' }),
        h('span', { class: 'row-text' },
          h('span', { class: 'issue-title' }, h('span', { class: 'visually-hidden' }, `${sev}: `), g.title),
          h('span', { class: 'row-meta' }, `${where ? where + ' · ' : ''}${count} element${count === 1 ? '' : 's'} affected`)),
        h('span', { class: 'chev', 'aria-hidden': 'true' })),
    h('div', { class: 'issue-body' },
      h('div', { class: 'chips' },
        ...i.wcag.map(sc => h('span', { class: 'chip sc' }, `${sc}${i.level ? ' ' + i.level : ''}`)),
        ...standardsFor(i).map(k => h('span', { class: 'chip' }, labelOf(k)))),
      h('p', {}, i.description),
      i.sesmag?.length ? h('p', { class: 'facets' }, `SESMag facets: ${i.sesmag.join(', ')}`) : null,
      i.helpUrl ? h('p', {}, h('a', { href: i.helpUrl, target: '_blank', rel: 'noopener' }, 'How to fix (opens in a new tab)')) : null,
      g.nodes.length && !DASHBOARD ? h('p', { class: 'nodes-h' }, `${g.nodes.length} element${g.nodes.length === 1 ? '' : 's'} affected`) : null,
      g.nodes.length
        ? h('ol', { class: 'nodes' }, ...g.nodes.slice(0, MAX_SHOWN_NODES).map(renderNode))
        : h('p', { class: 'facets' }, `Pages: ${[...g.pageIds].map(id => pageById(id)?.title || 'Whole session').join(', ')}`),
      g.nodes.length > MAX_SHOWN_NODES ? h('p', { class: 'more' }, `Showing ${MAX_SHOWN_NODES} of ${g.nodes.length}. Download the report for the full list.`) : null));
  det.addEventListener('toggle', () => (det.open ? state.open.add(g.key) : state.open.delete(g.key)));
  return det;
}

function renderNode(n) {
  const page = pageById(n.pageId);
  // Same page even when a test left an in-page #anchor in the address (pageKey keeps #/ routes apart).
  const here = page && state.tab?.url && pageKey(page.url) === pageKey(state.tab.url);
  return h('li', { class: 'node' },
    h('p', { class: 'node-where' }, `${page ? page.title || shortUrl(page.url) : 'Whole session'}${n.state && n.state !== 'Page load' ? ' · ' + n.state : ''}`),
    n.html ? h('code', { class: 'snippet' }, n.html) : null,
    n.summary ? h('p', { class: 'node-summary' }, n.summary) : null,
    n.fix ? h('div', { class: 'node-fix' },
      h('p', { class: 'fix-how' }, h('strong', {}, n.fix.by === 'ai' ? 'Suggested fix (AI): ' : 'Suggested fix: '), n.fix.how),
      n.fix.code ? h('code', { class: 'snippet fix-code' }, n.fix.code) : null) : null,
    h('div', { class: 'node-actions' },
      n.target && here ? h('button', { type: 'button', class: 'btn tiny', disabled: state.busy, onclick: () => !state.busy && locate(n) }, 'Highlight on page') : null,
      page && !here && DASHBOARD ? h('button', { type: 'button', class: 'btn tiny', onclick: () => chrome.tabs.create({ url: page.url }) }, 'Open page') : null,
      page && !here && !DASHBOARD ? h('button', { type: 'button', class: 'btn tiny', disabled: state.busy, onclick: () => !state.busy && chrome.tabs.update(state.tab.id, { url: page.url }) }, 'Go to page') : null,
      n.fix?.code ? h('button', { type: 'button', class: 'btn tiny ghost', onclick: () => copy(n.fix.code) }, 'Copy fix') : null,
      n.target ? h('button', { type: 'button', class: 'btn tiny ghost', onclick: () => copy(n.target) }, 'Copy selector') : null));
}

// The standard shown in the checklist (dashboard): WCAG 2.2 AA, or ADA, GIGW 3.0, SESMag with their own items.
let checklistStd = 'wcag22';

function renderChecklist() {
  const picker = $('checklist-std');
  if (picker) {
    picker.replaceChildren(...STANDARD_LISTS.map(s => h('button', {
      type: 'button', class: 'std-chip', 'aria-pressed': String(s.key === checklistStd),
      onclick: () => { checklistStd = s.key; renderChecklist(); },
    }, s.label)));
  }
  if (picker && checklistStd !== 'wcag22') return renderStandardList();
  const crit = currentChecklist();
  const tested = state.session.pages.length > 0;
  $('checklist-sum').textContent = tested
    ? 'Each Level A and AA criterion, decided from the tests that ran. Run the full test for the most coverage. Select a failing criterion to see its issues.'
    : 'Scan a page to fill in the checklist.';
  $('checklist').replaceChildren(...Object.entries(PRINCIPLES).map(([num, name]) => h('div', {},
    h('h3', { class: 'principle-h' }, `${num}. ${name}`),
    h('ul', { class: 'crit' }, ...crit.filter(c => c.id.startsWith(num + '.')).map(c => h('li', {},
      c.issueCount
        ? h('button', { type: 'button', class: 'crit-name', onclick: () => showCriterion(c.id) }, h('span', { class: 'crit-id' }, c.id), c.name, h('span', { class: 'lvl' }, c.level))
        : h('span', { class: 'crit-name' }, h('span', { class: 'crit-id' }, c.id), c.name, h('span', { class: 'lvl' }, c.level)),
      tested ? h('span', { class: `st ${c.status}` }, STATUS_LABELS[c.status]) : null))))));
}

// One standard's list: its own requirements first, then the WCAG criteria it takes in (by principle).
function renderStandardList() {
  const pages = state.filter.page === 'all' ? state.session.pages : state.session.pages.filter(p => p.id === state.filter.page);
  const list = standardsChecklists(pages, filtered({ ignoreStandard: true, ignoreKind: true, ignoreTest: true }))[checklistStd];
  const tested = state.session.pages.length > 0;
  const count = s => list.items.filter(i => i.status === s).length;
  $('checklist-sum').textContent = tested
    ? `${list.note} ${count('fail')} fail · ${count('pass') + count('reviewed')} with no failures found · ${count('judgement') + count('unverified')} need review${count('na') ? ` · ${count('na')} not applicable` : ''}.`
    : `${list.note} Scan a page to fill in the list.`;
  const row = c => h('li', {},
    c.issueCount && /^\d/.test(c.id)
      ? h('button', { type: 'button', class: 'crit-name', onclick: () => showCriterion(c.id) }, h('span', { class: 'crit-id' }, c.id), c.name, c.level ? h('span', { class: 'lvl' }, c.level) : null)
      : h('span', { class: 'crit-name' }, h('span', { class: 'crit-id' }, c.id), c.name, c.level ? h('span', { class: 'lvl' }, c.level) : null),
    tested ? h('span', { class: `st ${c.status}` }, STATUS_LABELS[c.status]) : null);
  const ownItems = list.items.filter(i => !/^\d/.test(i.id));
  const wcagItems = list.items.filter(i => /^\d/.test(i.id));
  $('checklist').replaceChildren(
    ownItems.length ? h('div', {}, h('h3', { class: 'principle-h' }, `${list.label} requirements`), h('ul', { class: 'crit' }, ...ownItems.map(row))) : '',
    ...Object.entries(PRINCIPLES).map(([num, name]) => {
      const items = wcagItems.filter(c => c.id.startsWith(num + '.'));
      return items.length ? h('div', {}, h('h3', { class: 'principle-h' }, `${num}. ${name} (WCAG 2.1)`), h('ul', { class: 'crit' }, ...items.map(row))) : '';
    }));
}

// ── Review tasks (Design / Engineering) ───────────────────────────────────────────────────

const reviewFilter = { owner: 'all', status: 'all' };

function renderReview() {
  const box = $('review');
  const pages = state.session.pages.filter(p => p.review?.length);
  const all = pages.flatMap(p => forOwner(p.review, reviewFilter.owner));
  const done = all.filter(t => t.status !== 'todo').length;
  const badge = $('nav-review-count');
  if (badge) {
    const todo = state.session.pages.flatMap(p => p.review ?? []).filter(t => t.status === 'todo').length;
    badge.hidden = !todo;
    badge.textContent = String(todo);
  }
  $('review-count').replaceChildren(...(all.length
    ? [h('b', {}, String(all.length - done)), ' to do · ', h('b', {}, String(all.filter(t => t.status === 'fail').length)), ' failed · ', h('b', {}, String(all.filter(t => t.status === 'pass' || t.status === 'na').length)), ' passed or not applicable']
    : []));
  if (!pages.length) {
    box.replaceChildren(h('p', { class: 'empty' }, 'Scan a page to get review tasks for the Design and Engineering teams.'));
    return;
  }
  const blocks = [];
  for (const p of pages) {
    const tasks = forOwner(p.review, reviewFilter.owner).filter(t => reviewFilter.status === 'all' || (reviewFilter.status === 'todo' ? t.status === 'todo' : t.status !== 'todo'));
    if (!tasks.length) continue;
    blocks.push(h('h3', { class: 'page-h' }, p.title || shortUrl(p.url)));
    blocks.push(...tasks.map(t => renderTask(p, t)));
  }
  box.replaceChildren(...(blocks.length ? blocks : [h('p', { class: 'empty' }, 'No tasks match these filters.')]));
}

function renderTask(page, t) {
  const here = state.tab?.url && pageKey(page.url) === pageKey(state.tab.url);
  const decide = async status => {
    t.status = t.status === status ? 'todo' : status;
    t.decidedAt = t.status === 'todo' ? null : new Date().toISOString();
    t.decidedTargets = t.status === 'todo' ? null : t.evidence.map(elementKey); // the decision covers these elements
    await save();
    render();
  };
  const choice = (status, label) => h('button', {
    type: 'button', class: `btn tiny d-${status}`, 'aria-pressed': String(t.status === status), onclick: () => decide(status),
  }, label);
  return h('div', { class: 'task' },
    h('span', { class: 'owner' }, OWNERS[t.owner]), ' ', ...t.sc.map(sc => h('span', { class: 'chip sc' }, sc)),
    h('h4', {}, t.title),
    h('p', { class: 'how' }, t.how),
    t.evidence.length ? h('ul', { class: 'evidence' }, ...t.evidence.slice(0, 8).map(n => h('li', {},
      h('code', {}, (n.html || n.target || '').slice(0, 90)),
      n.target && here ? h('button', { type: 'button', class: 'btn tiny', disabled: state.busy, onclick: () => !state.busy && locate(n) }, 'Highlight') : null))) : null,
    t.evidence.length > 8 ? h('p', { class: 'more' }, `…and ${t.evidence.length - 8} more in the downloaded tasks.`) : null,
    h('div', { class: 'decide', role: 'group', 'aria-label': `Result for: ${t.title}` },
      choice('pass', 'Pass'), choice('fail', 'Fail'), choice('na', 'Not applicable')),
    h('textarea', {
      rows: '2', 'aria-label': `Notes for: ${t.title}`, placeholder: 'Notes (what was found, who checked)',
      onchange: async e => { t.note = e.target.value; await save(); render(); },
    }, t.note));
}

$('f-owner').addEventListener('change', e => { reviewFilter.owner = e.target.value; renderReview(); });
$('f-task-status').addEventListener('change', e => { reviewFilter.status = e.target.value; renderReview(); });

$('btn-export-review').addEventListener('click', () => {
  if (!state.session.pages.some(p => p.review?.length)) return setStatus('Scan a page first.', 'error');
  const owner = reviewFilter.owner;
  const html = reviewTasksHtml({ projectName: state.session.pages[0].title || 'Accessibility review', pages: state.session.pages, owner, date: new Date().toISOString() });
  download(`review-tasks-${owner === 'all' ? 'design-engineering' : owner === 'ux' ? 'design' : 'engineering'}-${stamp()}.html`, 'text/html', html);
  setStatus(`Review tasks downloaded${owner === 'all' ? '' : ` for ${OWNERS[owner]}`}.`, 'ok');
});

// ── AI review setting ────────────────────────────────────────────────────────

let aiDownloading = false;
let aiKnown = null; // Chrome's answer, asked once per panel (again after a download): it doesn't change while the panel is open
async function showAiStatus() {
  // The switch says whether to use AI; the button only downloads Chrome's model, so it shows only when the switch is on
  // and the model still needs downloading, and never while a download is running.
  if (aiDownloading || !$('ai-status')) return;
  const on = state.settings.ai !== false;
  if (!on) { $('ai-status').textContent = ''; $('btn-ai-start').hidden = true; return; }
  // Text-only support is enough (images are judged when the device supports them).
  const status = aiKnown ??= await aiStatus({ images: false });
  const text = {
    available: 'Ready. AI review runs as part of the full test and listed-page scans.',
    downloadable: 'Chrome needs to download its built-in AI model first (about 2–4 GB, one time).',
    downloading: 'Chrome is downloading its built-in AI model…',
    unavailable: 'Not available on this computer or browser (needs desktop Chrome 138+ with about 22 GB free disk and 16 GB RAM or a 4 GB+ graphics card). Items the AI would judge go to the review tasks instead.',
  }[status] ?? '';
  $('ai-status').textContent = text;
  $('btn-ai-start').hidden = status !== 'downloadable';
}

$('btn-ai-start')?.addEventListener('click', async () => {
  aiDownloading = true;
  $('btn-ai-start').hidden = true;
  $('ai-status').textContent = 'Starting Chrome’s built-in AI…';
  const ok = await aiStart(p => { $('ai-status').textContent = `Downloading the model… ${Math.round(p * 100)}%`; });
  aiDownloading = false;
  aiKnown = null;
  await showAiStatus();
  if (!ok) $('ai-status').textContent = 'The model could not start. Items the AI would judge go to the review tasks instead.';
});

$('ai-enabled')?.addEventListener('change', async e => {
  state.settings.ai = e.target.checked;
  await saveSettings();
  showAiStatus();
});

function showCriterion(sc) {
  state.filter.sc = sc;
  state.filter.standard = 'all';
  state.filter.kind = 'all';
  $('f-standard').value = 'all';
  $('f-kind').value = 'all';
  setView('issues');
  render();
}

const VIEWS = [...document.querySelectorAll('.view-tabs [role="tab"][data-view]')].map(t => t.dataset.view);
function setView(view) {
  state.view = view;
  for (const name of VIEWS) {
    const on = view === name;
    $(`tab-${name}`).setAttribute('aria-selected', String(on));
    $(`tab-${name}`).tabIndex = on ? 0 : -1;
    $(`view-${name}`).hidden = !on;
  }
  if (view === 'schedules') loadSchedules();
}

// Scheduled scans (dashboard): the projects screens, inside the dashboard, with the product open now filled in
// when a new project is added.
function loadSchedules() {
  const frame = $('schedules-frame');
  if (!frame) return;
  const p = currentProject();
  const src = chrome.runtime.getURL(`projects.html?embed=1${p ? `#/edit/${p.id}` : ''}`);
  if (frame.dataset.src !== src) { frame.dataset.src = src; frame.src = src; }
}

async function locate(n) {
  try {
    const found = await engine('highlight', [n.target]);
    setStatus(found ? 'Highlighted on the page.' : 'That element is not on the page right now. It may only appear in another UI state.', found ? 'ok' : 'error');
  } catch (e) {
    setStatus(e.message, 'error');
  }
}

async function copy(text) {
  await navigator.clipboard.writeText(text);
  setStatus('Selector copied.', 'ok');
}

// ── Tests: names, chips, overview ────────────────────────────────────────────

const TEST_LABEL = {
  scan: 'Page scan', ai: 'AI review', screenreader: 'Screen reader preview', spacing: 'Text spacing', keyboard: 'Keyboard walk',
  reflow: 'Reflow at 320px', mobile: 'Phone', motion: 'Motion', explore: 'Use the app', deep: 'Use the app', context: 'Keyboard interactions', record: 'Recorded actions',
  review: 'Review tasks',
};

function renderTestChips() {
  const box = $('test-counts');
  if (!box) return;
  const groups = groupIssues(filtered({ ignoreTest: true, ignoreKind: true }));
  const tests = [...new Set(groups.flatMap(g => [...g.tests]))].sort((a, b) => Object.keys(TEST_LABEL).indexOf(a) - Object.keys(TEST_LABEL).indexOf(b));
  if (state.filter.test !== 'all' && !tests.includes(state.filter.test)) state.filter.test = 'all';
  const chip = (key, label, count) => h('button', {
    type: 'button', class: 'std-chip', 'aria-pressed': String(state.filter.test === key),
    onclick: () => { state.filter.test = key; render(); },
  }, count == null ? label : `${label} · ${count}`);
  box.replaceChildren(chip('all', 'All tests'), ...tests.map(t => chip(t, TEST_LABEL[t] || t, groups.filter(g => g.tests.has(t)).length)));
}

// Dashboard overview: average adherence, adherence per standard and issues by severity (the same numbers as the emailed report).
function renderOverview() {
  if (!$('score-val')) return;
  const scanned = state.session.pages.filter(p => p.scannedAt);
  const sevBar = $('sev-bar');
  if (!scanned.length) {
    $('score-val').textContent = '–';
    $('score-arc').setAttribute('stroke-dashoffset', '220');
    $('score-sub').textContent = 'Scan a page to see average adherence.';
    $('compliance').replaceChildren(h('p', { class: 'hint' }, 'Adherence per standard appears after a scan.'));
    sevBar.replaceChildren();
    return;
  }
  const r = buildRunReport({ pages: scanned, failedPages: state.session.failedPages || [] });
  $('score-val').textContent = r.adherence == null ? '–' : `${r.adherence}%`;
  const wcag = r.compliance.wcag22;
  $('score-arc').setAttribute('stroke-dashoffset', String(220 - (220 * (r.adherence ?? 0)) / 100));
  const similar = state.session.similarPages?.length || 0;
  $('score-sub').textContent = `${scanned.length} page${scanned.length === 1 ? '' : 's'} tested${similar ? ` · ${similar} similar record page${similar === 1 ? '' : 's'} skipped` : ''}${wcag ? ` · ${wcag.review} WCAG criteria need a person` : ''}`;
  $('compliance').replaceChildren(...STANDARDS.filter(s => r.compliance[s.key]).map(s => {
    const c = r.compliance[s.key];
    const pct = c.percent;
    const covered = pct == null ? 'not tested' : `${pct}% of the ${c.passed + c.failed} tested · ${c.review} need${c.review === 1 ? 's' : ''} a person`;
    return h('div', { class: 'r' }, h('span', {}, s.label),
      h('div', { class: 'bar', role: 'img', 'aria-label': `${s.label}: ${covered}` }, h('i', { style: `width:${pct ?? 0}%` })),
      h('b', {}, pct == null ? '–' : `${pct}%`),
      h('small', { class: 'cov' }, pct == null ? 'Not tested' : `of ${c.passed + c.failed} tested · ${c.review} need${c.review === 1 ? 's' : ''} a person`));
  }));
  const v = groupIssues(filtered({ ignoreStandard: true, ignoreKind: true, ignoreTest: true })).filter(g => g.meta.kind === 'violation');
  const colours = { critical: 'var(--sev-1)', serious: 'var(--sev-2)', moderate: 'var(--sev-3)', minor: 'var(--sev-4)' };
  sevBar.replaceChildren(...IMPACTS.map(imp => [imp, v.filter(g => g.meta.impact === imp).length]).filter(([, n]) => n)
    .map(([imp, n]) => h('i', { style: `flex:${n};background:${colours[imp]}` })));
}

// Similar record pages a whole-product scan listed instead of testing.
function renderSkipped() {
  const box = $('skipped-box');
  if (!box) return;
  const list = state.session.similarPages || [];
  box.hidden = !list.length;
  if (!list.length) return;
  $('skipped-sum').textContent = `${list.length} similar record page${list.length === 1 ? '' : 's'} skipped (same layout as the tested ones of their page type)`;
  $('skipped-list').replaceChildren(...list.map(u => h('li', {}, shortUrl(u))),
    h('li', { class: 'hint' }, 'To test every one, set "Record pages to test per page type" to All in Interaction settings.'));
}

// Records Deep mode filled in (and may have saved), named so a person can delete them.
function renderTestData() {
  const box = $('testdata-box');
  if (!box) return;
  const data = [...state.session.pages.flatMap(p => (p.testData || []).map(d => ({ ...d, page: p }))),
  ];
  box.hidden = !data.length;
  if (!data.length) return;
  $('testdata-sum').textContent = `Test data created — delete these (${data.length})`;
  $('testdata-list').replaceChildren(...data.map(d => h('li', {}, h('b', {}, d.name), ` · ${d.page.title || shortUrl(d.page.url)} · ${d.where}`)));
}

// ── Time estimates: measured on this scanner, then learned from this computer's own runs ──

const timings = {
  data: {},
  DEFAULT: { scan: 5000, full: 75000, 'page-quick': 4000, 'page-standard': 11000, 'page-everything': 60000 },
  async load() { this.data = (await chrome.storage.local.get('timings')).timings || {}; this.show(); },
  get(key) { return this.data[key] ?? this.DEFAULT[key]; },
  async record(key, ms) {
    if (!key || !(ms > 0)) return;
    const old = this.data[key];
    this.data[key] = old ? Math.round(old * 0.6 + ms * 0.4) : Math.round(ms); // recent runs count most
    await chrome.storage.local.set({ timings: this.data });
    this.show();
  },
  show() {
    if (!$('eta-scan')) return;
    $('eta-scan').textContent = `About ${duration(this.get('scan'))}`;
    $('eta-full').textContent = this.data.full ? `About ${duration(this.get('full'))}` : 'About 30 s – 2 min';
    const per = this.get(`page-${state.settings.crawlTests}`);
    const n = listedUrls(currentProject()).length;
    $('eta-product').textContent = n ? `About ${duration(per * n)} for ${n} page${n === 1 ? '' : 's'}` : `About ${duration(per)} a page`;
  },
};

function duration(ms) {
  const s = Math.max(1, Math.round(ms / 1000));
  if (s < 60) return `${s} s`;
  const m = Math.round(s / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)} h ${m % 60} min`;
}

// ── Live view (dashboard) ──

const live = {
  on: false, kind: 'page', ordered: [], startedAt: 0, steps: {}, current: null, crawlState: null, timer: null, shotUrl: null,
  el: id => (DASHBOARD ? $(id) : null),
  show(busy) {
    const box = this.el('live');
    if (!box) return;
    box.hidden = !busy;
    $('choices').hidden = busy;
    if (!busy) { clearInterval(this.timer); this.on = false; }
  },
  start({ kind, ordered }) {
    if (!DASHBOARD) return;
    Object.assign(this, { on: true, kind, ordered, startedAt: Date.now(), steps: {}, current: null, crawlState: null, shotUrl: null });
    $('live-level').textContent = kind === 'product' ? $('crawl-tests').selectedOptions[0]?.text.split(':')[0] + ' tests' : '';
    $('live-shot').removeAttribute('src');
    clearInterval(this.timer);
    this.timer = setInterval(() => this.tick(), 1000);
    this.render();
    this.shot();
  },
  step(name, phase, ordered) {
    if (!this.on) return;
    this.ordered = ordered;
    const st = this.steps[name] ||= {};
    if (phase === 'start') { st.startedAt = Date.now(); st.done = false; } else { st.done = true; st.ms = Date.now() - (st.startedAt || Date.now()); }
    this.render();
  },
  crawl(p) {
    if (!this.on) return;
    const at = p.url || p.title;
    if (at && at !== this.current) { this.current = at; this.steps = {}; this.shotUrl = null; setTimeout(() => this.shot(), 1500); }
    this.crawlState = p;
    this.render();
  },
  // A picture of the page being tested (the product's own window, as it is now).
  async shot() {
    const tab = state.tab;
    if (!this.on || !tab || this.shotUrl === tab.url) return;
    try {
      const img = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 60 });
      this.shotUrl = tab.url;
      $('live-shot').src = img;
    } catch { /* the window is minimised or showing another tab */ }
  },
  tick() {
    if (!this.on) return;
    const secs = Math.floor((Date.now() - this.startedAt) / 1000);
    $('live-elapsed').textContent = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`;
    this.render();
  },
  render() {
    if (!this.on) return;
    const tab = state.tab;
    const page = tab?.url ? (() => { try { const u = new URL(tab.url); return u.pathname + u.search; } catch { return tab.url; } })() : '';
    const c = this.crawlState;
    $('live-page').textContent = c ? `Page ${c.tested + 1}: ${page}` : page;
    $('live-page-title').textContent = tab?.title || '';
    // Progress: pages for a listed-page scan, tests for one page.
    let done, total, left;
    if (this.kind === 'product' && c) {
      done = c.tested; total = c.tested + c.queued + (c.url ? 1 : 0);
      $('live-count').textContent = `${done} / ${total}`;
      $('live-count-label').textContent = 'pages tested';
      left = (c.queued + (c.url ? 1 : 0)) * timings.get(`page-${state.settings.crawlTests}`);
      $('kpi-found').textContent = String(total + c.similar + c.failed);
      $('kpi-left').textContent = String(c.queued + (c.url ? 1 : 0));
      $('kpi-left-sub').textContent = `about ${duration(timings.get(`page-${state.settings.crawlTests}`))} each`;
      $('kpi-skipped').textContent = String(c.similar);
    } else {
      done = this.ordered.filter(n => this.steps[n]?.done).length; total = this.ordered.length;
      $('live-count').textContent = `${done} / ${total}`;
      $('live-count-label').textContent = 'tests done';
      const whole = this.ordered.length === 1 && this.ordered[0] === 'scan' ? timings.get('scan') : timings.get('full');
      left = Math.max(0, whole - (Date.now() - this.startedAt));
      for (const id of ['kpi-found', 'kpi-left', 'kpi-skipped']) $(id).textContent = '–';
      $('kpi-left-sub').textContent = '';
    }
    $('ring-arc').setAttribute('stroke-dashoffset', String(total ? 490 - (490 * done) / total : 490));
    $('live-left').textContent = left > 0 ? `${duration(left)} left` : 'almost done';
    const issues = groupIssues(allIssues());
    $('kpi-issues').textContent = String(issues.filter(g => g.meta.kind === 'violation').length);
    $('kpi-issues-sub').textContent = `${issues.filter(g => g.meta.kind === 'unverified').length} couldn’t verify`;
    $('live-steps').replaceChildren(...this.ordered.map(n => {
      const st = this.steps[n];
      const cls = st?.done ? 'done' : st ? 'now' : 'todo';
      return h('li', { class: cls }, h('span', { class: 's', 'aria-hidden': 'true' }, st?.done ? '✓' : ''), TEST_LABEL[n] || n,
        h('em', {}, st?.done ? duration(st.ms) : st ? 'now' : ''));
    }));
  },
};

// ── Persistence & export ─────────────────────────────────────────────────────

async function save() {
  // The dashboard keeps each project's results; the side panel keeps its own.
  if (DASHBOARD) {
    if (state.scanId) await updateScanSession(state.scanId, state.session);
  } else {
    Object.assign(state.session, { rev: crypto.randomUUID(), by: 'panel' }); // the background's saves say by: 'background'
    await chrome.storage.local.set({ session: state.session, recording: state.recording, recordingId: state.recordingId, ...(state.recording && state.tab ? { recordTabId: state.tab.id } : {}) });
  }
}

function download(name, type, text) {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = h('a', { href: url, download: name });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

const stamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');

// ── Wiring ───────────────────────────────────────────────────────────────────

$('btn-scan')?.addEventListener('click', () => runTests(['scan'])); // dashboard
$('btn-full')?.addEventListener('click', () => runTests(FULL_TEST)); // dashboard

async function saveSettings() {
  await chrome.storage.local.set({ settings: { ...state.settings, noLimits: true } });
}

function renderSettings() {
  if (!$('never-click')) return; // settings live in the side panel
  const s = state.settings;
  document.querySelectorAll('input[name="mode"]').forEach(r => { r.checked = r.value === s.mode; });
  $('never-click').value = s.neverClick.join(', ');
  $('max-actions').value = s.maxActions;
  if ($('crawl-tests')) $('crawl-tests').value = s.crawlTests;
  timings.show();
  $('ai-enabled').checked = s.ai !== false;
  showAiStatus();
  renderModeTag();
}

$('btn-product')?.addEventListener('click', scanListedPages); // dashboard only: the side panel scans this page
// The product the user is on fills in a new scheduled project, so no address has to be typed.
$('btn-projects')?.addEventListener('click', () => {
  openDashboard('#/schedules');
});
// The dashboard opens in its own window next to the product's window, so both stay visible
// (a hidden tab is slowed down by the browser, which would upset keyboard and screenshot tests).
$('btn-dashboard')?.addEventListener('click', () => openDashboard('#/'));

// The dashboard (Scan log) opens in a tab; an open one is reused and brought to the front.
async function openDashboard(hash) {
  const base = chrome.runtime.getURL('dashboard.html');
  const [open] = await chrome.tabs.query({ url: `${base}*` });
  if (open) {
    await chrome.tabs.update(open.id, { url: base + hash, active: true });
    await chrome.windows.update(open.windowId, { focused: true }).catch(() => {});
  } else await chrome.tabs.create({ url: base + hash });
}
$('btn-stop')?.addEventListener('click', () => {
  state.stop = true;
  $('btn-stop').disabled = true;
  if ($('rp-title')) $('rp-title').textContent = 'Stopping…';
  resumeCrawl?.();
  setStatus('Stopping after the current step…', 'busy');
});
$('btn-continue')?.addEventListener('click', () => resumeCrawl?.());
$('crawl-tests')?.addEventListener('change', async e => {
  state.settings.crawlTests = e.target.value;
  await saveSettings();
  timings.show();
});
document.querySelectorAll('input[name="mode"]').forEach(r => r.addEventListener('change', async () => {
  state.settings.mode = r.value;
  await saveSettings();
  renderModeTag();
  setStatus(r.value === 'deep' ? '"Use the app" will now also open "Add" forms and test their error messages, without saving anything.' : '"Use the app" will only open and close things.', 'ok');
}));
$('never-click')?.addEventListener('change', async e => {
  state.settings.neverClick = e.target.value.split(/[,\n]/).map(w => w.trim()).filter(Boolean);
  await saveSettings();
});
$('max-actions')?.addEventListener('change', async e => {
  state.settings.maxActions = Math.max(0, parseInt(e.target.value, 10) || 0); // 0 = no limit
  e.target.value = state.settings.maxActions;
  await saveSettings();
});
document.querySelectorAll('[data-test]').forEach(b => b.addEventListener('click', () => runTests([b.dataset.test])));

// After a scan (`after` = its "Done" message) the tab order is added to that message instead of replacing it.
async function showTabOrder(after = '') {
  try {
    await refreshTab();
    const n = await engine('showTabOrder');
    const msg = n ? `Showing ${n} tab stops. Red boxes have no visible focus style.` : 'Run the keyboard walk on this page first.';
    // After a scan that ended on another page there is no tab order to draw: the Done message stays as it is.
    if (after) { if (n) setStatus(`${after} ${msg}`, 'ok'); return; }
    setStatus(msg, n ? 'ok' : 'error');
  } catch (e) {
    setStatus(e.message, 'error');
  }
}
$('btn-taborder')?.addEventListener('click', () => showTabOrder()); // dashboard

// ── Side panel: Scan / Issues / Settings tabs, the test checklist and one Scan button ──
const MAIN = ['scan', 'issues', 'settings'];
const PICKS = [...document.querySelectorAll('[data-pick]')];
function setMain(name) {
  if (!$('main-tab-scan')) return;
  for (const m of MAIN) {
    const on = m === name;
    $(`main-tab-${m}`).setAttribute('aria-selected', String(on));
    $(`main-tab-${m}`).tabIndex = on ? 0 : -1;
    $(`main-${m}`).hidden = !on;
  }
  $('foot-scan').hidden = name !== 'scan';
  $('foot-issues').hidden = name !== 'issues';
  try { localStorage.setItem('panelTab', name); } catch { /* storage blocked */ }
}
function renderPicks() {
  if (!PICKS.length) return;
  const on = PICKS.filter(c => c.checked);
  $('tests-count').textContent = `${on.length}/${PICKS.length}`;
  $('tests-toggle').textContent = on.length ? 'Clear all' : 'Select all';
  $('run-label').textContent = on.length === PICKS.length ? 'Scan this page · all tests'
    : on.length ? `Scan this page · ${on.length} test${on.length === 1 ? '' : 's'}` : 'Scan this page';
}
function renderModeTag() {
  const tag = $('mode-tag');
  if (tag) tag.textContent = state.settings.mode === 'deep' ? 'Deep' : 'Safe';
}
async function savePicks() {
  await chrome.storage.local.set({ panelTests: PICKS.filter(c => !c.checked).map(c => c.dataset.pick) });
}
if ($('main-tab-scan')) {
  for (const m of MAIN) $(`main-tab-${m}`).addEventListener('click', () => setMain(m));
  document.querySelector('.main-tabs').addEventListener('keydown', e => {
    if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    const cur = MAIN.findIndex(m => $(`main-tab-${m}`).getAttribute('aria-selected') === 'true');
    const next = e.key === 'Home' ? 0 : e.key === 'End' ? MAIN.length - 1 : (cur + (e.key === 'ArrowRight' ? 1 : MAIN.length - 1)) % MAIN.length;
    setMain(MAIN[next]);
    $(`main-tab-${MAIN[next]}`).focus();
  });
  PICKS.forEach(c => c.addEventListener('change', () => { renderPicks(); savePicks(); }));
  $('tests-toggle').addEventListener('click', () => {
    const any = PICKS.some(c => c.checked);
    PICKS.forEach(c => { c.checked = !any; });
    renderPicks();
    savePicks();
  });
  // The page scan always runs; the ticked tests (and AI review, when it is on in Settings) run with it.
  $('btn-run').addEventListener('click', async () => {
    const picked = PICKS.filter(c => c.checked).map(c => c.dataset.pick);
    const tests = picked.filter(t => t !== 'taborder');
    const all = picked.length === PICKS.length;
    await runTests(all ? FULL_TEST : tests.length ? ['scan', 'ai', ...tests] : ['scan'], { log: all ? 'full' : tests.length ? tests : 'quick' }); // nothing ticked = the quick page scan
    if (picked.includes('taborder') && !state.stop && /^Done/.test($('status').textContent)) await showTabOrder($('status').textContent);
  });
  // A menu closes after a choice, on Escape and on a click elsewhere; the More menu goes when it has nothing in it.
  const more = $('more-menu');
  if (more && !more.querySelector('.menu button')) more.remove();
}

$('rec')?.addEventListener('change', async e => {
  state.recording = e.target.checked;
  if (state.recording) {
    state.recordingId = newRecordingId();
    await save();
    setStatus('Recording: every page you open in this tab is scanned, and every action you take is tested, also with this panel closed.', 'ok');
    runTests(['scan'], { recordedIn: state.recordingId }).then(listen);
    return;
  }
  engine('stopRecording').catch(() => {});
  const entry = await saveRecording(state.session, state.recordingId);
  state.recordingId = null;
  await save();
  setStatus(`Recording stopped.${entry ? ` Saved as ${entry.name}.` : ''}`, 'ok');
});

for (const name of VIEWS) $(`tab-${name}`).addEventListener('click', () => setView(name));
$('f-sr-page').addEventListener('change', e => { state.srPage = e.target.value; renderScreenReader(); });
$('f-sr-kind').addEventListener('change', () => renderScreenReader());
document.querySelector('.view-tabs').addEventListener('keydown', e => {
  const fwd = DASHBOARD ? ['ArrowDown', 'ArrowRight'] : ['ArrowRight'];
  const back = DASHBOARD ? ['ArrowUp', 'ArrowLeft'] : ['ArrowLeft'];
  if (!fwd.includes(e.key) && !back.includes(e.key)) return;
  e.preventDefault();
  const views = VIEWS;
  const next = views[(views.indexOf(state.view) + (fwd.includes(e.key) ? 1 : views.length - 1)) % views.length];
  setView(next);
  $(`tab-${next}`).focus();
});

const fStandard = $('f-standard');
fStandard.replaceChildren(h('option', { value: 'all' }, 'All standards'), ...STANDARDS.map(s => h('option', { value: s.key }, s.label)));
fStandard.addEventListener('change', e => { state.filter.standard = e.target.value; render(); });
$('f-kind').addEventListener('change', e => { state.filter.kind = e.target.value; render(); });
$('f-page').addEventListener('change', e => { state.filter.page = e.target.value; render(); });

// Dashboard Export menu: closes after a choice, on Escape (focus back on Export) and on a click elsewhere.
for (const menu of document.querySelectorAll('.export-menu, .more-menu')) {
  menu.querySelectorAll('.menu button').forEach(b => b.addEventListener('click', () => { menu.open = false; }));
  menu.addEventListener('keydown', e => { if (e.key === 'Escape' && menu.open) { menu.open = false; menu.querySelector('summary').focus(); } });
  document.addEventListener('click', e => { if (menu.open && !menu.contains(e.target)) menu.open = false; });
}

$('btn-export-html').addEventListener('click', () => {
  if (!state.session.pages.length) return setStatus('Nothing to export yet.', 'error');
  const html = reportHtmlFor(state.session);
  download(`accessibility-report-${stamp()}.html`, 'text/html', html);
  setStatus('Report downloaded. Open it in the browser and use Print → Save as PDF for a PDF.', 'ok');
});

$('btn-export-json').addEventListener('click', () => {
  if (!state.session.pages.length) return setStatus('Nothing to export yet.', 'error');
  const issues = allIssues();
  const data = {
    tool: "DIGIT Accessibility Scanner", target: 'WCAG 2.2 Level AA', exportedAt: new Date().toISOString(),
    ...state.session, pages: state.session.pages.map(dedupedPage), sessionIssues: sessionIssues(state.session.pages), checklist: checklist(state.session.pages, issues), standards: standardsChecklists(state.session.pages, issues),
  };
  download(`accessibility-results-${stamp()}.json`, 'application/json', JSON.stringify(data, null, 2));
});

// Issues as a CSV that Jira (System → External system import → CSV) and spreadsheets read directly.
$('btn-export-csv').addEventListener('click', () => {
  if (!state.session.pages.length) return setStatus('Nothing to export yet.', 'error');
  const name = id => (id ? pageById(id)?.title || pageById(id)?.url || 'Page' : 'Whole site');
  download(`accessibility-issues-${stamp()}.csv`, 'text/csv', issuesCsv(groupIssues(allIssues()), name));
  setStatus('Issues CSV downloaded. In Jira: System → External system import → CSV.', 'ok');
});

// Draft Accessibility Conformance Report (VPAT 2.5 WCAG layout) for an expert to finish.
$('btn-export-acr').addEventListener('click', () => {
  if (!state.session.pages.length) return setStatus('Nothing to export yet.', 'error');
  const issues = allIssues();
  const first = state.session.pages[0];
  let host = '';
  try { host = new URL(first.url).hostname; } catch { /* keep empty */ }
  download(`accessibility-conformance-report-draft-${stamp()}.html`, 'text/html', acrHtml({
    productName: host || first.title || 'Product', productUrl: first.url, pages: state.session.pages,
    criteria: checklist(state.session.pages, issues), groups: groupIssues(issues),
  }));
  setStatus('ACR draft downloaded. An accessibility specialist must review it before it is published.', 'ok');
});

$('btn-clear')?.addEventListener('click', async () => {
  if (!confirm('Clear all scanned pages and results from this session?')) return;
  // A recording that is still on keeps what it found so far in the Scan log, and carries on as a new recording.
  const entry = state.recording ? await saveRecording(state.session, state.recordingId) : null;
  if (state.recording) state.recordingId = newRecordingId();
  state.session = newSession();
  state.open.clear();
  state.filter.sc = null;
  await save();
  render();
  setStatus(`Session cleared.${entry ? ` The recording so far is saved as ${entry.name}.` : ''}`, 'ok');
});

// Dashboard: the scan named in the address (#/scan/<id>) fills every section; other addresses show the Scan log.
async function loadScanFromHash() {
  const m = location.hash.match(/^#\/scan\/([\w-]+)/);
  if (!m) return;
  const entry = await getScan(m[1]);
  if (!entry) return;
  state.scanId = entry.id;
  state.session = entry.session;
  state.open.clear();
  state.filter = { standard: 'all', test: 'all', kind: 'all', page: 'all', screen: 'all', sc: null };
  state.srPage = null;
  if ($('f-standard')) $('f-standard').value = 'all';
  if ($('f-kind')) $('f-kind').value = 'all';
  render();
  setView('home');
}

(async function init() {
  const saved = await chrome.storage.local.get(['session', 'recording', 'recordingId', 'settings']);
  if (DASHBOARD) {
    window.addEventListener('hashchange', loadScanFromHash);
    await loadScanFromHash();
  } else if (saved.session?.v === SESSION_VERSION) state.session = saved.session;
  state.recording = !!saved.recording;
  state.recordingId = state.recording ? saved.recordingId || newRecordingId() : null; // recordings started before ids
  state.settings = withDefaults(saved.settings);
  await timings.load();
  if ($('rec')) $('rec').checked = state.recording;
  renderSettings();
  if (PICKS.length) {
    const off = (await chrome.storage.local.get('panelTests')).panelTests || [];
    PICKS.forEach(c => { c.checked = !off.includes(c.dataset.pick); });
    renderPicks();
    let tab = 'scan';
    try { tab = localStorage.getItem('panelTab') || 'scan'; } catch { /* storage blocked */ }
    setMain(MAIN.includes(tab) ? tab : 'scan');
  }
  if (DASHBOARD) return;
  await refreshTab();
  listen(); // recording was left on: keep testing actions in this tab
  render();
})();

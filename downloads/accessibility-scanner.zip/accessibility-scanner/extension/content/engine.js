/*
 * DIGIT Accessibility Scanner — in-page engine.
 *
 * Injected into the tab under test (isolated world) right after axe-core.
 * Exposes window.__nsScanner; every method returns plain JSON so results can
 * travel back to the side panel through chrome.scripting.executeScript.
 *
 * Target: WCAG 2.2 Level A + AA. Findings are either "violation" (failed a
 * definite test) or "unverified" (the page gave the test nothing it could
 * decide on); there is no "please review" bucket.
 */
(() => {
  const VERSION = '0.9.0';
  if (window.__nsScanner?.version === VERSION) return;

  // WCAG 2.0 / 2.1 / 2.2 Level A and AA only: no AAA and no best-practice rules.
  const AXE_TAGS = ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'wcag22aa'];
  const ADVICE_RULES = ['empty-heading', 'page-has-heading-one', 'heading-order', 'image-redundant-alt', 'empty-table-header'];
  // WCAG 2.2 Level AAA success criteria: out of scope, never listed on a finding.
  const AAA_SC = new Set(['1.2.6', '1.2.7', '1.2.8', '1.2.9', '1.3.6', '1.4.6', '1.4.7', '1.4.8', '1.4.9', '2.1.3', '2.2.3', '2.2.4', '2.2.5', '2.2.6',
    '2.3.2', '2.3.3', '2.4.8', '2.4.9', '2.4.10', '2.4.12', '2.4.13', '2.5.5', '2.5.6', '3.1.3', '3.1.4', '3.1.5', '3.1.6', '3.2.5', '3.3.5', '3.3.6', '3.3.9']);
  const MAX_NODES = Infinity; // every affected element is listed
  const OVERLAY_ID = '__ns-overlay';
  const UNDERSTANDING = 'https://www.w3.org/WAI/WCAG22/Understanding/';

  // WCAG criteria checked by the custom tests below (axe results carry their own).
  const SC = {
    '1.1.1': { level: 'A', version: '2.0', slug: 'non-text-content' },
    '1.2.1': { level: 'A', version: '2.0', slug: 'audio-only-and-video-only-prerecorded' },
    '1.2.2': { level: 'A', version: '2.0', slug: 'captions-prerecorded' },
    '1.3.2': { level: 'A', version: '2.0', slug: 'meaningful-sequence' },
    '1.3.3': { level: 'A', version: '2.0', slug: 'sensory-characteristics' },
    '2.4.2': { level: 'A', version: '2.0', slug: 'page-titled' },
    '2.4.4': { level: 'A', version: '2.0', slug: 'link-purpose-in-context' },
    '2.4.6': { level: 'AA', version: '2.0', slug: 'headings-and-labels' },
    '2.4.13': { level: 'AAA', version: '2.2', slug: 'focus-appearance' },
    '3.3.2': { level: 'A', version: '2.0', slug: 'labels-or-instructions' },
    '4.1.2': { level: 'A', version: '2.0', slug: 'name-role-value' },
    '1.3.1': { level: 'A', version: '2.0', slug: 'info-and-relationships' },
    '1.4.10': { level: 'AA', version: '2.1', slug: 'reflow' },
    '1.4.11': { level: 'AA', version: '2.1', slug: 'non-text-contrast' },
    '2.1.4': { level: 'A', version: '2.1', slug: 'character-key-shortcuts' },
    '2.3.1': { level: 'A', version: '2.0', slug: 'three-flashes-or-below-threshold' },
    '2.5.1': { level: 'A', version: '2.1', slug: 'pointer-gestures' },
    '2.5.2': { level: 'A', version: '2.1', slug: 'pointer-cancellation' },
    '2.5.4': { level: 'A', version: '2.1', slug: 'motion-actuation' },
    '3.3.3': { level: 'AA', version: '2.0', slug: 'error-suggestion' },
    '3.3.7': { level: 'A', version: '2.2', slug: 'redundant-entry' },
    '1.4.12': { level: 'AA', version: '2.1', slug: 'text-spacing' },
    '1.4.13': { level: 'AA', version: '2.1', slug: 'content-on-hover-or-focus' },
    '2.1.1': { level: 'A', version: '2.0', slug: 'keyboard' },
    '2.1.2': { level: 'A', version: '2.0', slug: 'no-keyboard-trap' },
    '2.2.2': { level: 'A', version: '2.0', slug: 'pause-stop-hide' },
    '2.4.1': { level: 'A', version: '2.0', slug: 'bypass-blocks' },
    '2.4.3': { level: 'A', version: '2.0', slug: 'focus-order' },
    '2.4.7': { level: 'AA', version: '2.0', slug: 'focus-visible' },
    '2.4.11': { level: 'AA', version: '2.2', slug: 'focus-not-obscured-minimum' },
    '2.5.7': { level: 'AA', version: '2.2', slug: 'dragging-movements' },
    '2.5.8': { level: 'AA', version: '2.2', slug: 'target-size-minimum' },
    '3.2.1': { level: 'A', version: '2.0', slug: 'on-focus' },
    '3.2.2': { level: 'A', version: '2.0', slug: 'on-input' },
    '3.3.1': { level: 'A', version: '2.0', slug: 'error-identification' },
    '3.3.8': { level: 'AA', version: '2.2', slug: 'accessible-authentication-minimum' },
    '4.1.3': { level: 'AA', version: '2.1', slug: 'status-messages' },
  };

  // SESMag facets (socio-economic inclusivity).
  const SESMAG = {
    tech: 'Access to reliable technology',
    literacy: 'Communication literacy, education and culture',
    efficacy: 'Computer self-efficacy',
    risk: 'Attitude toward technology risks',
    control: 'Perceived control and attitude toward authority',
  };
  const facets = (...keys) => keys.map(k => SESMAG[k]);

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ── DOM helpers ────────────────────────────────────────────────────────────

  function cssPath(el) {
    if (!(el instanceof Element)) return '';
    const parts = [];
    for (let node = el; node && node.nodeType === 1 && node !== document.documentElement; node = node.parentElement) {
      if (node.id && document.querySelectorAll('#' + CSS.escape(node.id)).length === 1) {
        parts.unshift('#' + CSS.escape(node.id));
        break;
      }
      let part = node.localName;
      const parent = node.parentElement;
      if (parent) {
        const same = [...parent.children].filter(c => c.localName === node.localName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(node) + 1})`;
      }
      parts.unshift(part);
    }
    return parts.join(' > ');
  }

  function snippet(el) {
    const html = el.outerHTML || '';
    const open = html.slice(0, html.indexOf('>') + 1) || html;
    return open.length > 260 ? open.slice(0, 257) + '…' : open;
  }

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    if (el.checkVisibility && !el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  // An element's visible text. SVG elements (canvas editors, icons, charts) have no innerText: their text content is
  // used instead, so a rule never stops on "reading 'trim' of undefined".
  const itext = el => el?.innerText ?? el?.textContent ?? '';

  function accName(el) {
    const ids = el.getAttribute('aria-labelledby');
    const fromIds = ids ? ids.split(/\s+/).map(id => document.getElementById(id)?.textContent || '').join(' ') : '';
    const img = el.querySelector?.('img[alt]');
    const name = el.getAttribute('aria-label') || fromIds || el.innerText || el.getAttribute('title') || img?.alt ||
      (el instanceof SVGElement ? el.textContent : '') || '';
    return name.replace(/\s+/g, ' ').trim().slice(0, 80);
  }

  function fieldLabel(el) {
    const labels = el.labels ? [...el.labels].map(l => l.textContent).join(' ') : '';
    return [labels, el.getAttribute('aria-label'), el.getAttribute('placeholder'), el.name, el.id].filter(Boolean).join(' ');
  }

  function deepActive() {
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    return a;
  }

  function inFixed(el) {
    for (let n = el; n && n !== docRoot() && n.nodeType === 1; n = n.parentElement) {
      const p = getComputedStyle(n).position;
      if (p === 'fixed' || p === 'sticky') return true;
    }
    return false;
  }

  // Keep only the outermost elements, so one wide container isn't reported once per child.
  function outermost(els) {
    const set = new Set(els);
    return els.filter(el => { for (let p = el.parentElement; p; p = p.parentElement) if (set.has(p)) return false; return true; });
  }

  function innermost(els) {
    return els.filter(el => !els.some(o => o !== el && el.contains(o)));
  }

  const stripHash = href => href.split('#')[0];
  // A link inside SVG has an object for its href (SVGAnimatedString), not text.
  // An SVG file opened on its own has no <body>: its checks run over the whole document.
  const docRoot = () => document.body || document.documentElement;
  const pageText = () => document.body?.innerText ?? document.documentElement.textContent;
  const htmlEl = tag => document.createElementNS('http://www.w3.org/1999/xhtml', tag);
  const hrefOf = a => { const h = a.href; if (typeof h === 'string') return h; try { return new URL(h?.baseVal || '', location.href).href; } catch { return ''; } };
  // Real dialogs, plus overlays built without dialog markup (lightboxes, modals) that sit on top of the page.
  const OVERLAY_CLASSES = '[class*="lightbox" i], [class*="modal" i], [class*="popup" i], [class*="overlay" i]';
  const visibleDialogs = () => [
    ...document.querySelectorAll('dialog[open], [role="dialog"], [role="alertdialog"], [aria-modal="true"]'),
    ...[...document.querySelectorAll(OVERLAY_CLASSES)].filter(el => /fixed|absolute/.test(getComputedStyle(el).position) && !el.closest('dialog, [role="dialog"], [role="alertdialog"]')),
  ].filter((el, i, all) => isVisible(el) && all.indexOf(el) === i && !all.some(o => o !== el && o.contains(el)));
  // Opened on top of the page: menus and lists, and trees or grids that float. Not the side nav, header or a data
  // grid that are always part of the page (DIGIT's side nav is a role="tree").
  const SHARED_BOX = 'nav, header, footer, aside, [role="navigation"], [role="banner"], [role="contentinfo"], [class*="sidebar" i], [class*="sidenav" i], [class*="side-nav" i], [class*="topbar" i], [class*="navbar" i]';
  const floats = el => [el, el.parentElement, el.parentElement?.parentElement].some(n => n && /absolute|fixed/.test(getComputedStyle(n).position));
  const visiblePopups = () => [...document.querySelectorAll('[role="menu"], [role="listbox"], [role="tree"], [role="grid"]')]
    .filter(el => isVisible(el) && !el.closest(SHARED_BOX) && (el.matches('[role="menu"], [role="listbox"]') || floats(el)));
  const controlled = el => { const id = el.getAttribute('aria-controls')?.split(/\s+/)[0]; return id ? document.getElementById(id) : null; };

  function issue(o) {
    return Object.assign({ source: 'custom', kind: 'violation', impact: 'moderate', wcag: [], level: null, version: null, helpUrl: '', description: '', nodes: [] }, o);
  }

  function wcagIssue(sc, o) {
    const m = SC[sc] ?? { level: 'A', version: '2.0', slug: '' };
    return issue({ wcag: [sc], level: m.level, version: m.version, helpUrl: UNDERSTANDING + m.slug + '.html', ...o });
  }

  // text: the element's own words, so fixes can rebuild the whole element (html is only its opening tag).
  const nodeOf = (el, summary = '') => {
    const text = (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 160);
    return { target: cssPath(el), html: snippet(el), summary, ...(text ? { text } : {}) };
  };
  const nodesOf = (els, summary) => els.slice(0, MAX_NODES).map(el => nodeOf(el, summary));

  const FOCUSABLE = 'a[href], area[href], button, input, select, textarea, iframe, summary, audio[controls], video[controls], [contenteditable=""], [contenteditable="true"], [tabindex]';

  function tabbables() {
    return [...document.querySelectorAll(FOCUSABLE)].filter(el =>
      el.tabIndex >= 0 && !el.disabled && !el.closest('[inert]') && !(el.localName === 'input' && el.type === 'hidden') && isVisible(el));
  }

  // ── axe-core ───────────────────────────────────────────────────────────────

  function wcagFromTags(tags) {
    const all = tags.map(t => /^wcag(\d)(\d)(\d+)$/.exec(t)).filter(Boolean).map(m => `${m[1]}.${m[2]}.${m[3]}`);
    // Only A / AA criteria are shown: "scrollable region" is 2.1.1 (A), not also 2.1.3 (AAA).
    const sc = all.some(s => !AAA_SC.has(s)) ? all.filter(s => !AAA_SC.has(s)) : all;
    const lv = tags.map(t => /^wcag2(\d)?(a{1,3})$/.exec(t)).find(Boolean);
    return { sc, level: lv ? lv[2].toUpperCase() : null, version: lv ? (lv[1] ? `2.${lv[1]}` : '2.0') : null };
  }

  // Contrast cases axe can't decide (background images, gradients, overlaps) are
  // returned as `contrastPending` and measured from a real screenshot by the panel.
  const ICON_TEXT = new Set(['shortTextContent', 'nonBmp', 'pseudoContent']);

  // WCAG 1.4.12 values. axe flags any !important spacing in a style attribute below them, but it only matters where it
  // reaches text: an element with no text of its own, text inside with its own wider value, or a value wide enough for
  // the (smaller) text it reaches all pass.
  const SPACING_MIN = { 'letter-spacing': 0.12, 'word-spacing': 0.16, 'line-height': 1.5 };
  function narrowInlineSpacing(el) {
    return Object.entries(SPACING_MIN).some(([prop, min]) => el.style.getPropertyPriority(prop) === 'important' && [el, ...el.querySelectorAll('*')].some(t => {
      if (![...t.childNodes].some(n => n.nodeType === 3 && n.nodeValue.trim())) return false;
      for (let a = t; a && a !== el; a = a.parentElement) if (a.style?.getPropertyValue(prop)) return false; // its own value applies
      const cs = getComputedStyle(t);
      const v = cs.getPropertyValue(prop);
      return v === 'normal' || parseFloat(v) < min * parseFloat(cs.fontSize) - 0.01;
    }));
  }
  // A focusable element inside aria-hidden that passes focus on as soon as it gets it (a "sentinel" that wraps focus
  // back into a dialog) is never left focused, so it hides nothing from screen-reader users.
  function keepsFocus(el) {
    const prev = document.activeElement, x = scrollX, y = scrollY;
    const focusables = [el, ...el.querySelectorAll(FOCUSABLE)].filter(f => f.matches(FOCUSABLE) && f.tabIndex >= 0);
    const kept = focusables.some(f => { f.focus({ preventScroll: true }); return document.activeElement === f; });
    prev?.focus?.({ preventScroll: true });
    scrollTo(x, y);
    return kept || !focusables.length;
  }
  const AXE_KEEP = { 'avoid-inline-spacing': narrowInlineSpacing, 'aria-hidden-focus': keepsFocus };

  async function runAxe({ measureContrast = false } = {}) {
    const res = await window.axe.run({ exclude: [[`#${OVERLAY_ID}`]] }, {
      runOnly: { type: 'tag', values: AXE_TAGS },
      // target-size is replaced by targetSizeCheck(). A few best-practice rules run too, as Advice (never a failure):
      // headings and tables people rely on, and alt text that repeats the link text.
      rules: { 'target-size': { enabled: false }, ...Object.fromEntries(ADVICE_RULES.map(id => [id, { enabled: true }])) },
      // Passes too, at page load: which text already passed contrast (see "judged once per look" below).
      resultTypes: measureContrast ? ['violations', 'incomplete'] : ['violations', 'incomplete', 'passes'],
    });
    const contrastPending = [];
    const toIssue = kind => r => {
      const { sc, level, version } = wcagFromTags(r.tags);
      const advisory = !level || level === 'AAA';
      return issue({
        ruleId: r.id, source: 'axe', kind, bestPractice: advisory,
        title: r.help, description: r.description, helpUrl: r.helpUrl,
        // Outside the AA target (AAA, best practice): Low, however serious axe rates it, so it never reads as urgent.
        impact: advisory ? 'minor' : r.impact || 'moderate',
        wcag: sc, level, version,
        nodes: r.nodes.slice(0, MAX_NODES).map(n => ({
          target: n.target.map(t => (Array.isArray(t) ? t.join(' ') : t)).join(' '),
          html: n.html.length > 260 ? n.html.slice(0, 257) + '…' : n.html,
          summary: n.failureSummary || '',
        })),
        total: r.nodes.length,
      });
    };
    const incomplete = [];
    const pendingFrom = (r, axeFailed = false) => {
      for (const n of r.nodes) {
        const d = n.any?.[0]?.data || {};
        if (ICON_TEXT.has(d.messageKey)) continue; // icon glyphs, not text
        contrastPending.push({
          target: n.target.map(t => (Array.isArray(t) ? t.join(' ') : t)).join(' '), html: n.html.slice(0, 260), fg: d.fgColor || null,
          required: parseFloat(d.expectedContrastRatio) || 4.5, reason: d.messageKey || '',
          // axe already found it failing: if the screenshot can't be taken, axe's result stands.
          ...(axeFailed ? { axeRatio: parseFloat(d.contrastRatio) || null } : {}),
        });
      }
    };
    // Text contrast is judged once per look: elements whose own colour and background are unchanged since page load
    // were already judged there (re-measuring them in an opened state can be fooled by layered backgrounds);
    // elements that are new or changed colour in this state are measured from a screenshot.
    const targetOf = n => n.target.map(t => (Array.isArray(t) ? t.join(' ') : t)).join(' ');
    const look = target => {
      let el; try { el = document.querySelector(target); } catch { return null; }
      if (!el) return null;
      let bg = 'none';
      for (let n = el; n; n = n.parentElement) { const c = getComputedStyle(n).backgroundColor; if (c && c !== 'rgba(0, 0, 0, 0)' && c !== 'transparent') { bg = c; break; } }
      const cs = getComputedStyle(el);
      return `${cs.color}|${bg}|${cs.fontSize}|${cs.fontWeight}`;
    };
    const contrastRules = res => ['passes', 'violations', 'incomplete'].flatMap(k => (res[k] || []).filter(r => r.id === 'color-contrast').flatMap(r => r.nodes.map(targetOf)));
    if (!measureContrast) C.loadLooks = new Map(contrastRules(res).map(t => [t, look(t)]));
    const unchanged = n => { const t = targetOf(n); return C.loadLooks?.has(t) && C.loadLooks.get(t) === look(t); };
    // Nodes axe flags that a closer look clears (AXE_KEEP); a rule with none left is dropped.
    const kept = r => {
      const keep = AXE_KEEP[r.id];
      if (!keep) return r;
      return { ...r, nodes: r.nodes.filter(n => { let el; try { el = n.target.length === 1 && document.querySelector(n.target[0]); } catch { el = null; } return !el || keep(el); }) };
    };
    const violations = res.violations.map(kept).filter(r => {
      if (!r.nodes.length) return false;
      if (measureContrast && r.id === 'color-contrast') { pendingFrom({ ...r, nodes: r.nodes.filter(n => !unchanged(n)) }, true); return false; }
      return true;
    });
    for (const r of res.incomplete) {
      // Only A/AA questions go to people; axe's AAA / best-practice "can't tell" and its "frame tested" note do not.
      const { level } = wcagFromTags(r.tags);
      if (r.id === 'frame-tested' || (r.id !== 'color-contrast' && (!level || level === 'AAA'))) continue;
      if (r.id !== 'color-contrast') { incomplete.push(r); continue; }
      pendingFrom(measureContrast ? { ...r, nodes: r.nodes.filter(n => !unchanged(n)) } : r);
    }
    // Which criteria axe had something to test on this page (true) or nothing at all (false).
    const axeSC = {};
    const mark = (r, applicable) => wcagFromTags(r.tags).sc.forEach(s => { axeSC[s] = axeSC[s] || applicable; });
    res.inapplicable.forEach(r => mark(r, false));
    [...res.passes, ...res.violations, ...res.incomplete].forEach(r => mark(r, true));
    return {
      issues: [...violations.map(toIssue('violation')), ...incomplete.map(toIssue('unverified'))],
      contrastPending,
      axeSC,
    };
  }

  // ── Static WCAG checks ─────────────────────────────────────────────────────

  function authChecks() {
    const out = [];
    // 3.3.8: actually try pasting into each password / OTP field.
    const fields = [...document.querySelectorAll('input[type="password"], input[autocomplete="one-time-code"]')].filter(isVisible);
    const blocked = fields.filter(el => {
      const dt = new DataTransfer();
      dt.setData('text/plain', 'x');
      const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true });
      el.dispatchEvent(ev);
      return ev.defaultPrevented;
    });
    if (blocked.length) out.push(wcagIssue('3.3.8', {
      ruleId: 'auth-paste-blocked', source: 'auth', impact: 'serious',
      title: 'Password or code field blocks pasting',
      description: 'People who use password managers or copy codes from messages cannot fill this field. Remove the paste-blocking handler.',
      nodes: nodesOf(blocked, 'A paste into this field was cancelled by the page.'),
    }));
    const captcha = outermost([...document.querySelectorAll('img, iframe, canvas, div')].filter(el =>
      /captcha/i.test([el.id, el.getAttribute('class'), el.getAttribute('src'), el.getAttribute('alt')].join(' ')) && isVisible(el)));
    const alternative = [...document.querySelectorAll('a, button, [role="button"]')].some(el => /audio|listen|otp|another way|email me|send (a )?(link|code)/i.test(accName(el)));
    if (captcha.length && !alternative) out.push(wcagIssue('3.3.8', {
      ruleId: 'auth-captcha', source: 'auth', impact: 'serious', kind: 'unverified', sesmag: facets('efficacy', 'literacy'),
      title: 'CAPTCHA with no alternative',
      description: 'A CAPTCHA is a cognitive test. Offer another way to continue that does not need one, such as an OTP, an audio option or a link sent by email.',
      nodes: nodesOf(captcha),
    }));
    return out;
  }

  function draggingChecks() {
    const els = outermost([...document.querySelectorAll('[draggable="true"], [aria-grabbed], [class*="sortable" i], [class*="drag" i]')]
      .filter(el => el.localName !== 'input' && el.localName !== 'img' && isVisible(el)));
    // An item with its own buttons or menu (move up/down, ⋮) has a single-pointer alternative, and so does an item that is
    // itself a button or link (a click does what the drag does). Disabled items are skipped.
    const noAlternative = els.filter(el => !el.matches('button, a[href], [role="button"], [role="link"], [role="menuitem"], [role="option"]')
      && !el.closest('[disabled], [aria-disabled="true"]')
      && !el.querySelector('button, select, [role="button"], [role="menu"], [aria-haspopup]'));
    if (!noAlternative.length) return [];
    return [wcagIssue('2.5.7', {
      ruleId: 'dragging-no-alternative', source: 'dragging', impact: 'serious',
      title: 'Drag-only interaction with no single-pointer alternative',
      description: 'Every drag action must also work with a single click or tap, for example "Move up / Move down" buttons or a menu on each item.',
      nodes: nodesOf(noAlternative, 'Draggable, with no buttons or menu inside.'),
    })];
  }

  // 2.5.8: undersized targets fail when a 24px circle on their centre touches another target.
  const TARGETS = 'a[href], button, input:not([type="hidden"]), select, textarea, summary, [role="button"], [role="link"], [role="checkbox"], [role="radio"], [role="tab"], [role="switch"], [role="menuitem"], [role="option"]';

  // Off-screen or clipped to a pixel (sr-only, skip links until focused).
  const visuallyHiddenRect = r => r.width <= 2 || r.height <= 2 || r.right + scrollX <= 0 || r.bottom + scrollY <= 0;
  const visuallyHidden = el => visuallyHiddenRect(el.getBoundingClientRect()) || /rect\(0(px)?,? ?0(px)?,? ?0(px)?,? ?0(px)?\)|inset\(50%\)/.test(getComputedStyle(el).clip + getComputedStyle(el).clipPath);
  // Keyboard users can do the same thing another way: the card or item also has a real link or button,
  // or the click goes to an address a link on the page already goes to.
  function hasKeyboardEquivalent(el) {
    // Walk out through nested card parts with no links ("card__image-link" inside "card") to the nearest box that has links;
    // it counts only if that box has a single destination (the card's own link).
    const SEL = 'li, article, [class*="card" i], [class*="tile" i], tr';
    for (let box = el.parentElement?.closest(SEL); box; box = box.parentElement?.closest(SEL)) {
      const links = [...box.querySelectorAll('a[href]')].filter(a => !el.contains(a) && isVisible(a));
      if (!links.length) continue;
      if (new Set(links.map(hrefOf)).size === 1) return true;
      break;
    }
    const go = (el.getAttribute('onclick') || '').match(/location(?:\.href)?\s*=\s*['"]([^'"]+)['"]/);
    return !!go && [...document.querySelectorAll('a[href]')].some(a => a.getAttribute('href') === go[1] || hrefOf(a) === (() => { try { return new URL(go[1], location.href).href; } catch { return null; } })());
  }

  function targetSizeCheck() {
    const targets = [...document.querySelectorAll(TARGETS)].filter(el => isVisible(el) && !visuallyHidden(el)).map(el => {
      const r = el.getBoundingClientRect();
      // A 24px target measures a hair under 24 when the page is zoomed out or the screen is scaled.
      return { el, r, cx: r.left + r.width / 2, cy: r.top + r.height / 2, small: r.width < 23.5 || r.height < 23.5 };
    });
    const exempt = t => {
      const cs = getComputedStyle(t.el);
      if (/^(checkbox|radio)$/.test(t.el.type) && cs.appearance !== 'none') return true; // unstyled browser control
      if (cs.display === 'inline' && t.el.parentElement) {
        // Inside a sentence: the surrounding non-link text (not other links' text) is substantial.
        const parent = t.el.parentElement;
        const letters = s => s.replace(/[\s|·•,;:\/-]+/g, '').length;
        // Text of every target (links, buttons, role=link spans…) and label, counted once even when nested.
        const own = [...parent.querySelectorAll(`${TARGETS}, label`)];
        const linkText = own.filter(a => !own.some(o => o !== a && o.contains(a))).reduce((n, a) => n + letters(a.textContent), 0);
        if (letters(parent.textContent) - linkText > 10) return true;
      }
      return false;
    };
    const touchesRect = (t, r) => {
      const dx = Math.max(r.left - t.cx, 0, t.cx - r.right);
      const dy = Math.max(r.top - t.cy, 0, t.cy - r.bottom);
      return dx * dx + dy * dy < 144;
    };
    const fails = targets.filter(t => t.small && !exempt(t) && targets.some(o =>
      o !== t && !o.el.contains(t.el) && !t.el.contains(o.el) &&
      (touchesRect(t, o.r) || (o.small && Math.hypot(t.cx - o.cx, t.cy - o.cy) < 24))));
    if (!fails.length) return [];
    return [wcagIssue('2.5.8', {
      ruleId: 'target-size', source: 'target-size', impact: 'serious',
      title: 'Click or tap target is smaller than 24 × 24px and too close to others',
      description: 'Make targets at least 24 × 24 CSS pixels, or space them so a 24px circle centred on each does not touch any other target.',
      nodes: fails.slice(0, MAX_NODES).map(t => nodeOf(t.el, `Size ${Math.round(t.r.width)} × ${Math.round(t.r.height)}px.`)),
    })];
  }

  // 2.1.1: things that look clickable but keyboard users can never reach.
  const WIDGET_ROLES = 'button, link, checkbox, switch, slider';

  function mouseOnlyChecks() {
    const out = [];
    const notNative = el => !el.matches('a[href], button, input, select, textarea, summary');
    const roleOnly = [...document.querySelectorAll(WIDGET_ROLES.split(', ').map(r => `[role="${r}"]`).join(', '))]
      .filter(el => notNative(el) && el.tabIndex < 0 && el.getAttribute('aria-disabled') !== 'true' && isVisible(el));
    const pointer = [];
    for (const el of docRoot().querySelectorAll('div, span, li, img, svg, i, td, tr, p, h1, h2, h3, h4, h5, h6')) {
      if (pointer.length >= MAX_NODES) break;
      if (getComputedStyle(el).cursor !== 'pointer') continue;
      if (el.parentElement && getComputedStyle(el.parentElement).cursor === 'pointer') continue;
      if (el.tabIndex >= 0 || el.closest(`${FOCUSABLE}, label, #${OVERLAY_ID}`) || roleOnly.includes(el)) continue;
      // A clickable card is fine if a control inside it does the same job (a link, or "Open/View/Edit").
      if (hasKeyboardEquivalent(el)) continue;
      const inner = [...el.querySelectorAll(FOCUSABLE)];
      if (inner.some(c => c.matches('a[href]') || /open|view|details|edit|more|select/i.test(accName(c)))) continue;
      if (inner.length && !inner.every(c => DANGER.test(accName(c)))) continue;
      const r = el.getBoundingClientRect();
      if (r.width < 8 || r.height < 8 || !isVisible(el)) continue;
      pointer.push(el);
    }
    const all = [...roleOnly, ...pointer];
    if (all.length) out.push(wcagIssue('2.1.1', {
      ruleId: 'mouse-only-control', source: 'keyboard-static', impact: 'critical',
      title: 'Clickable element can’t be reached with the keyboard',
      description: 'These elements act as controls (they have a control role or a pointer cursor) but are not in the tab order. Use a native <button> or <a href>, or add tabindex="0" with Enter/Space handling.',
      nodes: [...nodesOf(roleOnly, 'Has a control role but no tabindex.'), ...nodesOf(pointer, 'Has a pointer cursor but cannot receive focus.')].slice(0, MAX_NODES),
    }));
    return out;
  }

  // ── SESMag ─────────────────────────────────────────────────────────────────

  function syllables(word) {
    const w = word.toLowerCase().replace(/e$/, '');
    return Math.max(1, (w.match(/[aeiouy]+/g) || []).length);
  }

  const TECH_TEXT = /\[object Object\]|\b(undefined|NaN|null pointer|stack ?trace|ERR_[A-Z_]{3,}|status code \d{3}|error code:?\s*\w+|internal server error|Exception:|Exception in)\b/;
  const SENSITIVE = /aadha?ar|\bpan\b|bank|account (no|number)|ifsc|date of birth|\bdob\b|income|caste|religion|mobile|phone/i;

  // What each SESMag check could look at on this page (kept in the page's signals): a check with nothing to look at
  // is "not applicable", and a page weight hidden by other sites' files is "couldn't verify", never a pass.
  let sesmagApplies = null;

  function sesmagChecks() {
    const out = [];

    const entries = [...performance.getEntriesByType('navigation'), ...performance.getEntriesByType('resource')];
    const bytes = entries.reduce((s, e) => s + (e.transferSize || 0), 0);
    // Files from other sites report 0 bytes unless they allow timing: when most do, the total says little.
    const hidden = entries.filter(e => !e.transferSize && !e.decodedBodySize).length;
    if (bytes > 3 * 1024 * 1024 || entries.length > 150) out.push(issue({
      ruleId: 'sesmag-page-weight', source: 'sesmag', bestPractice: true, impact: 'moderate', sesmag: facets('tech'),
      title: `Heavy page: at least ${(bytes / 1048576).toFixed(1)} MB over ${entries.length} requests`,
      description: 'People on prepaid data, slow networks or older phones may give up before this page loads. Aim for under 1.5 MB: compress images and load scripts only where they are needed.',
    }));

    // Reading level — English prose only (paragraphs and list items).
    const lang = (document.documentElement.lang || 'en').toLowerCase();
    // Prose in paragraphs, plus long text written straight into a container.
    const loose = [...document.querySelectorAll('main, article, section, div')].filter(el => isVisible(el)).map(el => [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join(' ').replace(/\s+/g, ' ').trim()).filter(t => t.split(' ').length >= 40);
    const blocks = [...[...document.querySelectorAll('p, li, dd')].filter(isVisible).map(el => itext(el).replace(/\s+/g, ' ').trim()).filter(t => t.split(' ').length >= 8), ...loose];
    const prose = blocks.join(' ');
    const words = prose.match(/[A-Za-z]+/g) || [];
    if (lang.startsWith('en') && words.length >= 80) {
      const sentences = prose.split(/[.!?]+(?:\s|$)/).filter(s => s.trim().split(/\s+/).length > 2);
      const syl = words.reduce((s, w) => s + syllables(w), 0);
      const ease = 206.835 - 1.015 * (words.length / Math.max(sentences.length, 1)) - 84.6 * (syl / words.length);
      const long = sentences.filter(s => s.trim().split(/\s+/).length > 30).length;
      if (ease < 50 || long > 3) out.push(issue({
        ruleId: 'sesmag-reading-level', source: 'sesmag', bestPractice: true, impact: 'moderate', sesmag: facets('literacy'),
        title: `Text is hard to read (reading ease ${Math.round(ease)}/100${long ? `, ${long} very long sentences` : ''})`,
        description: 'Use short sentences and everyday words. A reading-ease score of 60 or more is easier for people with less formal education or reading in a second language.',
      }));
    }

    const tech = new Set(), small = new Set();
    const walker = document.createTreeWalker(docRoot(), NodeFilter.SHOW_TEXT);
    for (let t = walker.nextNode(); t; t = walker.nextNode()) {
      const text = t.nodeValue.trim();
      const el = t.parentElement;
      if (text.length < 3 || !el || /^(script|style|noscript|code|pre|textarea)$/.test(el.localName) || el.closest(`#${OVERLAY_ID}`)) continue;
      if (tech.size < MAX_NODES && TECH_TEXT.test(text) && isVisible(el)) tech.add(el);
      if (small.size < MAX_NODES && parseFloat(getComputedStyle(el).fontSize) < 12 && isVisible(el)) small.add(el);
    }
    if (tech.size) out.push(issue({
      ruleId: 'sesmag-technical-text', source: 'sesmag', bestPractice: true, impact: 'serious', sesmag: facets('efficacy', 'literacy'),
      title: 'Raw technical or error text shown to users',
      description: 'Messages like "undefined" or error codes make people think they broke something. Replace them with plain language that says what happened and what to do next.',
      nodes: nodesOf([...tech]),
    }));
    if (small.size) out.push(issue({
      ruleId: 'sesmag-small-text', source: 'sesmag', bestPractice: true, impact: 'minor', sesmag: facets('tech', 'literacy'),
      title: 'Very small text (under 12px)',
      description: 'Small text is hard to read on low-cost phones and small screens. Use at least 14px for body text and 12px for captions.',
      nodes: nodesOf([...small]),
    }));

    // Logos linking home are recognisable without a text label.
    const isLogo = el => /logo|brand|homepage|home-link/i.test(`${el.getAttribute('class') || ''} ${el.querySelector('img, svg')?.getAttribute('class') || ''} ${el.querySelector('img')?.alt || ''}`) || ['/', location.origin + '/'].includes(el.getAttribute('href'));
    // Icons most people recognise without a label, judged by the button's name: they are not flagged. Includes the
    // standard canvas zoom bar (− 66% + ⛶ ⋯): zoom, fit to screen, full screen, and "more" / "… options" menus (⋯),
    // and − / + steppers ("Decrease SLA time").
    const COMMON_ICON = /^(zoom (in|out)|zoom to fit|fit|fit to (screen|view|page|window)|reset zoom|(exit )?full ?screen|more|more (options|actions)|(\w+ ){0,2}(options|actions)|(increase|decrease)\b.*|(close|back|next|previous|prev|go back)\b.*|close|close (dialog|menu|panel|window)|dismiss|search|(open |main )?menu|navigation menu|back|go back|forward|next|previous|prev|home|add|new|plus|minus|edit|delete|remove|download|upload|print|settings|help|info|information|refresh|reload|play|pause|stop|mute|unmute|expand|collapse|show password|hide password|copy|share|undo|redo|notifications?|(move|scroll|go)\b.*\b(up|down|left|right)|(up|down|left|right))$/i;
    const commonIcon = el => COMMON_ICON.test(accName(el).replace(/[.…:!?]+$/, '').trim());
    // A real tooltip (shown on hover and keyboard focus), not just title, which never shows on touch or focus.
    const TOOLTIP_ATTR = '[data-tooltip], [data-tip], [data-tooltip-content], [data-bs-toggle="tooltip"], [data-toggle="tooltip"], [mattooltip], [ng-reflect-message], [v-tooltip], [tooltip]';
    const hasTooltip = el => el.matches(TOOLTIP_ATTR) || `${el.getAttribute('aria-describedby') || ''}`.split(/\s+/).some(id => id && document.getElementById(id)?.matches('[role="tooltip"], [class*="tooltip" i]'))
      || !!el.querySelector('[role="tooltip"]'); // the button's own tooltip, not one that belongs to a neighbour
    const iconOnly = [...document.querySelectorAll('button, a[href], [role="button"]')]
      .filter(el => isVisible(el) && !itext(el).trim() && el.querySelector('svg, img, i, [class*="icon" i]') && !isLogo(el) && !commonIcon(el) && !hasTooltip(el)
        // Not icon-only: switched off, or named by visible text next to it (a dropdown field with its label above).
        && !el.matches(':disabled, [aria-disabled="true"]')
        && !`${el.getAttribute('aria-labelledby') || ''}`.split(/\s+/).some(id => { const l = id && document.getElementById(id); return l && l !== el && !el.contains(l) && isVisible(l) && itext(l).trim(); }));
    if (iconOnly.length) out.push(issue({
      ruleId: 'sesmag-icon-only', source: 'sesmag', bestPractice: true, impact: 'minor', sesmag: facets('literacy', 'efficacy'),
      title: 'Buttons with only an icon and no visible text',
      description: 'These icons aren’t common enough to be understood without words, and they have no tooltip. People new to apps may guess wrong. Show a short label on hover and keyboard focus (a tooltip, not just title), or add a visible text label — a screen-reader label does not help sighted users.',
      nodes: nodesOf(iconOnly),
    }));

    const sensitive = [...document.querySelectorAll('input, select, textarea')].filter(el => el.type !== 'hidden' && isVisible(el) && SENSITIVE.test(fieldLabel(el)));
    sesmagApplies = {
      'sesmag-page-weight': bytes > 3 * 1024 * 1024 || entries.length > 150 || hidden <= entries.length / 2 ? 'yes' : 'unmeasured',
      'sesmag-reading-level': lang.startsWith('en') && words.length >= 80 ? 'yes' : 'no',
      'sesmag-sensitive-data': sensitive.length ? 'yes' : 'no',
      'sesmag-autoplay': document.querySelector('video, audio') ? 'yes' : 'no',
    };
    if (sensitive.length && !/why we|privacy|secure|safe|will (only )?be used|we use|consent|सुरक्षित|गोपनीयता/i.test(pageText())) out.push(issue({
      ruleId: 'sesmag-sensitive-data', source: 'sesmag', bestPractice: true, impact: 'moderate', sesmag: facets('risk', 'control'),
      title: 'Personal data requested with no explanation',
      description: 'People who are wary of technology risks may stop here. Say briefly why each sensitive detail is needed and how it will be kept safe.',
      nodes: nodesOf(sensitive),
    }));

    const autoplay = [...document.querySelectorAll('video[autoplay], audio[autoplay]')].filter(isVisible);
    if (autoplay.length) out.push(issue({
      ruleId: 'sesmag-autoplay', source: 'sesmag', bestPractice: true, impact: 'minor', sesmag: facets('tech', 'control'),
      title: 'Media plays automatically',
      description: 'Autoplay uses mobile data and takes control away from the user. Let people choose to play it.',
      nodes: nodesOf(autoplay),
    }));
    return out;
  }

  // Signals combined across all scanned pages in the side panel.
  const GIGW_ITEMS = {
    privacy: /privacy|गोपनीयता/i,
    terms: /terms|नियम/i,
    copyright: /copyright|कॉपीराइट/i,
    hyperlinking: /hyperlink/i,
    accessibility: /accessibility|अभिगम्यता|सुगम्यता/i,
    help: /\bhelp\b|\bfaq|सहायता/i,
    contact: /contact|संपर्क/i,
    sitemap: /site\s?map|साइट\s?मैप/i,
    feedback: /feedback|प्रतिक्रिया/i,
  };

  // An error or block page instead of the product (often shown to automated browsers): nothing on it can be judged.
  // Bot checks and block notices: a short page that starts with one of these.
  // ("Just a moment..." is also a common loading message, so it counts only as Cloudflare's page title.)
  const BLOCKED = /^(access denied|request rejected|web page blocked|the (url|page) you requested has been blocked|attention required|are you a robot|verify you are (a )?human)(\W|$)/i;
  const ERROR_PHRASE = /^(access denied|forbidden|request rejected|web page blocked|the (url|page) you requested has been blocked|attention required|just a moment|are you a robot|verify you are (a )?human|(page )?not found|page (could not|cannot|can.t) be found|internal server error|bad gateway|gateway time-?out|service (temporarily )?unavailable|site can.t be reached|error|त्रुटि|पृष्ठ नहीं मिला)$/i;
  // One part of a title is an error by itself: “404”, “Error 404”, “404: Page not found”, “Forbidden”. A bare “Error” is not enough.
  const errorPart = part => {
    let s = part.trim().replace(/[.!?…]+$/, '');
    const code = /\b(40[34]|50[0-4])\b/.test(s);
    s = s.replace(/^(error|http|त्रुटि)\s*/i, '').replace(/\b(40[34]|50[0-4])\b/g, '').replace(/\(.*\)/g, '').replace(/^[\s:\-–—!\d]+$|^[\s:\-–—]+|[\s:\-–—!\d]+$/g, '');
    return s === '' ? code : ERROR_PHRASE.test(s) && (code || !/^(error|त्रुटि)$/i.test(s));
  };
  function blockedPage() {
    // The server's answer (403, 404, 5xx) plus what the page shows. An error status with an app is not an error page:
    // single-page apps on GitHub Pages answer deep links with 404 and then render normally, and after an in-app route
    // change the status belongs to the first page, not this one.
    const nav = performance.getEntriesByType?.('navigation')?.[0];
    const sameDoc = nav && nav.name.split('#')[0] === location.href.split('#')[0];
    const status = sameDoc ? nav.responseStatus || 0 : 0;
    const appLike = !!document.querySelector('input:not([type="hidden"]), select, textarea, [role="application"], #root > *, #app > *, #__next > *, #__nuxt > *, #svelte > *, [data-sveltekit-hydrate], [data-reactroot], [ng-version], [data-v-app]');
    const title = (document.title || '').trim();
    const text = (document.body?.innerText || '').replace(/\s+/g, ' ').trim();
    const short = text.length < 600;
    // The title's first or last part is the error (the other end is the site name).
    const parts = title.split(/\s*[|–—·»]\s*|\s+-\s+/).filter(Boolean);
    const titleIsError = parts.length > 0 && (errorPart(parts[0]) || errorPart(parts[parts.length - 1]));
    const label = title || text.slice(0, 80);
    if (status >= 400 && (titleIsError || (short && (BLOCKED.test(text) || !appLike)))) return `${status} ${label}`.trim();
    // Without an error status only a short page counts: long pages such as MDN's “404 Not Found - HTTP” reference
    // or “Forbidden City tour” are content, not errors.
    if (short && (titleIsError || BLOCKED.test(text))) return label;
    return null;
  }

  function pageSignals() {
    const controls = [...document.querySelectorAll('a, button, [role="link"], [role="button"], option')].filter(el => !el.closest(`#${OVERLAY_ID}`));
    const named = controls.map(el => ({ el, text: accName(el) + ' ' + (el.getAttribute('href') || '') }));
    const has = re => named.some(n => re.test(n.text));
    const gigw = {};
    const headings = [...document.querySelectorAll('h1, h2, h3, [role="heading"]')].map(h => h.textContent.replace(/\s+/g, ' ').trim());
    for (const [key, re] of Object.entries(GIGW_ITEMS)) gigw[key] = has(re) || headings.some(h => re.test(h));
    // A "Website Policies" page is the usual GIGW home for these policies.
    if (has(/website\s*polic|वेबसाइट\s*नीति/i)) for (const k of ['privacy', 'terms', 'copyright', 'hyperlinking']) gigw[k] = true;
    // A site-named policy page in the footer ("DigiLocker Policy"): the word before "Policy" is a whole word of the site's
    // title or address. Policy documents in menus and content ("Tourism Policy" on tourism.gov.in) are not.
    const siteWords = new Set(`${document.title} ${location.hostname}`.toLowerCase().split(/[^\p{L}\p{M}\p{N}]+/u));
    const policyLink = controls.find(el => {
      if (!el.closest('footer, [role="contentinfo"], [class*="footer" i], [id*="footer" i]')) return false;
      const m = accName(el).replace(/\s+/g, ' ').trim().match(/^(?:(\S+)\s+)?(?:polic(?:y|ies)|नीतियाँ|नीति)$/i);
      if (!m) return false;
      const w = (m[1] || '').toLowerCase();
      return !w || /^(site|portal|our|all)$/.test(w) || (w.length >= 3 && siteWords.has(w) && !/^(the|and|for|this|that|your|new|any|www|gov|nic|com|org|net)$|cookie|privacy|copyright|hyperlink|terms|refund|return|cancel/.test(w));
    });
    gigw.policyPage = !!policyLink;
    gigw.policyLink = policyLink ? { ...nodeOf(policyLink), href: hrefOf(policyLink) } : null;
    gigw.languageSwitch = has(/हिन्दी|हिंदी|hindi|english|भाषा|language/i) || !!document.querySelector('link[hreflang]');
    gigw.skipLink = named.some(n => n.el.localName === 'a' && /^#./.test(n.el.getAttribute('href') || '') && /skip|main content|मुख्य/i.test(n.text));
    gigw.lastUpdated = /last\s*(updated|reviewed|modified)|अंतिम\s*(अद्यतन|संशोधन)/i.test(document.body?.innerText || '');
    const helpLinks = [...new Set(named.filter(n => /\bhelp\b|support|contact|faq|सहायता/i.test(n.text)).map(n => accName(n.el)).filter(Boolean))].slice(0, 5);

    // 3.2.3: the order of navigation items; 3.2.4: what each internal link is called; 2.4.5: ways to find pages.
    const navs = [...document.querySelectorAll('nav, [role="navigation"]')].filter(isVisible);
    const navOrder = [...new Set(navs.flatMap(n => [...n.querySelectorAll('a[href], button, [role="menuitem"], [role="link"]')].map(accName).filter(Boolean)))].slice(0, 60);
    const linkNames = {};
    for (const a of document.querySelectorAll('a[href]')) {
      const name = accName(a).toLowerCase();
      let u;
      try { u = new URL(a.getAttribute('href'), location.href); } catch { continue; }
      if (!name || u.origin !== location.origin) continue;
      if (!/^#!?\//.test(u.hash)) u.hash = '';
      const list = linkNames[u.href] ??= [];
      if (!list.includes(name)) list.push(name);
    }
    const ways = {
      navigation: navs.length > 0 || !!document.querySelector('[role="menubar"], header a[href]'),
      search: !!document.querySelector('input[type="search"], [role="search"], form[action*="search" i], input[name*="search" i], input[placeholder*="search" i]'),
      sitemap: has(/site\s?map|साइट\s?मैप/i),
      index: has(/a\s?[-–]\s?z|\bindex\b|table of contents/i),
    };
    return {
      gigw, helpLinks, navOrder, linkNames, ways,
      hasMedia: !!document.querySelector('video, audio, iframe[src*="youtube"], iframe[src*="vimeo"], iframe[src*="player"]'),
      hasForm: !!document.querySelector('input:not([type="hidden"]), select, textarea'),
      hasLogin: !!document.querySelector('input[type="password"], input[autocomplete="one-time-code"], [class*="captcha" i], [id*="captcha" i]'),
      sesmag: sesmagApplies,
    };
  }

  // ── 2.4.3 positive tabindex, 1.4.11 non-text contrast, 2.5.1 pointer gestures ──

  function positiveTabindex() {
    const els = [...document.querySelectorAll('[tabindex]')].filter(el => el.tabIndex > 0 && isVisible(el));
    if (!els.length) return [];
    return [bp({
      ruleId: 'positive-tabindex', source: 'keyboard-static',
      title: 'Positive tabindex changes the focus order',
      description: 'Elements with tabindex greater than 0 are focused before everything else, so Tab no longer follows the reading order. Use tabindex="0" (or none) and put elements in the right order in the HTML.',
      nodes: nodesOf(els, 'tabindex is greater than 0.'),
    })];
  }

  // Any CSS colour as rgba(): Chrome reports modern formats (oklch(), lab(), color(display-p3 …)) as written, so those are
  // painted on a 1-pixel canvas and read back as red, green and blue. Not a colour ("none", "") → null.
  const toRgb = (() => {
    const cache = new Map();
    let ctx;
    return s => {
      if (/^rgba?\(/.test(s)) return s;
      if (cache.has(s)) return cache.get(s);
      ctx ??= Object.assign(htmlEl('canvas'), { width: 1, height: 1 }).getContext('2d', { willReadFrequently: true });
      ctx.fillStyle = '#010203';
      ctx.fillStyle = s; // an invalid colour leaves the sentinel in place
      let out = null;
      if (String(ctx.fillStyle) !== '#010203') {
        ctx.clearRect(0, 0, 1, 1);
        ctx.fillRect(0, 0, 1, 1);
        const [r, g, b, a] = ctx.getImageData(0, 0, 1, 1).data;
        out = `rgba(${r}, ${g}, ${b}, ${+(a / 255).toFixed(3)})`;
      }
      cache.set(s, out);
      return out;
    };
  })();
  const parseColor = s => { s = s && toRgb(s); const m = (s || '').match(/[\d.]+/g); if (!m || m.length < 3) return null; const [r, g, b, a = 1] = m.map(Number); return { r, g, b, a }; };
  const relLum = ({ r, g, b }) => { const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const contrastOf = (x, y) => { const a = relLum(x), b = relLum(y); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); };
  const over = (c, bg) => ({ r: c.r * c.a + bg.r * (1 - c.a), g: c.g * c.a + bg.g * (1 - c.a), b: c.b * c.a + bg.b * (1 - c.a) });

  // The solid colour painted behind (and including) an element; null when an image or gradient is involved.
  function backdrop(el) {
    const layers = [];
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.backgroundImage !== 'none') return null;
      const c = parseColor(cs.backgroundColor);
      if (c && c.a > 0) { layers.push(c); if (c.a >= 1) break; }
    }
    return layers.reverse().reduce((bg, c) => over(c, bg), { r: 255, g: 255, b: 255 });
  }

  const FIELD_SEL = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="image"]):not([type="range"]):not([type="color"]):not([type="file"]), select, textarea';

  function nonTextContrast() {
    const fails = [];
    const fields = [
      ...document.querySelectorAll(FIELD_SEL),
      ...[...document.querySelectorAll('input[type="checkbox"], input[type="radio"]')].filter(el => getComputedStyle(el).appearance === 'none'),
      ...[...document.querySelectorAll('[role="checkbox"], [role="radio"], [role="switch"]')].filter(el => el.localName !== 'input'),
    ].filter(isVisible).filter(el => !el.matches(':disabled, [aria-disabled="true"]')); // inactive controls are exempt (1.4.11)
    for (const el of fields) {
      // A border still fading (hover, focus, a dialog opening) is judged only once it has settled.
      if (el.getAnimations?.().some(a => a.playState === 'running')) continue;
      const outside = backdrop(el.parentElement);
      const inside = backdrop(el);
      if (!outside || !inside) continue;
      const cs = getComputedStyle(el);
      const borders = ['Top', 'Right', 'Bottom', 'Left']
        .map(s => ({ w: parseFloat(cs[`border${s}Width`]), c: parseColor(cs[`border${s}Color`]), style: cs[`border${s}Style`] }))
        // A 1px border reads as 0.8px on a screen scaled to 125%: any width is drawn.
        .filter(b => b.w > 0 && b.style !== 'none' && b.c && b.c.a > 0)
        .map(b => contrastOf(over(b.c, outside), outside));
      const shadow = cs.boxShadow !== 'none';
      if (contrastOf(inside, outside) >= 3 || borders.some(r => r >= 3) || shadow) continue;
      // The visible edge may be drawn by a wrapper that hugs the field (search boxes, input groups).
      const er = el.getBoundingClientRect();
      // (The wrapper may also hold a button, so it can be wider — but it must be about the same height.)
      const ancestors = [];
      for (let w = el.parentElement, i = 0; w && w !== docRoot() && i < 4; w = w.parentElement, i++) ancestors.push(w);
      const wrapped = ancestors.some(w => {
        const wr = w.getBoundingClientRect(), ws = getComputedStyle(w), wb = backdrop(w.parentElement);
        const hugs = Math.abs(wr.height - er.height) < 16 && wr.width < er.width * 1.6 + 40;
        const edge = ['Top', 'Bottom'].some(side => parseFloat(ws[`border${side}Width`]) > 0 && ws[`border${side}Style`] !== 'none' && wb && contrastOf(over(parseColor(ws[`border${side}Color`]) ?? { r: 255, g: 255, b: 255, a: 0 }, wb), wb) >= 3);
        return hugs && (edge || ws.boxShadow !== 'none' || (wb && backdrop(w) && contrastOf(backdrop(w), wb) >= 3));
      });
      if (wrapped) continue;
      fails.push(nodeOf(el, borders.length ? `Border contrast ${Math.max(...borders).toFixed(2)}:1 against the background (needs 3:1).` : 'No visible border, and the fill is not distinguishable from the background.'));
    }
    // Icon-only buttons: the icon itself must stand out from the button.
    for (const btn of document.querySelectorAll('button, [role="button"], a[href]')) {
      if (fails.length >= MAX_NODES || !isVisible(btn) || itext(btn).trim() || btn.matches(':disabled, [aria-disabled="true"]')) continue;
      const svg = btn.querySelector('svg');
      const bg = backdrop(btn);
      if (!svg || !bg) continue;
      // The colour of what is actually drawn: the icon's shapes (a <path fill="currentColor">), not the <svg> wrapper,
      // whose own fill is the browser default (black) when the shapes set theirs.
      const shapes = [...svg.querySelectorAll('path, circle, rect, line, polyline, polygon, ellipse, use, text')].slice(0, 6);
      const paintOf = cs => [cs.fill, cs.stroke].map(c => (c === 'none' ? null : parseColor(c))).find(c => c && c.a > 0);
      const paint = shapes.map(sh => paintOf(getComputedStyle(sh))).find(Boolean) ?? paintOf(getComputedStyle(svg)) ?? parseColor(getComputedStyle(svg).color);
      if (!paint) continue;
      const r = contrastOf(over(paint, bg), bg);
      if (r < 3) fails.push(nodeOf(btn, `Icon contrast ${r.toFixed(2)}:1 against the button background (needs 3:1).`));
    }
    if (!fails.length) return [];
    return [wcagIssue('1.4.11', {
      ruleId: 'non-text-contrast', source: 'contrast', impact: 'serious',
      title: 'Form fields or icons do not stand out from the background',
      description: 'The edges of form fields, custom checkboxes and the icons of icon-only buttons need at least 3:1 contrast against what is next to them, so people with low vision can find them.',
      nodes: fails.slice(0, MAX_NODES),
    })];
  }

  function gestureChecks() {
    const areas = outermost([...document.querySelectorAll('[class*="swiper" i], [class*="slick" i], [class*="carousel" i], [aria-roledescription="carousel" i], [class*="leaflet-container" i], .gm-style, [class*="mapboxgl-map" i], [class*="glide" i], [class*="splide" i]')].filter(isVisible));
    // Previous / Next arrows (often just "<" and ">"), or dots that go to a slide.
    const alt = /prev|next|previous|zoom|‹|›|«|»|<|>|arrow|slide \d|go to slide|indicator|\bdots?\b/i;
    const lacking = areas.filter(el => ![el, el.parentElement].filter(Boolean)
      .some(scope => [...scope.querySelectorAll('button, [role="button"], a[href]')].some(b => isVisible(b) && alt.test(`${accName(b)} ${b.getAttribute('class') || ''}`))));
    if (!lacking.length) return [];
    return [wcagIssue('2.5.1', {
      ruleId: 'gesture-no-alternative', source: 'gesture', impact: 'serious',
      title: 'Swipe or pinch area has no button alternative',
      description: 'This carousel or map seems to need swiping or pinching. Add Previous / Next (or zoom) buttons so it also works with a single tap or click.',
      nodes: nodesOf(lacking, 'No Previous / Next or zoom buttons found.'),
    })];
  }

  // ── Rule checks beyond axe: links, images, tables, forms, structure, language direction, typography ──
  // Best-practice and AAA findings are flagged bestPractice: reported, but not part of adherence.

  const bp = o => issue({ bestPractice: true, impact: 'minor', ...o });
  const visibleAll = sel => [...document.querySelectorAll(sel)].filter(el => isVisible(el) && !el.closest(`#${OVERLAY_ID}`));
  const norm = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const fileOf = href => { try { return new URL(href, location.href).pathname.split('/').pop().toLowerCase(); } catch { return ''; } };
  // Only phrases that never name a destination ("Details", "View", "Continue" can be real page or step names).
  const VAGUE = /^(click here|here|read more|more|learn more|this|this page|this link|continue reading|more info|more information|click|view more|see more|find out more|page|my page|link|website|this website|details|go|go here)$/i;

  function linkChecks() {
    const out = [];
    const links = visibleAll('a[href]');
    const named = links.map(a => ({ a, name: norm(accName(a)), href: hrefOf(a) }));
    const pick = (f, summary) => nodesOf(named.filter(f).map(x => x.a), summary);

    const newWindow = named.filter(x => x.a.target === '_blank' && !/new (window|tab)|opens in|external|↗|⧉/.test(`${x.name} ${norm(x.a.title)} ${norm(x.a.getAttribute('aria-describedby') && document.getElementById(x.a.getAttribute('aria-describedby'))?.textContent)}`));
    if (newWindow.length) out.push(bp({ ruleId: 'link-new-window', source: 'links', wcag: ['3.2.5'], level: 'AAA', version: '2.0',
      title: 'Link opens a new window without warning', description: 'Tell people a link opens a new tab or window, for example "(opens in a new tab)" in the link text or a labelled icon.', nodes: nodesOf(newWindow.map(x => x.a)) }));

    const files = named.filter(x => /\.(pdf|docx?|xlsx?|pptx?|odt|ods|zip|csv|rtf)$/i.test(fileOf(x.href)) && !/pdf|word|excel|powerpoint|\b(kb|mb)\b|\bdoc|\bxls|\bzip|\bcsv|\bppt|odt|rtf/.test(`${x.name} ${norm(x.a.title)}`));
    if (files.length) out.push(bp({ ruleId: 'link-file-info', source: 'links', impact: 'moderate',
      title: 'Link to a file doesn’t say its type or size', description: 'Say what kind of file a link downloads and how big it is, for example "Annual report (PDF, 2 MB)".', nodes: pick(x => files.includes(x)) }));

    // Only that the PDF is there: what's inside it isn't tested, so a person checks it.
    const pdfs = named.filter(x => /\.pdf$/i.test(fileOf(x.href)));
    if (pdfs.length) out.push(wcagIssue('1.3.1', { ruleId: 'pdf-linked', source: 'links', kind: 'unverified', impact: 'moderate',
      title: 'Page links to a PDF', description: 'The scanner doesn’t open PDFs. Check each one by hand: it is tagged for screen readers, has a title and language set, has real text (not a scanned image), and its images have descriptions.', nodes: pick(x => pdfs.includes(x)) }));

    const noDest = named.filter(x => /^(#|javascript:)/i.test(x.a.getAttribute('href').trim()) && !x.a.matches('[role="button"], [role="tab"], [role="menuitem"], [aria-controls], [aria-expanded]') && !/^#.+/.test(x.a.getAttribute('href')));
    if (noDest.length) out.push(bp({ ruleId: 'link-no-destination', source: 'links', impact: 'moderate',
      title: 'Link doesn’t go anywhere', description: 'Links with href="#" or "javascript:" are announced as links but act as buttons (or do nothing). Use a <button> for actions, or give the link a real destination.', nodes: pick(x => noDest.includes(x)) }));

    const punct = named.filter(x => x.name && /^[\s\p{P}\p{S}]+$/u.test(x.name));
    if (punct.length) out.push(wcagIssue('2.4.4', { ruleId: 'link-text-punctuation', source: 'links', impact: 'serious',
      title: 'Link text is only punctuation', description: 'A link whose text is a full stop or symbol says nothing about where it goes. Give it meaningful text.', nodes: pick(x => punct.includes(x)) }));

    // A word that can be a name ("Details", "Link", "Page") in a menu of links is a name, like its neighbours
    // ("Checkboxes", "Date input", "Details"); "click here", "read more" and "here" never are.
    const NAME_WORD = /^(details|link|page|website)$/i;
    const inMenu = a => {
      const list = a.closest('ul, ol, [role="list"], [role="menu"]');
      const items = list ? [...list.querySelectorAll('a[href]')].filter(o => o !== a) : [];
      return (!!a.closest('nav, [role="navigation"], [role="menu"], aside') || items.length >= 3) && items.length >= 2 && items.filter(o => { const n = norm(accName(o)); return !VAGUE.test(n) || NAME_WORD.test(n); }).length >= items.length * 0.75;
    };
    const vagueAll = named.filter(x => VAGUE.test(x.name) && !x.a.getAttribute('aria-label') && !(NAME_WORD.test(x.name) && inMenu(x.a)));
    const linkContext = a => {
      if (a.getAttribute('aria-describedby') || a.title) return true;
      // The sentence around it: in a paragraph-like box, or a box of text alone ("<div><a>Read more</a> about WAI</div>").
      const box = a.closest('p, li, td, th, dd');
      if (box && norm(box.textContent.replace(a.textContent, '')).split(' ').filter(Boolean).length >= 3) return true;
      // Only its plain text counts there, not other links or buttons (a row of "Read more · Share · Like").
      const parent = a.parentElement;
      if (!box && parent && parent !== docRoot() && !parent.querySelector('div, p, ul, ol, li, section, article, table, h1, h2, h3, h4, h5, h6') &&
        norm([...parent.childNodes].filter(n => n.nodeType === 3 || (n.nodeType === 1 && !n.matches('a, button, [role="link"], [role="button"]'))).map(n => n.textContent).join(' ')).split(' ').filter(Boolean).length >= 3) return true;
      const card = a.closest('li, article, section, [class*="card" i]');
      return !!card?.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
    };
    const vague = vagueAll.filter(x => !linkContext(x.a));
    const vagueInContext = vagueAll.filter(x => linkContext(x.a));
    if (vagueInContext.length) out.push(bp({ ruleId: 'link-vague-in-context', source: 'links', wcag: ['2.4.9'], level: 'AAA', version: '2.0',
      title: 'Link text only makes sense with the text around it', description: 'The sentence or heading around these links explains them (enough for WCAG 2.4.4), but on their own — in a screen reader’s list of links — "Read more" says nothing. Name the destination in the link.', nodes: pick(x => vagueInContext.includes(x)) }));
    if (vague.length) out.push(wcagIssue('2.4.4', { ruleId: 'link-vague', source: 'links', impact: 'moderate',
      title: 'Link text doesn’t say where it goes', description: '"Click here", "read more" and similar don’t make sense out of context (screen-reader users often list links on their own). Use text that names the destination, for example "Read the 2025 annual report".', nodes: pick(x => vague.includes(x)) }));

    const byName = {};
    for (const x of named) if (x.name && !VAGUE.test(x.name)) (byName[x.name] ??= new Set()).add(x.href.split('#')[0]);
    const clash = Object.entries(byName).filter(([, s]) => s.size > 1).map(([n]) => n);
    if (clash.length) out.push(bp({ ruleId: 'link-same-text', source: 'links', impact: 'moderate', wcag: ['2.4.9'], level: 'AAA', version: '2.0',
      title: 'Links with the same text go to different places', description: 'Links that read the same should go to the same place. Make each link’s text unique to its destination.', nodes: pick(x => clash.includes(x.name)) }));

    const adjacent = named.filter((x, i) => i > 0 && named[i - 1].href === x.href && named[i - 1].a.parentElement === x.a.parentElement);
    if (adjacent.length) out.push(bp({ ruleId: 'link-adjacent-duplicate', source: 'links',
      title: 'Two links next to each other go to the same place', description: 'An image link and a text link to the same page, side by side, make keyboard and screen-reader users go through it twice. Combine them into one link.', nodes: pick(x => adjacent.includes(x)) }));

    const sameTitle = named.filter(x => x.name && norm(x.a.title) === x.name);
    if (sameTitle.length) out.push(bp({ ruleId: 'link-title-redundant', source: 'links',
      title: 'Link title repeats the link text', description: 'A title attribute that repeats the link text adds nothing and is read twice by some screen readers. Remove it.', nodes: pick(x => sameTitle.includes(x)) }));

    const unseparated = links.filter(a => {
      const prev = a.previousSibling;
      return prev && prev.nodeType === 3 && !prev.textContent.trim() && prev.previousSibling?.localName === 'a' && !a.closest('li, nav, [role="navigation"]');
    }).concat(links.filter(a => a.previousSibling?.localName === 'a' && !a.closest('li, nav, [role="navigation"]')));
    if (unseparated.length) out.push(bp({ ruleId: 'links-not-separated', source: 'links',
      title: 'Links next to each other aren’t separated', description: 'Adjacent links with nothing printable between them run together for screen readers and some users. Separate them with text, a list, or visible punctuation.', nodes: nodesOf([...new Set(unseparated)]) }));

    const media = named.filter(x => /\.(mp3|wav|ogg|m4a|aac|mp4|mov|webm|avi|wmv)$/i.test(fileOf(x.href)));
    const noTranscript = media.filter(x => !/transcript/i.test(x.a.parentElement?.textContent || '') && !visibleAll('a[href]').some(a => /transcript/i.test(accName(a))));
    const mediaLinkIssue = (kind, list, summary) => wcagIssue('1.2.1', { ruleId: 'link-media-no-transcript', source: 'media', kind, impact: 'serious', wcag: ['1.2.1'], level: 'A', version: '2.0',
      title: 'Link to audio or video has no transcript', description: 'Provide a transcript (and captions for video) for linked audio and video files.', nodes: pick(x => list.includes(x), summary) });
    const nearText = noTranscript.filter(x => textNextTo(x.a));
    if (noTranscript.length > nearText.length) out.push(mediaLinkIssue('violation', noTranscript.filter(x => !nearText.includes(x))));
    if (nearText.length) out.push(mediaLinkIssue('unverified', nearText, 'The text next to this link may be the transcript. Check it says everything the recording does.'));

    const toImage = named.filter(x => /\.(jpe?g|png|gif|webp|bmp|tiff?)$/i.test(fileOf(x.href)) && (!x.name || x.name === fileOf(x.href) || x.name === fileOf(x.href).replace(/\.\w+$/, '') || VAGUE.test(x.name)));
    if (toImage.length) out.push(bp({ ruleId: 'link-to-image', source: 'links', impact: 'moderate',
      title: 'Link to an image has no description', description: 'When linking to an image file, describe the image in the link text or next to it.', nodes: pick(x => toImage.includes(x)) }));
    return out;
  }

  function imageChecks() {
    const out = [];
    const imgs = visibleAll('img');
    // Images hidden from screen readers (aria-hidden, role="none") never have their alt read.
    const fileAlt = imgs.filter(img => { const alt = norm(img.getAttribute('alt')); return alt && !img.closest('[aria-hidden="true"]') && !img.matches('[role="presentation"], [role="none"]') && (/\.(png|jpe?g|gif|svg|webp|bmp)$/.test(alt) || /^(img|image|dsc|photo|pic|screenshot|untitled)[-_ ]?\d+/.test(alt) || alt === fileOf(img.src) || alt === fileOf(img.src).replace(/\.\w+$/, '')); });
    if (fileAlt.length) out.push(wcagIssue('1.1.1', { ruleId: 'alt-filename', source: 'images', impact: 'serious', wcag: ['1.1.1'], level: 'A', version: '2.0',
      title: 'Image description is a file name', description: 'Alt text like "IMG_2041.jpg" tells people nothing. Describe what the image shows, or use alt="" if it is decorative.', nodes: nodesOf(fileAlt) }));
    const mismatch = imgs.filter(img => { const a = norm(img.getAttribute('alt')), t = norm(img.title); return a && t && a !== t; });
    if (mismatch.length) out.push(bp({ ruleId: 'alt-title-mismatch', source: 'images',
      title: 'Image alt and title say different things', description: 'Some people get the alt text and others the title. Make them agree, or remove the title.', nodes: nodesOf(mismatch) }));
    const emptyAltTitle = imgs.filter(img => img.getAttribute('alt') === '' && norm(img.title));
    if (emptyAltTitle.length) out.push(bp({ ruleId: 'alt-empty-with-title', source: 'images', impact: 'moderate',
      title: 'Image marked decorative but has a title', description: 'alt="" says the image is decorative, but the title says it carries information. If it matters, put that text in the alt; if not, remove the title.', nodes: nodesOf(emptyAltTitle) }));
    const presentation = [...document.querySelectorAll('img[role="presentation"], img[role="none"]')].filter(img => norm(img.getAttribute('alt')));
    if (presentation.length) out.push(bp({ ruleId: 'presentation-with-alt', source: 'images', impact: 'moderate',
      title: 'Image marked as decorative but has alt text', description: 'role="presentation" hides the image from screen readers, but its alt text suggests it carries meaning. Decide which is right.', nodes: nodesOf(presentation) }));
    const vagueButton = [...document.querySelectorAll('input[type="image"]')].filter(b => /^(button|submit|image|img|go|click|icon|picture)$/i.test((b.getAttribute('alt') || '').trim()));
    if (vagueButton.length) out.push(wcagIssue('1.1.1', { ruleId: 'image-button-vague-alt', source: 'images', impact: 'serious', wcag: ['1.1.1'], level: 'A', version: '2.0',
      title: 'Image button’s description doesn’t say what it does', description: 'An image button’s alt text must say what it does ("Search", "Send message"), not "button" or "image".', nodes: nodesOf(vagueButton) }));
    const spacers = [...document.querySelectorAll('img')].filter(img => /spacer|blank|pixel|clear\.gif|transparent\.gif/i.test(img.src) || (img.naturalWidth === 1 && img.naturalHeight === 1));
    if (spacers.length) out.push(bp({ ruleId: 'spacer-image', source: 'images',
      title: 'Spacer image used for layout', description: 'Use CSS for spacing. If a spacer image must stay, give it alt="".', nodes: nodesOf(spacers) }));
    return out;
  }

  // Long text right before or after a player (or the paragraph holding a media link) may be its transcript, or the
  // recording may be an alternative to that text: a person checks they say the same.
  function textNextTo(el) {
    const box = el.closest('p, li') || (el.parentElement && el.parentElement !== docRoot() && el.parentElement.children.length === 1 ? el.parentElement : el);
    return [box.previousElementSibling, box.nextElementSibling].some(s => s && isVisible(s) && !/^(audio|video)$/.test(s.localName) && itext(s).split(/\s+/).filter(Boolean).length >= 30);
  }
  // A video whose file has no sound needs no captions. Known only once its details have loaded, and only for files
  // from the page's own site (others can't be inspected).
  function silentVideo(v) {
    if (v.readyState < 1) return false;
    try { return v.captureStream().getAudioTracks().length === 0; } catch { return false; }
  }

  function mediaChecks() {
    const out = [];
    const videos = visibleAll('video').filter(v => !(v.muted && v.autoplay && !v.controls) && !v.querySelector('track[kind="captions"], track[kind="subtitles"]') && !silentVideo(v));
    const captionsIssue = (kind, list, summary) => wcagIssue('1.2.2', { ruleId: 'video-no-captions', source: 'media', kind, impact: 'critical', wcag: ['1.2.2'], level: 'A', version: '2.0',
      helpUrl: UNDERSTANDING + 'captions-prerecorded.html', title: 'Video has no captions track', description: 'Add captions (a <track kind="captions">) so deaf and hard-of-hearing people can follow the video.', nodes: nodesOf(list, summary) });
    const videosNearText = videos.filter(textNextTo);
    if (videos.length > videosNearText.length) out.push(captionsIssue('violation', videos.filter(v => !videosNearText.includes(v))));
    if (videosNearText.length) out.push(captionsIssue('unverified', videosNearText, 'The text next to this video may say the same as it. If it does, and the video is marked as an alternative to that text, captions aren’t needed.'));
    const audios = visibleAll('audio, embed[src$=".mp3" i], object[data$=".mp3" i]').filter(a => !/transcript/i.test(a.parentElement?.parentElement?.textContent || ''));
    // Audio next to a video may be that video's audio description, not a recording of its own.
    const audiosNear = audios.filter(a => textNextTo(a) || [a.previousElementSibling, a.nextElementSibling].some(s => s?.localName === 'video'));
    const transcriptIssue = (kind, list, summary) => wcagIssue('1.2.1', { ruleId: 'audio-no-transcript', source: 'media', kind, impact: 'serious', wcag: ['1.2.1'], level: 'A', version: '2.0',
      helpUrl: UNDERSTANDING + 'audio-only-and-video-only-prerecorded.html', title: 'Audio has no transcript', description: 'Provide a text transcript next to the audio player.', nodes: nodesOf(list, summary) });
    if (audios.length > audiosNear.length) out.push(transcriptIssue('violation', audios.filter(a => !audiosNear.includes(a))));
    if (audiosNear.length) out.push(transcriptIssue('unverified', audiosNear, 'The text or video next to this audio may be its transcript or what it describes. Check it says everything the audio does.'));
    return out;
  }

  // Hue names for colours that are clearly coloured (not greys).
  function hueName({ r, g, b }) {
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    if (max - min < 50) return null;
    let h;
    if (max === r) h = ((g - b) / (max - min)) % 6; else if (max === g) h = (b - r) / (max - min) + 2; else h = (r - g) / (max - min) + 4;
    h = (h * 60 + 360) % 360;
    return h < 20 || h >= 340 ? 'red' : h < 45 ? 'orange' : h < 70 ? 'yellow' : h < 170 ? 'green' : h < 260 ? 'blue' : 'purple';
  }

  // Groups of sibling items (list items, cells, tags) whose text colours differ while everything else about them looks
  // the same, on a page whose text names those colours. Each group is returned as the items that carry the colours.
  function colourCodedGroups() {
    const COLOUR_WORD = { red: 'red', green: 'green', blue: 'blue', orange: 'orange', yellow: 'yellow', amber: 'orange', purple: 'purple', violet: 'purple' };
    const words = new Set((pageText().toLowerCase().match(/\b(red|green|blue|orange|yellow|amber|purple|violet)\b/g) || []).map(w => COLOUR_WORD[w]));
    if (!words.size) return [];
    const look = el => { const cs = getComputedStyle(el); return [cs.fontWeight, cs.fontStyle, cs.textDecorationLine, cs.backgroundColor, cs.borderLeftStyle, cs.listStyleType, cs.fontSize].join('|'); };
    const groups = [];
    for (const parent of document.querySelectorAll('ul, ol, tr, tbody, dl, div, p')) {
      const items = [...parent.children].filter(el => isVisible(el) && el.textContent.trim() && !el.querySelector('img, svg, [class*="icon" i]'));
      if (items.length < 3 || items.length !== [...parent.children].filter(isVisible).length) continue;
      if (new Set(items.map(el => el.localName)).size !== 1 || new Set(items.map(look)).size !== 1) continue;
      const hues = items.map(el => hueName(parseColor(getComputedStyle(el).color) ?? { r: 0, g: 0, b: 0 }));
      const named = new Set(hues.filter(Boolean));
      if (named.size < 2 || ![...named].some(h => words.has(h))) continue;
      groups.push(items.filter((_, i) => hues[i]));
    }
    return groups;
  }

  function structureChecks() {
    const out = [];
    const bodySize = parseFloat(getComputedStyle(docRoot()).fontSize) || 16;
    // Text styled to look like a heading but not marked up as one.
    const fake = visibleAll('p, div, span').filter(el => !el.closest('[aria-live], [role="status"], [role="alert"], [role="log"]')).filter(el => {
      if (el.closest('h1, h2, h3, h4, h5, h6, label, button, a, th, legend, summary, [role="heading"], li, td') || el.children.length > 2) return false;
      const text = el.textContent.trim();
      if (!text || text.length > 80 || /[.:,;!?]$/.test(text) || el.querySelector('p, div')) return false;
      const strong = el.matches('b, strong') || (el.children.length === 1 && el.firstElementChild.matches('b, strong') && el.firstElementChild.textContent.trim() === text);
      const cs = getComputedStyle(el);
      const big = parseFloat(cs.fontSize) >= bodySize * 1.25 && parseInt(cs.fontWeight, 10) >= 600;
      const next = el.nextElementSibling;
      return (strong || big) && next && /^(p|ul|ol|div|table)$/.test(next.localName) && next.textContent.trim().length > 40;
    });
    if (fake.length) out.push(wcagIssue('1.3.1', { ruleId: 'fake-heading', source: 'structure', impact: 'moderate', kind: 'unverified',
      title: 'Text styled as a heading isn’t marked up as one', description: 'Bold or large text that introduces a section must be a real heading (<h2>, <h3>…) so screen-reader users can find and jump to it.', nodes: nodesOf(fake) }));
    // Lines that start with bullets or numbers, separated by <br>, instead of a real list.
    const fakeList = visibleAll('p, div, main, section, article, td, dd, blockquote').filter(el => el.querySelectorAll('br').length >= 1 && !el.querySelector('ul, ol, p, div') &&
      itext(el).split('\n').filter(l => /^\s*([-*•·–]|\d+[.)])\s+\S/.test(l)).length >= 2);
    if (fakeList.length) out.push(wcagIssue('1.3.1', { ruleId: 'fake-list', source: 'structure', impact: 'moderate',
      title: 'List isn’t marked up as a list', description: 'Use <ul> or <ol> for lists so screen readers announce how many items there are.', nodes: nodesOf(fakeList) }));
    // A long run of text with no headings or lists to break it up.
    const root = document.querySelector('main, [role="main"]') || docRoot();
    const words = [...root.querySelectorAll('p')].filter(isVisible).reduce((n, p) => n + itext(p).split(/\s+/).length, 0);
    if (words >= 300 && !root.querySelector('h2, h3, h4, ul, ol, [role="heading"]')) out.push(bp({ ruleId: 'wall-of-text', source: 'structure', impact: 'moderate', sesmag: facets('literacy'),
      title: 'Long text with no headings or lists', description: `About ${words} words with no sub-headings or lists. Break the content into sections with headings and use lists, so people can scan it.`, nodes: [nodeOf(root)] }));
    // Generic page title.
    const t = norm(document.title);
    if (t && (/^(untitled|untitled document|page title|new page|new document|document|home|index|page|title|test|default|welcome|my page|insert title here|title here|enter title here|page title here)$/.test(t) || t === location.hostname)) out.push(wcagIssue('2.4.2', {
      ruleId: 'generic-page-title', source: 'structure', impact: 'moderate', wcag: ['2.4.2'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'page-titled.html',
      title: 'Page title doesn’t describe the page', description: `The page title is "${document.title}". Give each page a title that says what it is, for example "Apply for a licence – City Services".`, nodes: [{ target: 'title', html: `<title>${document.title}</title>`, summary: '' }] }));
    // Text direction: right-to-left scripts need dir="rtl"; left-to-right text shouldn't be forced to rtl.
    const RTL = /[֐-ࣿיִ-﷿ﹰ-﻿]/g;
    const blocks = visibleAll('p, li, td, h1, h2, h3, h4, span, div').filter(el => !el.querySelector('p, li, div') && el.textContent.trim().length >= 15);
    const missingDir = blocks.filter(el => (el.textContent.match(RTL) || []).length >= 10 && getComputedStyle(el).direction !== 'rtl');
    const wrongDir = blocks.filter(el => getComputedStyle(el).direction === 'rtl' && !(el.textContent.match(RTL) || []).length && (el.textContent.match(/[A-Za-z]/g) || []).length >= 15);
    if (missingDir.length) out.push(wcagIssue('1.3.2', { ruleId: 'missing-dir', source: 'language', impact: 'serious', wcag: ['1.3.2'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'meaningful-sequence.html',
      title: 'Right-to-left text is shown left-to-right', description: 'Arabic, Hebrew or Urdu text needs dir="rtl" (and a lang attribute) so it reads and is spoken in the right order.', nodes: nodesOf(missingDir) }));
    if (wrongDir.length) out.push(wcagIssue('1.3.2', { ruleId: 'wrong-dir', source: 'language', impact: 'serious', wcag: ['1.3.2'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'meaningful-sequence.html',
      title: 'Left-to-right text is set to right-to-left', description: 'This text is in a left-to-right language but marked dir="rtl", so punctuation and order come out wrong. Remove the rtl direction.', nodes: nodesOf(wrongDir) }));
    // Instructions that rely on colour, shape or position.
    // Position and colour/shape references; "above"/"below" are left out because they are common in normal writing.
    const SENSORY = /\b(on|to|at) the (left|right)\b|\b(red|green|blue|yellow|orange|round|square|circular|triangular) (button|icon|link|box|square|circle|one|arrow)\b|\bin the (top|bottom)[- ](left|right)\b/i;
    const sensory = visibleAll('p, li, label, span, div').filter(el => !el.querySelector('p, li, div') && SENSORY.test(el.textContent));
    // A clear failure: the thing to act on is identified only by its look or place ("click the button on the right",
    // "press the green one"). An instruction that also names it ("select a state from the list on the left") passes
    // WCAG 1.3.3 (technique G96), so it goes to a person instead, like other mentions.
    const ONLY_SENSORY = /\b(?:click|press|select|tap|choose|use|pick|drag)\b[^.]{0,30}?\b(?:the|a|an)\s+(?:(?:red|green|blue|yellow|orange|grey|gray|round|square|big|small|circular|triangular)\s+)?(?:button|icon|link|box|arrow|one|item|option|image|picture|circle|square|shape)\b[^.]{0,25}?(?:\b(?:on|to|at|in) the (?:\w+ )?(?:left|right|top|bottom)\b|\b(?:above|below)\b)|\b(?:click|press|select|tap|choose|use|pick)\b[^.]{0,20}?\b(?:the|a|an)\s+(?:red|green|blue|yellow|orange|round|square|circular|triangular)\s+(?:button|icon|link|box|arrow|one|item|option|circle|square|shape)\b/i;
    // Text moved off the page (top: -9999em) is not seen, so it can't mislead anyone who looks.
    const onPage = el => { const r = el.getBoundingClientRect(); return r.bottom + scrollY > 0 && r.right + scrollX > 0; };
    // An instruction that names the control it means ("the button labelled Howdy", "the round button" for a button
    // called Round button) doesn't rely on its look (G96).
    const controlNames = visibleAll('button, a[href], input[type="submit"], input[type="button"], [role="button"], [role="link"]')
      .map(el => norm(accName(el) || el.value || '')).filter(n => n.length >= 3 && !/^(button|link|icon|one|item|option|arrow|box|here)$/.test(n));
    const wordsOf = t => ` ${norm(t).replace(/[^\p{L}\p{N}]+/gu, ' ')} `;
    const namesControl = el => { const t = wordsOf(el.textContent); return controlNames.some(n => t.includes(wordsOf(n))); };
    const instructions = sensory.filter(el => onPage(el) && ONLY_SENSORY.test(el.textContent) && !namesControl(el));
    const mentions = sensory.filter(el => onPage(el) && !instructions.includes(el) && !namesControl(el));
    const sensoryIssue = (kind, list, summary) => wcagIssue('1.3.3', { ruleId: 'sensory-instruction', source: 'content', kind, impact: 'moderate', wcag: ['1.3.3'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'sensory-characteristics.html',
      title: 'Instruction relies on colour, shape or position', description: 'Instructions like "click the green button" or "see the box on the right" fail people who can’t see the colour or layout. Also name the thing ("select Continue").', nodes: nodesOf(list.slice(0, 10), summary) });
    if (instructions.length) out.push(sensoryIssue('violation', instructions, 'An instruction that refers to colour, shape or position.'));
    if (mentions.length) out.push(sensoryIssue('unverified', mentions, 'Mentions colour, shape or position — check it isn’t the only way to identify something.'));
    // Abbreviations: the first use should be expanded. The text is read as written in the HTML (visible text nodes), so
    // words only shown in capitals by CSS ("End" styled uppercase) are not abbreviations; words in the page title are the
    // product's own name (DIGIT, HCM).
    const textNodes = [];
    for (const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); walker.nextNode() && textNodes.length < 4000;) {
      const n = walker.currentNode, el = n.parentElement;
      if (n.nodeValue.trim() && el && !el.closest('script, style, noscript, template') && isVisible(el)) textNodes.push(n);
    }
    const text = textNodes.map(n => n.nodeValue).join(' ').slice(0, 20000);
    const brand = new Set(document.title.match(/\b[A-Z]{2,6}\b/g) || []);
    // Also a name: in a logo or brand element, or right after "Powered by".
    for (const n of textNodes) {
      const brandish = n.parentElement.closest('[class*="brand" i], [class*="logo" i], [id*="brand" i], [id*="logo" i]');
      const after = brandish ? n.nodeValue : (n.nodeValue.match(/powered by\s+([A-Z]{2,6})\b/i)?.[1] ?? (/powered by\s*$/i.test(n.parentElement.parentElement?.textContent.split(n.nodeValue)[0] ?? '') ? n.nodeValue : ''));
      for (const w of after.match(/\b[A-Z]{2,6}\b/g) || []) brand.add(w);
    }
    const abbrs = [...new Set(text.match(/\b[A-Z]{2,6}s?\b/g) || [])].filter(a => !/^(OK|UK|US|USA|EU|PDF|FAQ|ID|TV|AM|PM|II|III|IV)$/.test(a) && !brand.has(a.replace(/s$/, '')));
    const expanded = new Set([...document.querySelectorAll('abbr[title], acronym[title]')].map(a => a.textContent.trim()));
    const unexpanded = abbrs.filter(a => !expanded.has(a) && !new RegExp(`\\(${a}\\)|${a} \\(`).test(text));
    // Each one shown where it first appears.
    const firstUse = a => textNodes.find(n => new RegExp(`\\b${a}\\b`).test(n.nodeValue))?.parentElement;
    if (unexpanded.length) out.push(bp({ ruleId: 'abbr-not-expanded', source: 'content', wcag: ['3.1.4'], level: 'AAA', version: '2.0',
      title: 'Abbreviations are not expanded', description: `Spell out abbreviations the first time they are used, or use <abbr title="…">: ${unexpanded.slice(0, 10).join(', ')}.`,
      nodes: unexpanded.slice(0, 10).map(a => nodeOf(firstUse(a) || root, `“${a}” is not spelled out.`)) }));
    return out;
  }

  function tableChecks() {
    const out = [];
    const tables = visibleAll('table').filter(t => !t.matches('[role="presentation"], [role="none"]'));
    const cellsOf = tr => [...tr.children].filter(c => c.matches('td, th'));
    const res = { noHeaders: [], onlyTh: [], complex: [], nested: [], irregular: [], noCaption: [], layout: [] };
    for (const t of tables) {
      const rows = [...t.rows];
      const cells = rows.flatMap(cellsOf);
      if (t.parentElement?.closest('table')) res.nested.push(t);
      const ths = cells.filter(c => c.localName === 'th' || c.matches('[role="columnheader"], [role="rowheader"]'));
      const looksLayout = !ths.length && (t.querySelector('table, form, h1, h2, h3, ul, ol') || rows.length < 2);
      if (looksLayout) { res.layout.push(t); continue; }
      if (cells.length >= 2 && ths.length === cells.length) { res.onlyTh.push(t); continue; }
      if (rows.length < 2 || Math.max(...rows.map(r => cellsOf(r).length)) < 2) continue;
      if (!ths.length) res.noHeaders.push(t);
      const grid = rows.map(() => new Set());
      // A rowspan reaches at most the end of its own section (thead / tbody / tfoot); rowspan="0" means exactly that.
      const sectionEnd = i => { let e = i; while (e + 1 < rows.length && rows[e + 1].parentElement === rows[i].parentElement) e++; return e + 1; };
      rows.forEach((r, i) => {
        let col = 0;
        for (const c of cellsOf(r)) {
          while (grid[i].has(col)) col++;
          const end = sectionEnd(i);
          const down = c.rowSpan === 0 ? end - i : Math.min(c.rowSpan || 1, end - i);
          for (let y = i; y < i + down; y++) for (let x = col; x < col + (c.colSpan || 1); x++) grid[y].add(x);
          col += c.colSpan || 1;
        }
      });
      const widths = grid.map(g => g.size);
      // Uneven widths, or body rows built from very different cell counts held together by large colspans.
      const bodyCounts = rows.filter(r => r.parentElement?.localName !== 'thead').map(r => cellsOf(r).length);
      if (new Set(widths).size > 1 || (new Set(bodyCounts).size > 1 && cells.some(c => c.colSpan > 2 && c.closest('tbody')))) res.irregular.push(t);
      // A header row may start with an empty corner cell.
      const headerRows = rows.filter(r => { const filled = cellsOf(r).filter(c => c.textContent.trim()); return filled.length && filled.every(c => c.localName === 'th'); }).length;
      const rowHeaders = rows.filter(r => cellsOf(r)[0]?.localName === 'th' && cellsOf(r).some(c => c.localName === 'td')).length;
      const unscoped = !ths.some(th => th.hasAttribute('scope')) && !cells.some(c => c.hasAttribute('headers'));
      // Two levels of row headers: rows that start with two or more header cells before their data.
      const doubleRowHeaders = rows.some(r => { const c = cellsOf(r); return c.length > 2 && c[0].localName === 'th' && c[1].localName === 'th' && c.some(x => x.localName === 'td'); });
      if ((headerRows >= 2 || doubleRowHeaders) && unscoped) res.complex.push(t);
      else if (headerRows >= 1 && rowHeaders >= 1 && unscoped) (res.scopeAdvice ??= []).push(t);
      if (ths.length && !t.querySelector('caption') && !t.getAttribute('aria-label') && !t.getAttribute('aria-labelledby')) res.noCaption.push(t);
    }
    if (res.noHeaders.length) out.push(wcagIssue('1.3.1', { ruleId: 'table-no-headers', source: 'tables', impact: 'serious',
      title: 'Data table has no header cells', description: 'Mark column and row headings with <th> so screen readers can tell people which heading each cell belongs to.', nodes: nodesOf(res.noHeaders) }));
    if (res.scopeAdvice?.length) out.push(bp({ ruleId: 'table-no-scope', source: 'tables',
      title: 'Table headers have no scope', description: 'Add scope="col" and scope="row" to header cells so every screen reader links each cell to the right headings.', nodes: nodesOf(res.scopeAdvice) }));
    if (res.onlyTh.length) out.push(bp({ ruleId: 'table-only-th', source: 'tables',
      title: 'Every cell in the table is a header', description: 'Use <th> only for headings and <td> for data, otherwise screen readers announce every cell as a heading.', nodes: nodesOf(res.onlyTh) }));
    if (res.complex.length) out.push(wcagIssue('1.3.1', { ruleId: 'complex-table', source: 'tables', impact: 'serious',
      title: 'Table with row and column headers has no scope', description: 'Tables with more than one level of headers need scope="col" / scope="row" (or headers/id) so each cell is linked to the right headings.', nodes: nodesOf(res.complex) }));
    if (res.nested.length) out.push(bp({ ruleId: 'nested-table', source: 'tables', impact: 'moderate',
      title: 'Table nested inside another table', description: 'Nested tables are very hard to follow with a screen reader. Flatten the data into one table or separate tables.', nodes: nodesOf(res.nested) }));
    if (res.irregular.length) out.push(bp({ ruleId: 'table-irregular', source: 'tables',
      title: 'Table rows have different numbers of columns', description: 'Uneven rows confuse screen-reader table navigation. Use colspan/rowspan correctly or restructure the table.', nodes: nodesOf(res.irregular) }));
    if (res.noCaption.length) out.push(bp({ ruleId: 'table-no-caption', source: 'tables',
      title: 'Data table has no caption', description: 'A <caption> (or aria-label) tells screen-reader users what a table is about before they enter it.', nodes: nodesOf(res.noCaption) }));
    if (res.layout.length) out.push(bp({ ruleId: 'layout-table', source: 'tables', impact: 'moderate',
      title: 'Table used for layout', description: 'Use CSS for layout. If a layout table must stay, add role="presentation" so it isn’t announced as a data table.', nodes: nodesOf(res.layout) }));
    return out;
  }

  function formChecks() {
    const out = [];
    const fields = visibleAll(FIELD_SEL);
    const groups = {};
    for (const el of visibleAll('input[type="radio"], input[type="checkbox"]')) if (el.name) (groups[`${el.type}|${el.name}`] ??= []).push(el);
    const loose = Object.values(groups).filter(g => g.length >= 2 && !g[0].closest('fieldset, [role="radiogroup"], [role="group"]')).map(g => g[0]);
    if (loose.length) out.push(wcagIssue('1.3.1', { ruleId: 'group-no-fieldset', source: 'forms', impact: 'moderate',
      title: 'Group of options isn’t grouped', description: 'Put related radio buttons or checkboxes in a <fieldset> with a <legend> (the question), so screen readers announce the question with each option.', nodes: nodesOf(loose) }));
    const noLegend = visibleAll('fieldset').filter(f => !f.querySelector('legend')?.textContent.trim());
    if (noLegend.length) out.push(wcagIssue('1.3.1', { ruleId: 'fieldset-no-legend', source: 'forms', impact: 'moderate',
      title: 'Fieldset has no legend', description: 'Every <fieldset> needs a <legend> that says what the group of fields is about.', nodes: nodesOf(noLegend) }));
    const byLabel = {};
    // Fields in sections under different headings ("Name" under Shipping and under Billing) are told apart by them.
    // Headings moved off the page don't tell sighted users which section a field is in.
    const formHeadings = visibleAll('h1, h2, h3, h4, h5, h6, [role="heading"]').filter(h => { const r = h.getBoundingClientRect(); return r.bottom + scrollY > 0 && r.right + scrollX > 0; });
    const headingBefore = f => formHeadings.filter(h => h.compareDocumentPosition(f) & Node.DOCUMENT_POSITION_FOLLOWING).pop();
    const groupName = f => { const g = f.closest('[role="group"], [role="radiogroup"]'); return norm(f.closest('fieldset')?.querySelector('legend')?.textContent || (g && accName(g)) || itext(headingBefore(f)) || ''); };
    for (const f of fields) { const l = norm(f.labels?.[0]?.textContent || f.getAttribute('aria-label')); if (l) (byLabel[`${l}|${groupName(f)}`] ??= []).push(f); }
    const dupes = Object.values(byLabel).filter(g => g.length > 1).flat();
    if (dupes.length) out.push(wcagIssue('2.4.6', { ruleId: 'duplicate-label', source: 'forms', impact: 'moderate', wcag: ['2.4.6'], level: 'AA', version: '2.0', helpUrl: UNDERSTANDING + 'headings-and-labels.html',
      title: 'Different fields have the same label', description: 'Fields with identical labels can’t be told apart by screen-reader users. Make each label unique ("Home phone", "Work phone").', nodes: nodesOf(dupes) }));
    const multi = fields.filter(f => f.labels?.length > 1);
    if (multi.length) out.push(wcagIssue('1.3.1', { ruleId: 'form-field-multiple-labels', source: 'forms', impact: 'moderate',
      title: 'Field has more than one label', description: 'Several <label for> point at the same field, so screen readers read only one of them (or both, confusingly). Give each field exactly one label; use a fieldset and legend for a group question like "Date of issue".', nodes: nodesOf(multi) }));
    const placeholderOnly = fields.filter(f => f.placeholder && !f.labels?.length && !f.getAttribute('aria-label') && !f.getAttribute('aria-labelledby') && !f.title);
    if (placeholderOnly.length) out.push(wcagIssue('3.3.2', { ruleId: 'placeholder-as-label', source: 'forms', impact: 'serious', wcag: ['3.3.2'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'labels-or-instructions.html',
      title: 'Placeholder used instead of a label', description: 'Placeholder text disappears when people type and is often low-contrast. Give every field a visible <label>.', nodes: nodesOf(placeholderOnly) }));
    const hints = visibleAll('[class*="hint" i], [class*="help-text" i], [class*="helptext" i], [class*="description" i], [class*="instruction" i]').filter(h => h.textContent.trim().length > 3 && !h.matches('label, legend') && !h.querySelector(FIELD_SEL));
    const describedIds = new Set([...document.querySelectorAll('[aria-describedby]')].flatMap(x => x.getAttribute('aria-describedby').split(/\s+/)));
    // Hints hidden from screen readers on purpose (aria-hidden, such as a visual "or press Enter") need no link.
    const unlinked = hints.filter(h => !h.closest('[aria-live], [role="status"], [role="alert"], [aria-hidden="true"]') && !(h.id && describedIds.has(h.id)) && !/required|marked with|all fields|\*/i.test(h.textContent)).filter(h => {
      // Text beside several fields ("Please use your credentials to log in.") describes the form, not one field.
      const inParent = h.parentElement ? [...h.parentElement.querySelectorAll(FIELD_SEL)].filter(isVisible) : [];
      const field = [h.nextElementSibling, h.previousElementSibling, inParent.length === 1 ? inParent[0] : null].find(x => x?.matches?.(FIELD_SEL));
      if (!field) return false;
      const ids = `${field.getAttribute('aria-describedby') || ''}`.split(/\s+/);
      return !ids.some(id => id && (h.id === id || h.contains(document.getElementById(id))));
    });
    if (unlinked.length) out.push(wcagIssue('1.3.1', { ruleId: 'hint-not-associated', source: 'forms', impact: 'moderate',
      title: 'Field hint isn’t connected to its field', description: 'Link hint text to its field with aria-describedby so screen readers read it when the field gets focus.', nodes: nodesOf(unlinked) }));
    const far = visibleAll('label[for]').filter(l => { const f = document.getElementById(l.htmlFor); if (!f || !isVisible(f)) return false; const a = l.getBoundingClientRect(), b = f.getBoundingClientRect(); return Math.abs(a.top - b.top) < 20 && b.left - a.right > 250; });
    if (far.length) out.push(bp({ ruleId: 'label-far-from-field', source: 'forms',
      title: 'Label is far from its field', description: 'A big gap between a label and its field makes the pair hard to match, especially when zoomed in. Put labels close to (or above) their fields.', nodes: nodesOf(far) }));
    // Errors shown only by colour, as already on the page.
    // Errors already shown on the page. Only the field's own area counts (its label, wrapper, aria-describedby) —
    // a page-level error summary doesn't say which field is wrong.
    const ERR_CLASS = /(^|\s|-)(has-)?errors?(\s|$)|invalid/i;
    // Angular marks untouched required fields ng-invalid before the user does anything: not an error yet.
    const pristine = f => /\bng-untouched\b/.test(f.className) && !/(^|\s)(is-invalid|has-errors?|error)(\s|$)/i.test(`${f.className} ${f.parentElement?.className || ''}`);
    // Only classes that apply now: utility "variants" such as aria-[invalid=true]:border-red-600 or invalid:ring describe
    // how an error would look and are on every field, error or not.
    const liveClasses = el => String(el?.className?.baseVal ?? el?.className ?? '').split(/\s+/).filter(t => t && !/[:[]/.test(t)).join(' ');
    const invalid = fields.filter(f => f.getAttribute('aria-invalid') === 'true' || (!pristine(f) && ERR_CLASS.test(`${liveClasses(f)} ${liveClasses(f.parentElement)}`)));
    // The label's own words (not an error message placed inside the label), so they can be told apart from error text.
    const labelWords = f => [...(f.labels || [])].flatMap(l => [...l.childNodes]
      .filter(c => c.nodeType === 3 || (c.nodeType === 1 && !/error|invalid/i.test(c.className) && !c.matches(FIELD_SEL))).map(c => c.textContent.trim()))
      .concat([f.getAttribute('aria-label'), f.getAttribute('placeholder')]).filter(Boolean);
    const withoutLabel = (text, f) => labelWords(f).reduce((t, w) => t.split(w).join(' '), text);
    const ownErrorText = f => {
      const describedBy = (f.getAttribute('aria-describedby') || '').split(/\s+/).map(id => document.getElementById(id)?.innerText || '').join(' ');
      const area = [f.closest('label'), f.parentElement].filter(a => a && !a.matches('form, fieldset, main, body')).map(a => a.innerText || '').join(' ');
      return `${describedBy} ${area}`;
    };
    const silent = invalid.filter(f => !ERR.test(withoutLabel(ownErrorText(f), f)) && !/is not|not valid|must|required|enter|check/i.test(withoutLabel(ownErrorText(f), f)));
    if (silent.length) out.push(wcagIssue('3.3.1', { wcag: ['3.3.1', '1.4.1'], ruleId: 'error-colour-only', source: 'forms', impact: 'serious',
      title: 'Form errors are shown only by colour or styling', description: 'These fields are marked as having an error but no error text explains what is wrong. Describe each error in text next to its field.', nodes: nodesOf(silent) }));
    // An error summary says something is wrong, but no field is marked or explained.
    for (const form of visibleAll('form')) {
      const summary = [...form.querySelectorAll('[role="alert"], [class*="summary" i], [class*="error" i]')].find(s => isVisible(s) && ERR.test(s.innerText) && !s.querySelector(FIELD_SEL));
      const formFields = [...form.querySelectorAll(FIELD_SEL)].filter(isVisible);
      if (summary && formFields.length && !formFields.some(f => invalid.includes(f) || ERR.test(ownErrorText(f)))) out.push(wcagIssue('3.3.1', {
        ruleId: 'error-not-identified', source: 'forms', impact: 'serious',
        title: 'Error summary doesn’t say which field is wrong', description: 'The form says there are errors but doesn’t mark or explain any field. Say which field has the problem and what it is, next to the field and in the summary (as links to the fields).',
        nodes: [nodeOf(summary, 'Error summary with no field marked.')] }));
    }
    // 3.3.3 on errors already on the page: does the message say how to fix it?
    // Error text: an error-styled element next to the field (it may sit inside the label), else the text left after the label.
    const errorText = f => {
      const near = [f.closest('label'), f.parentElement, ...(f.getAttribute('aria-describedby') || '').split(/\s+/).map(id => document.getElementById(id))]
        .filter(Boolean).flatMap(a => [a, ...a.querySelectorAll('[class*="error" i], [class*="invalid" i]')])
        .filter(e => e !== f && !e.matches(FIELD_SEL) && !e.querySelector(FIELD_SEL) && /error|invalid/i.test(e.className) && e.innerText?.trim());
      return near.length ? near[0].innerText : withoutLabel(ownErrorText(f), f);
    };
    const vagueErrors = invalid.filter(f => !silent.includes(f)).map(f => ({ f, text: errorText(f).replace(/\s+/g, ' ').trim() })).filter(e => e.text && !SUGGESTS.test(e.text));
    if (vagueErrors.length) out.push(wcagIssue('3.3.3', { ruleId: 'error-no-suggestion', source: 'forms', impact: 'moderate', wcag: ['3.3.3'], level: 'AA', version: '2.0',
      title: 'Error message doesn’t say how to fix the problem', description: 'Say what is expected, for example "Enter a phone number in the format 07123 456789", not only "is not valid".',
      nodes: vagueErrors.slice(0, MAX_NODES).map(e => nodeOf(e.f, `Error shown: “${e.text.slice(0, 80)}”`)) }));
    return out;
  }

  function otherChecks() {
    const out = [];
    const keyed = visibleAll('[accesskey]');
    if (keyed.length) out.push(bp({ ruleId: 'accesskey-used', source: 'keyboard-static', impact: 'moderate',
      title: 'accesskey shortcuts used', description: 'accesskey shortcuts clash with browser and screen-reader shortcuts and are not announced consistently. Remove them, or offer them only as a documented option.', nodes: nodesOf(keyed) }));
    // Links inside text that differ from it only by colour (no underline, border, weight or style).
    const textLinks = visibleAll('p a[href], li a[href], td a[href], dd a[href]').filter(a => {
      const block = a.closest('p, li, td, dd');
      const ownText = [...block.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join('').trim();
      if (ownText.length < 3) return false;
      const ls = getComputedStyle(a), bs = getComputedStyle(block);
      const decorated = /underline/.test(ls.textDecorationLine) || parseFloat(ls.borderBottomWidth) > 0 || parseInt(ls.fontWeight, 10) - parseInt(bs.fontWeight, 10) >= 300 || ls.fontStyle !== bs.fontStyle || ls.backgroundColor !== bs.backgroundColor;
      return !decorated;
    });
    if (textLinks.length) {
      const lc = textLinks.map(a => ({ a, r: contrastOf(parseColor(getComputedStyle(a).color) ?? { r: 0, g: 0, b: 0 }, parseColor(getComputedStyle(a.closest('p, li, td, dd')).color) ?? { r: 0, g: 0, b: 0 }) }));
      const weak = lc.filter(x => x.r < 3).map(x => x.a);
      if (weak.length) out.push(wcagIssue('1.4.1', { ruleId: 'link-colour-only', source: 'links', impact: 'serious', wcag: ['1.4.1'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'use-of-color.html',
        title: 'Links in text are shown by colour alone', description: 'These links are not underlined and their colour is too close to the text (under 3:1) to tell them apart. Underline links in text.', nodes: nodesOf(weak) }));
      const strong = lc.filter(x => x.r >= 3).map(x => x.a);
      // 3:1 or more against the text passes WCAG 1.4.1 only if the link also changes on hover and focus (technique G183):
      // a person checks that.
      if (strong.length) out.push(wcagIssue('1.4.1', { ruleId: 'link-colour-only-check', source: 'links', kind: 'unverified', impact: 'moderate', wcag: ['1.4.1'], level: 'A', version: '2.0', helpUrl: UNDERSTANDING + 'use-of-color.html',
        title: 'Links in text are shown by colour: check hover and focus', description: 'These links are not underlined. Their colour contrasts with the text by 3:1 or more, which passes WCAG 1.4.1 only if the link also changes when hovered and focused (for example an underline appears). Check each one, or underline links in text.', nodes: nodesOf(strong) }));
    }
    // Items told apart only by colour, when the text points to those colours ("the red ones will kill you").
    const colourOnly = colourCodedGroups();
    if (colourOnly.length) out.push(wcagIssue('1.4.1', { ruleId: 'colour-only-meaning', source: 'structure', impact: 'serious',
      title: 'Meaning is shown by colour alone',
      description: 'The text refers to these items by their colour, and nothing but the colour tells them apart. People who can’t see the colours (colour blindness, screen readers, high-contrast mode) can’t tell which is which. Add a word, icon or pattern as well.',
      nodes: nodesOf(colourOnly.flat(), 'Differs from the items next to it only by colour.') }));
    // Boxes of text that have to be scrolled sideways at normal size.
    const sideways = visibleAll('div, section, article, main').filter(el => /auto|scroll/.test(getComputedStyle(el).overflowX) && el.scrollWidth > el.clientWidth + 2 &&
      el.querySelector('p, li') && !el.querySelector('table, pre, code, canvas, img, svg, iframe'));
    if (sideways.length) out.push(bp({ ruleId: 'horizontal-scroll', source: 'reflow', impact: 'moderate', wcag: ['1.4.10'], level: 'AA', version: '2.1',
      title: 'Text has to be scrolled sideways', description: 'This box of text is wider than its container, so people must scroll sideways to read every line. Let text wrap to the container width.', nodes: nodesOf(sideways) }));
    const tab0 = visibleAll('[tabindex="0"]').filter(el => !el.matches('a[href], button, input, select, textarea, summary, [contenteditable], [role]') && !el.getAttribute('aria-label') && !el.querySelector(FOCUSABLE) && !el.matches('[onclick], [onkeydown]'));
    if (tab0.length) out.push(bp({ ruleId: 'tabindex-non-interactive', source: 'keyboard-static', impact: 'moderate',
      title: 'Focusable element that does nothing', description: 'tabindex="0" on plain text adds a tab stop with no role or action, which confuses keyboard and screen-reader users. Remove it, or make it a real control with a role and name.', nodes: nodesOf(tab0) }));
    const generated = [];
    for (const el of docRoot().querySelectorAll('*')) {
      for (const pseudo of ['::before', '::after']) {
        const c = getComputedStyle(el, pseudo).content;
        if (c && c !== 'none' && c !== 'normal' && /^["'].*["']$/.test(c) && (c.match(/\p{L}/gu) || []).length >= 3 && isVisible(el)) { generated.push(el); break; }
      }
    }
    if (generated.length) out.push(bp({ ruleId: 'css-generated-content', source: 'structure',
      title: 'Meaningful text is added with CSS', description: 'Text inserted with CSS ::before/::after may not be read by all screen readers and disappears without styles. Put meaningful text in the HTML.', nodes: nodesOf(generated) }));
    const ids = {};
    for (const el of document.querySelectorAll('[id]')) (ids[el.id] ??= []).push(el);
    const dup = Object.values(ids).filter(g => g.length > 1).map(g => g[1]);
    if (dup.length) out.push(bp({ ruleId: 'duplicate-id', source: 'html',
      title: 'Duplicate id values', description: 'ids must be unique; duplicates break label, aria-describedby and skip-link references.', nodes: nodesOf(dup) }));
    // Not spacers: paragraphs that aren't displayed, live regions, and slots script fills in later (an empty paragraph
    // with an id: error messages, dialog descriptions, result counts). Spacer paragraphs have none of these.
    const filledLater = p => p.matches('[role], [aria-live], [aria-atomic], [id]') || getComputedStyle(p).display === 'none';
    const emptyP = [...document.querySelectorAll('p')].filter(p => !p.textContent.replace(/ /g, '').trim() && !p.querySelector('img, svg, input, iframe, video, audio, canvas') && !filledLater(p));
    if (emptyP.length >= 1) out.push(bp({ ruleId: 'empty-paragraph', source: 'html',
      title: 'Empty paragraphs used for spacing', description: 'Screen readers may announce empty paragraphs as "blank". Use CSS margins for spacing.', nodes: nodesOf(emptyP) }));
    const deprecated = [...document.querySelectorAll('center, font, big, strike, tt, marquee, blink, frameset, basefont')];
    if (deprecated.length) out.push(bp({ ruleId: 'deprecated-element', source: 'html',
      title: 'Outdated HTML elements', description: 'Elements like <center> and <font> are obsolete. Use CSS for presentation.', nodes: nodesOf(deprecated) }));
    const pres = visibleAll('pre').filter(p => !p.querySelector('code') && p.textContent.trim().length > 0);
    if (pres.length) out.push(bp({ ruleId: 'pre-without-code', source: 'html',
      title: 'Preformatted text without code markup', description: 'Use <pre> for code (with <code> inside) or real tables for tabular data — ASCII art and spaced-out text are read character by character.', nodes: nodesOf(pres) }));
    const frames = visibleAll('iframe').filter(f => /^(iframe|frame|untitled|content|title|embed|widget|\d+|)$/i.test((f.title || '').trim()) && f.title !== undefined && f.hasAttribute('title'));
    if (frames.length) out.push(bp({ ruleId: 'iframe-generic-title', source: 'html', helpUrl: UNDERSTANDING + 'name-role-value.html',
      title: 'Frame title doesn’t describe its content', description: 'Give each iframe a title that says what it contains, for example "Map of the office location".', nodes: nodesOf(frames) }));
    if (document.documentElement.scrollWidth > document.documentElement.clientWidth + 2) {
      const vw = document.documentElement.clientWidth;
      const wide = [...docRoot().querySelectorAll('*')].filter(el => el.getBoundingClientRect().right > vw + 2 && !(el.parentElement && el.parentElement.getBoundingClientRect().right > vw + 2) && isVisible(el)).slice(0, 10);
      out.push(bp({ ruleId: 'horizontal-scroll', source: 'reflow', impact: 'moderate', wcag: ['1.4.10'], level: 'AA', version: '2.1',
        title: 'Page scrolls sideways at normal width', description: 'Content is wider than the window even before zooming. Make layouts fit the window width.', nodes: nodesOf(wide.length ? wide : [docRoot()]) }));
    }
    return out;
  }

  // Typography (AAA / best practice): all caps, justified, long italics, tight line height, long lines.
  function typographyChecks() {
    const out = [];
    const blocks = visibleAll('p, li, td, dd, blockquote').filter(el => el.textContent.trim().length > 60);
    const caps = visibleAll('p, li, h1, h2, h3, h4, span, td').filter(el => { const t = el.textContent.trim(); const s = getComputedStyle(el); return t.split(/\s+/).length >= 4 && t.length > 25 && (s.textTransform === 'uppercase' || (t === t.toUpperCase() && /[A-Z]{4}/.test(t))); });
    const justified = blocks.filter(el => getComputedStyle(el).textAlign === 'justify');
    const italics = blocks.filter(el => getComputedStyle(el).fontStyle === 'italic' && el.textContent.trim().length > 150);
    const tight = blocks.filter(el => { const s = getComputedStyle(el); const lh = parseFloat(s.lineHeight); return lh && lh < parseFloat(s.fontSize) * 1.2; });
    const long = blocks.filter(el => el.getBoundingClientRect().width / ((parseFloat(getComputedStyle(el).fontSize) || 16) * 0.5) > 100 && el.textContent.trim().length > 120);
    const add = (ruleId, list, title, description, sc) => list.length && out.push(bp({ ruleId, source: 'typography', ...(sc ? { wcag: [sc], level: 'AAA', version: '2.0' } : {}), title, description, nodes: nodesOf(list) }));
    add('text-all-caps', caps, 'Long text in capital letters', 'Words in all capitals are harder to read and some screen readers spell them out. Use normal case.');
    add('text-justified', justified, 'Justified text', 'Justified text creates uneven gaps between words that make reading harder for people with dyslexia. Align text to the left.', '1.4.8');
    add('text-long-italics', italics, 'Long passages in italics', 'Italic text is harder to read in long passages. Use italics only for short emphasis.');
    add('text-tight-line-height', tight, 'Lines of text are too close together', 'Use a line height of at least 1.5 for paragraphs.', '1.4.8');
    add('text-long-lines', long, 'Lines of text are very long', 'Lines longer than about 80 characters are hard to follow. Limit the width of text columns.', '1.4.8');
    return out;
  }

  // ── Material for AI review, review tasks and language detection ──

  const sentenceAround = el => {
    const block = el.closest('p, li, td, dd, figcaption, div') || el.parentElement;
    return (block?.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  };
  const docClip = el => { const r = el.getBoundingClientRect(); return r.width >= 8 && r.height >= 8 ? { x: r.left + scrollX, y: r.top + scrollY, width: Math.min(r.width, 1200), height: Math.min(r.height, 1200) } : null; };
  const informativeImages = () => visibleAll('img, [role="img"], input[type="image"]').filter(i => i.getAttribute('alt') !== '' && i.getAttribute('role') !== 'presentation' && i.getBoundingClientRect().width >= 24);

  function evidence() {
    const sensitive = visibleAll('form').filter(f => /card|cvv|payment|amount|account|ifsc|aadha?ar|\bpan\b|consent|agree|declar|sign/i.test(f.innerText + ' ' + [...f.querySelectorAll('input, select')].map(fieldLabel).join(' ')));
    const named = visibleAll('button, a[href], [role="button"]').filter(el => el.getAttribute('aria-label') && itext(el).trim());
    return {
      media: nodesOf(visibleAll('video, audio, iframe[src*="youtube"], iframe[src*="vimeo"], iframe[src*="player"]')),
      images: nodesOf(informativeImages()),
      links: nodesOf(visibleAll('a[href]')),
      headings: nodesOf(visibleAll('h1, h2, h3, h4, h5, h6, [role="heading"]')),
      labels: nodesOf(visibleAll('label, legend')),
      namedControls: nodesOf(named),
      sensitiveForms: nodesOf(sensitive),
      sensory: nodesOf(visibleAll('p, li, label').filter(el => /\b(left|right|above|below|red|green|round|square|colou?r)\b/i.test(el.textContent)).slice(0, 10)),
      foreignText: nodesOf(visibleAll('[lang]').filter(el => el !== document.documentElement)),
    };
  }

  function langBlocks() {
    const pageLang = document.documentElement.getAttribute('lang') || '';
    // Real prose only: short UI text (buttons, labels) is too short for reliable language detection.
    const ownText = el => {
      const copy = el.cloneNode(true);
      copy.querySelectorAll('[lang]').forEach(x => x.remove());
      return (copy.textContent || '').replace(/\s+/g, ' ').trim();
    };
    const blocks = visibleAll('p, li, blockquote, dd, td').filter(el => !el.querySelector('p, li') && ownText(el).length >= 50).map(el => {
      const own = el.closest('[lang]');
      return { text: ownText(el).slice(0, 500), pageLang, ownLang: own && own !== document.documentElement ? own.getAttribute('lang') : null, node: nodeOf(el) };
    });
    // Phrases checked on their own: passages marked with lang, and quotations inside prose (a French quote in English text).
    // A passage's text leaves out the parts inside it marked with their own lang (English phrases in a Dutch paragraph).
    const marked = visibleAll('[lang]').filter(el => el !== document.documentElement).map(el => [el, ownText(el)]).filter(([, t]) => t.length >= 12 && t.length < 500)
      .map(([el, text]) => ({ text, pageLang, ownLang: el.getAttribute('lang'), node: nodeOf(el), segment: true }));
    const quotes = visibleAll('p, li, blockquote').filter(el => !el.closest('[lang]:not(html)')).flatMap(el =>
      [...ownText(el).matchAll(/["“«„]([^"”»“]{15,200})["”»“]/g)].map(m => ({ text: m[1], pageLang, ownLang: null, node: nodeOf(el, `Quoted: “${m[1].slice(0, 60)}”`), segment: true })));
    return [...blocks, ...marked, ...quotes];
  }

  function aiCandidates() {
    const firstText = (document.querySelector('main, [role="main"]') || docRoot()).innerText.replace(/\s+/g, ' ').trim().slice(0, 300);
    // How many there are in all: the AI only judges the first few, so coverage is claimed only when it saw every one.
    const totals = {
      links: visibleAll('a[href]').filter(a => accName(a)).length,
      headings: visibleAll('h1, h2, h3, h4, [role="heading"]').length,
      labels: visibleAll(FIELD_SEL).length,
      sensory: visibleAll('p, li, label').filter(el => !el.querySelector('p, li') && /\b(left|right|above|below|top|bottom|red|green|blue|round|square|circle|colou?r|shape)\b/i.test(el.textContent)).length,
    };
    return {
      totals,
      images: informativeImages().map(el => ({ alt: el.getAttribute('alt') ?? el.getAttribute('aria-label') ?? '', context: sentenceAround(el), clip: docClip(el), node: nodeOf(el) })),
      links: visibleAll('a[href]').filter(a => accName(a)).map(a => ({ text: accName(a), href: a.getAttribute('href'), context: sentenceAround(a), node: nodeOf(a) })),
      headings: visibleAll('h1, h2, h3, h4, [role="heading"]').map(h => ({ text: itext(h).trim(), next: (h.nextElementSibling?.innerText || '').replace(/\s+/g, ' ').slice(0, 300), node: nodeOf(h) })),
      labels: visibleAll(FIELD_SEL).map(f => ({ label: fieldLabel(f), type: f.type || f.localName, placeholder: f.placeholder || '', node: nodeOf(f) })),
      title: { title: document.title, h1: document.querySelector('h1')?.innerText.trim() || '', text: firstText, node: { target: 'title', html: `<title>${document.title.slice(0, 200)}</title>`, summary: 'Page title' } },
      sensory: visibleAll('p, li, label').filter(el => !el.querySelector('p, li') && /\b(left|right|above|below|top|bottom|red|green|blue|round|square|circle|colou?r|shape)\b/i.test(el.textContent)).map(el => ({ text: itext(el).trim().slice(0, 400), node: nodeOf(el) })),
      paragraphs: visibleAll('p').filter(p => itext(p).trim().split(/\s+/).length >= 25).map(p => ({ text: itext(p).trim().slice(0, 600), node: nodeOf(p) })),
      ...agentCandidates(),
    };
  }

  // Candidates for the detection agent's judgement rules (BrowserStack-style: decorative image, missing / incorrect heading,
  // missing long description, accessible name, required role).
  function agentCandidates() {
    const bodySize = parseFloat(getComputedStyle(docRoot()).fontSize) || 16;
    const after = el => (el.nextElementSibling?.innerText || el.parentElement?.nextElementSibling?.innerText || '').replace(/\s+/g, ' ').slice(0, 300);
    const hidden = visibleAll('img[alt=""], img[role="presentation"], img[role="none"], svg[aria-hidden="true"]')
      .filter(i => { const r = i.getBoundingClientRect(); return r.width >= 48 && r.height >= 48; });
    const looksHeading = visibleAll('p, div, span, b, strong').filter(el => {
      if (el.closest('h1, h2, h3, h4, h5, h6, [role="heading"], label, button, a, th, legend, summary, nav, header, footer') || el.querySelector('p, div, li, img')) return false;
      const text = itext(el).trim();
      if (!text || text.length > 80 || text.length < 3) return false;
      const cs = getComputedStyle(el);
      return (parseFloat(cs.fontSize) >= bodySize * 1.2 || parseInt(cs.fontWeight, 10) >= 600) && after(el).length > 40;
    });
    // <div><b>Title</b></div>: keep one candidate per piece of text (the outermost).
    const outermost = looksHeading.filter(el => !looksHeading.some(o => o !== el && o.contains(el)));
    const headings = visibleAll('h1, h2, h3, h4, h5, h6').filter(h => { const t = itext(h).trim(); return t.split(/\s+/).length > 10 || /[.!]$/.test(t); });
    const COMPLEX = /chart|graph|diagram|map|infographic|flow|timeline|figure|plot|statistic/i;
    const complex = informativeImages().filter(i => {
      if (i.closest('figure')?.querySelector('figcaption') || i.getAttribute('aria-describedby') || i.getAttribute('longdesc') || i.closest('details')) return false;
      const r = i.getBoundingClientRect();
      return COMPLEX.test(`${i.getAttribute('alt')} ${i.getAttribute('src')} ${i.className}`) || (r.width >= 400 && r.height >= 250);
    });
    const iconOnly = visibleAll('button, a[href], [role="button"], [role="link"]').filter(el => !itext(el).trim() && el.querySelector('svg, img, i, span') && accName(el));
    const about = el => ({ html: snippet(el), context: sentenceAround(el), clip: docClip(el), node: nodeOf(el) });
    return {
      decorative: hidden.map(about),
      missingHeading: outermost.map(el => { const cs = getComputedStyle(el); return { text: itext(el).trim(), next: after(el), style: `${Math.round(parseFloat(cs.fontSize))}px, weight ${cs.fontWeight}`, node: nodeOf(el) }; }),
      incorrectHeading: headings.map(h => ({ text: itext(h).trim().slice(0, 300), level: h.localName[1], next: after(h), node: nodeOf(h) })),
      longAlt: complex.map(i => ({ alt: i.getAttribute('alt') ?? i.getAttribute('aria-label') ?? '', context: sentenceAround(i), clip: docClip(i), node: nodeOf(i) })),
      name: iconOnly.map(el => ({ ...about(el), name: accName(el) })),
    };
  }

  // The detection agent double-checks "looks clickable but no keyboard access" findings before they are reported.
  function roleCandidates(targets = []) {
    return targets.map(t => { let el; try { el = document.querySelector(t); } catch { el = null; } return el && isVisible(el) ? { target: t, html: snippet(el), context: sentenceAround(el), clip: docClip(el), node: nodeOf(el) } : null; }).filter(Boolean);
  }

  // stateOnly: a UI state reached by exploring — skip page-level checks (SESMag, signals).
  async function scan({ state = 'Page load', stateOnly = false } = {}) {
    clearOverlay();
    await Promise.race([Promise.all(document.getAnimations().map(a => a.finished.catch(() => {}))), sleep(2000)]);
    const started = performance.now();
    const axe = await runAxe({ measureContrast: stateOnly });
    const issues = axe.issues;
    issues.push(...authChecks(), ...draggingChecks(), ...targetSizeCheck(), ...mouseOnlyChecks(), ...positiveTabindex(), ...nonTextContrast(), ...gestureChecks(),
      ...linkChecks(), ...imageChecks(), ...mediaChecks(), ...tableChecks(), ...formChecks());
    if (!stateOnly) issues.push(...sesmagChecks(), ...structureChecks(), ...otherChecks(), ...typographyChecks());
    issues.forEach(i => { i.state = state; });
    return {
      url: location.href, title: document.title, issues,
      contrastPending: axe.contrastPending, axeSC: axe.axeSC,
      signals: stateOnly ? null : pageSignals(), evidence: stateOnly ? null : evidence(), langBlocks: stateOnly ? [] : langBlocks(),
      ms: Math.round(performance.now() - started),
    };
  }

  // ── Contrast measured from screenshots (panel takes the pictures) ──────────

  const C = { hidden: [] };

  // Entrance animations (a fade or slide-in on load) finish before contrast is measured from a screenshot, so text is
  // never judged half-faded. Endless animations are left running (the motion test handles them). At most maxMs.
  async function settleAnimations(maxMs = 3000) {
    const ending = document.getAnimations().filter(a => a.playState === 'running' && Number.isFinite(a.effect?.getComputedTiming?.().endTime));
    if (ending.length) await Promise.race([Promise.all(ending.map(a => a.finished.catch(() => {}))), new Promise(r => setTimeout(r, maxMs))]);
    return ending.length;
  }

  function contrastPrep(target) {
    let el;
    try { el = document.querySelector(target); } catch { return null; }
    if (!el || !isVisible(el)) return null;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    const range = document.createRange();
    range.selectNodeContents(el);
    const r = range.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return null;
    const cs = getComputedStyle(el);
    const size = parseFloat(cs.fontSize);
    const bold = parseInt(cs.fontWeight, 10) >= 700;
    // Fixed and sticky text (dialogs, bars) moves if the screenshot enlarges the page, so it is measured only when it is
    // fully on screen, where it is captured at the real window size (inView below).
    let pinned = false;
    for (let a = el; a && a !== document.documentElement; a = a.parentElement) {
      if (/fixed|sticky/.test(getComputedStyle(a).position)) { pinned = true; break; }
    }
    // Only the part that can be seen: a long code line inside a scrolling box runs past the box (and the page).
    // Boxes that really clip this text count: not html/body (their overflow belongs to the window), and for
    // positioned text only its containing boxes.
    let view = { left: -scrollX, top: -scrollY, right: document.documentElement.scrollWidth - scrollX, bottom: document.documentElement.scrollHeight - scrollY };
    let escapes = cs.position === 'absolute';
    for (let a = el.parentElement; a && a !== docRoot() && a !== document.documentElement; a = a.parentElement) {
      const s = getComputedStyle(a);
      // Boxes that hold positioned text: positioned ones, and those with a transform, filter, perspective or containment.
      const contains = !escapes || s.position !== 'static' || s.transform !== 'none' || s.filter !== 'none' || (s.backdropFilter || 'none') !== 'none' ||
        s.perspective !== 'none' || /transform|filter|perspective/.test(s.willChange) || /layout|paint|strict|content/.test(s.contain) || (s.containerType || 'normal') !== 'normal';
      if (contains && !(s.overflowX === 'visible' && s.overflowY === 'visible')) {
        const q = a.getBoundingClientRect();
        view = { left: Math.max(view.left, q.left), top: Math.max(view.top, q.top), right: Math.min(view.right, q.right), bottom: Math.min(view.bottom, q.bottom) };
      }
      if (contains) escapes = s.position === 'absolute';
    }
    // Text that wraps: one piece per line. The overall box would also take in neighbouring text (other code tokens
    // on those lines), which is not hidden and is not this text's background. Pieces on the same line are joined.
    const lines = [];
    for (const q of range.getClientRects()) {
      if (q.width < 1 || q.height < 1) continue;
      const line = lines.find(l => Math.min(l.bottom, q.bottom) - Math.max(l.top, q.top) > Math.min(l.bottom - l.top, q.height) / 2);
      if (line) Object.assign(line, { left: Math.min(line.left, q.left), top: Math.min(line.top, q.top), right: Math.max(line.right, q.right), bottom: Math.max(line.bottom, q.bottom) });
      else lines.push({ left: q.left, top: q.top, right: q.right, bottom: q.bottom });
    }
    const clips = lines.map(q => ({ left: Math.max(q.left, view.left), top: Math.max(q.top, view.top), right: Math.min(q.right, view.right), bottom: Math.min(q.bottom, view.bottom) }))
      .filter(q => q.right - q.left >= 1 && q.bottom - q.top >= 1)
      .map(q => ({ x: q.left + scrollX, y: q.top + scrollY, width: q.right - q.left, height: q.bottom - q.top }));
    if (!clips.length) return { unmeasurable: true };
    // On screen (it was just scrolled to the middle): captured at the real window size. Enlarging the window to capture
    // would re-lay-out pages sized to the screen height (a centred, screen-tall intro moves and its text grows).
    const inView = clips.every(c => c.y >= scrollY && c.y + c.height <= scrollY + innerHeight && c.x >= scrollX && c.x + c.width <= scrollX + innerWidth);
    if (pinned && !inView) return { unmeasurable: true };
    return {
      clips,
      inView,
      fg: toRgb(cs.color) || cs.color,
      large: size >= 24 || (bold && size >= 18.66),
    };
  }

  // Where the text is now (its first line, in page coordinates), without scrolling: to check it didn't move while its
  // background was being captured.
  function contrastWhere(target) {
    let el; try { el = document.querySelector(target); } catch { return null; }
    if (!el) return null;
    const range = document.createRange();
    range.selectNodeContents(el);
    const q = [...range.getClientRects()].find(r => r.width >= 1 && r.height >= 1);
    return q ? { x: q.left + scrollX, y: q.top + scrollY } : null;
  }

  // Make the element's text transparent so the screenshot shows only what is behind it.
  function contrastHide(target, hide) {
    if (!hide) {
      for (const [el, props] of C.hidden) for (const [p, v, prio] of props) v ? el.style.setProperty(p, v, prio) : el.style.removeProperty(p);
      C.hidden = [];
      return true;
    }
    const el = document.querySelector(target);
    if (!el) return false;
    clearOverlay();
    for (const n of [el, ...el.querySelectorAll('*')]) {
      const props = ['color', '-webkit-text-fill-color', 'text-shadow', 'text-decoration-color', 'caret-color'].map(p => [p, n.style.getPropertyValue(p), n.style.getPropertyPriority(p)]);
      C.hidden.push([n, props]);
      n.style.setProperty('color', 'transparent', 'important');
      n.style.setProperty('-webkit-text-fill-color', 'transparent', 'important');
      n.style.setProperty('text-shadow', 'none', 'important');
      n.style.setProperty('text-decoration-color', 'transparent', 'important');
      n.style.setProperty('caret-color', 'transparent', 'important');
    }
    return true;
  }

  // ── Keyboard walk (real Tab presses are sent by the side panel) ────────────

  const FOCUS_PROPS = ['outline-style', 'outline-width', 'outline-color', 'box-shadow', 'border-top-color', 'border-bottom-color', 'border-bottom-width', 'background-color', 'color', 'text-decoration-line', 'opacity', 'transform'];
  const W = { steps: [], marker: null, inFrame: 0, href: '' };

  function finishTransitions(el) {
    for (const a of el.getAnimations?.({ subtree: true }) || []) {
      if (a instanceof CSSTransition) try { a.finish(); } catch { /* finished already */ }
    }
  }

  // Styles a focus indicator can change: the element, its pseudo-elements,
  // its label and next sibling (custom checkboxes), and its parent (:focus-within).
  function focusStyle(el) {
    const label = el.labels?.[0];
    const targets = [[el, null], [el, '::before'], [el, '::after'], [el.parentElement, null], [el.nextElementSibling, null], [label, null]];
    return targets.filter(([n]) => n).map(([n, pseudo]) => {
      const cs = getComputedStyle(n, pseudo);
      return FOCUS_PROPS.map(p => cs.getPropertyValue(p)).join('|');
    }).join('#');
  }

  function isObscured(el, rect) {
    const root = el.getRootNode();
    const finder = root.elementFromPoint ? root : document;
    const pts = [[0.5, 0.5], [0.1, 0.1], [0.9, 0.1], [0.1, 0.9], [0.9, 0.9]]
      .map(([fx, fy]) => [rect.left + rect.width * fx, rect.top + rect.height * fy])
      .filter(([x, y]) => x >= 0 && y >= 0 && x < innerWidth && y < innerHeight);
    if (!pts.length) return false;
    return pts.every(([x, y]) => {
      const top = finder.elementFromPoint(x, y);
      if (!top || el.contains(top) || top.contains(el)) return false;
      if (el.labels && [...el.labels].some(l => l.contains(top))) return false;
      return inFixed(top);
    });
  }

  // Did CSS move this element away from its place in the HTML (flex/grid order or reverse; float: right on a line)?
  function cssReordered(el, { floats = false } = {}) {
    for (let n = el, i = 0; n && n !== docRoot() && i < 5; n = n.parentElement, i++) {
      const parent = n.parentElement;
      if (!parent) break;
      const ps = getComputedStyle(parent), ns = getComputedStyle(n);
      if (/flex|grid/.test(ps.display) && (ns.order !== '0' || /reverse/.test(ps.flexDirection))) return true;
      if (floats && ns.float === 'right') return true;
    }
    return false;
  }

  // Lets script-driven focus styles (a class added on focus) and transitions settle before reading styles.
  const settleFrame = () => Promise.race([new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))), sleep(100)]);

  async function inspectFocus(el) {
    // Focus inside a frame is drawn by the framed page, which we can't see from here.
    if (el.localName === 'iframe') return { visible: true, obscured: false, indicator: true, weak: false, frame: true, top: el.getBoundingClientRect().top + scrollY, left: el.getBoundingClientRect().left + scrollX, fixed: inFixed(el) };
    await settleFrame();
    finishTransitions(el);
    el.parentElement && finishTransitions(el.parentElement);
    const focused = focusStyle(el);
    let rect = el.getBoundingClientRect();
    const offScreen = r => r.bottom <= 0 || r.right <= 0 || r.top >= innerHeight || r.left >= innerWidth;
    // On a page that scrolls smoothly, the scroll to the focused element is still on its way: let it finish.
    for (let i = 0, y = scrollY; i < 12 && offScreen(rect); i++) {
      await sleep(100);
      rect = el.getBoundingClientRect();
      if (scrollY === y && i >= 2) break;
      y = scrollY;
    }
    // A link around a lazy-loaded image has no size until the image arrives, which it does once focus scrolls it in.
    const loading = [...el.querySelectorAll('img')].filter(i => !i.complete);
    if (loading.length && !isVisible(el)) {
      await Promise.race([Promise.all(loading.map(i => new Promise(r => { i.addEventListener('load', r, { once: true }); i.addEventListener('error', r, { once: true }); }))), sleep(1500)]);
      await settleFrame();
      rect = el.getBoundingClientRect();
    }
    // Content that loads as focus scrolls in (a lazy example frame above) can push a normal element back off screen.
    // One moved off screen on purpose (left: -9999px) can't be scrolled to; this one can.
    if (offScreen(rect) && isVisible(el)) {
      await sleep(300);
      el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
      await settleFrame();
      rect = el.getBoundingClientRect();
    }
    const label = el.labels?.[0];
    const shown = isVisible(el) || (label && isVisible(label));
    const onScreen = rect.bottom > 0 && rect.right > 0 && rect.top < innerHeight && rect.left < innerWidth;
    const visible = !!shown && (onScreen || (label && isVisible(label)));
    const obscured = visible && onScreen && isObscured(el, rect);
    el.blur();
    await settleFrame();
    finishTransitions(el);
    el.parentElement && finishTransitions(el.parentElement);
    const plain = focusStyle(el);
    const plainRect = el.getBoundingClientRect();
    const appears = !visuallyHiddenRect(plainRect) !== !visuallyHiddenRect(rect) || Math.abs(plainRect.top - rect.top) > 2 || Math.abs(plainRect.left - rect.left) > 2;
    el.focus({ preventScroll: true });
    // A hairline outline or a thinner border is technically a change but hard to see (WCAG 2.4.13, AAA).
    const f = getComputedStyle(el);
    const weak = focused !== plain && f.outlineStyle !== 'auto' && (f.outlineStyle === 'none' || parseFloat(f.outlineWidth) < 2) && f.boxShadow === 'none' &&
      FOCUS_PROPS.filter(p => !/outline|border/.test(p)).every(p => focused.split('#')[0].split('|')[FOCUS_PROPS.indexOf(p)] === plain.split('#')[0].split('|')[FOCUS_PROPS.indexOf(p)]);
    return { visible, obscured, indicator: focused !== plain || appears, weak: weak && !appears, top: rect.top + scrollY, left: rect.left + scrollX, fixed: inFixed(el) };
  }

  function walkReset() {
    clearOverlay();
    W.steps = [];
    W.inFrame = 0;
    W.href = location.href;
    // In an SVG file a focusable SVG group stands in for the span.
    const marker = document.body ? document.createElement('span') : document.createElementNS('http://www.w3.org/2000/svg', 'g');
    marker.tabIndex = -1;
    marker.setAttribute('data-ns-marker', '');
    docRoot().prepend(marker);
    window.scrollTo(0, 0);
    marker.focus({ preventScroll: true });
    W.marker = marker;
    return { tabbables: tabbables().length };
  }

  async function walkStep() {
    const el = deepActive();
    if (location.href !== W.href) return { done: true, reason: 'navigated' };
    if (el && el === W.marker) return { done: true, reason: 'stuck' };
    W.marker?.remove();
    W.marker = null;
    if (!el || el === docRoot() || el === document.documentElement) return { done: true, reason: 'end' };
    const last = W.steps[W.steps.length - 1];
    if (last && last.el === el && /^(iframe|audio|video)$/.test(el.localName)) {
      // Tab is moving through the frame's own content; we can't see inside it.
      return ++W.inFrame > 150 ? { done: true, reason: 'limit' } : { done: false, count: W.steps.length };
    }
    const seen = W.steps.findIndex(s => s.el === el);
    if (seen !== -1) return { done: true, reason: 'repeat', firstIndex: seen };
    W.steps.push({ el, ...await inspectFocus(el) });
    return { done: false, count: W.steps.length };
  }

  function walkFinish(end = { reason: 'limit' }) {
    const steps = W.steps;
    const issues = [];
    const nodes = (list, summary) => list.slice(0, MAX_NODES).map(s => nodeOf(s.el, summary));

    const noIndicator = steps.filter(s => s.visible && !s.indicator);
    if (noIndicator.length) issues.push(wcagIssue('2.4.7', {
      ruleId: 'focus-visible', source: 'keyboard', impact: 'serious',
      title: 'No visible focus indicator',
      description: 'When these elements receive keyboard focus nothing on screen changes, so keyboard users lose track of where they are. Add a clear :focus-visible style, for example a 2px outline with at least 3:1 contrast.',
      nodes: nodes(noIndicator, 'Reached with Tab — no visual change detected.'), total: noIndicator.length,
    }));

    const invisible = steps.filter(s => !s.visible);
    if (invisible.length) issues.push(wcagIssue('2.4.7', {
      ruleId: 'focus-invisible-element', source: 'keyboard', impact: 'serious',
      title: 'Keyboard focus lands on hidden elements',
      description: 'Tab stops on elements that are off-screen or invisible. Remove them from the tab order (tabindex="-1", hidden or inert) or make them appear when focused.',
      nodes: nodes(invisible, 'Focused but not visible on screen.'), total: invisible.length,
    }));

    const obscured = steps.filter(s => s.obscured);
    if (obscured.length) issues.push(wcagIssue('2.4.11', {
      ruleId: 'focus-obscured', source: 'keyboard', impact: 'serious',
      title: 'Focused element is hidden behind a sticky header, footer or banner',
      description: 'Add scroll padding (for example html { scroll-padding-top: <header height> }) or stop the overlay from covering focused content.',
      nodes: nodes(obscured, 'Entirely covered by a fixed or sticky element while focused.'), total: obscured.length,
    }));

    // Only order changes the author caused: positive tabindex or CSS reordering.
    const rtl = getComputedStyle(docRoot()).direction === 'rtl';
    const jumps = steps.filter((s, i) => i > 0 && !s.fixed && !steps[i - 1].fixed && (
      (s.top < steps[i - 1].top - 200 && (s.el.tabIndex > 0 || steps[i - 1].el.tabIndex > 0 || cssReordered(s.el) || cssReordered(steps[i - 1].el))) ||
      // Same line, but focus moves right-to-left on a left-to-right page (floats, row-reverse, absolute positioning).
      (!rtl && Math.abs(s.top - steps[i - 1].top) < 10 && s.left < steps[i - 1].left - 20 && (cssReordered(s.el, { floats: true }) || cssReordered(steps[i - 1].el, { floats: true })))));
    const weak = steps.filter(s => s.visible && s.weak);
    if (weak.length) issues.push(issue({
      ruleId: 'focus-indicator-weak', source: 'keyboard', impact: 'moderate', bestPractice: true, wcag: ['2.4.13'], level: 'AAA', version: '2.2',
      helpUrl: UNDERSTANDING + 'focus-appearance.html', title: 'Focus indicator is barely visible',
      description: 'Focus only changes a 1px outline or border, which is very hard to see. Use an outline of at least 2px with 3:1 contrast against the background.',
      nodes: nodes(weak, 'Focus changes only a hairline outline or border.'),
    }));
    if (jumps.length) issues.push(wcagIssue('2.4.3', {
      ruleId: 'focus-order-mismatch', source: 'keyboard', impact: 'serious', kind: 'unverified',
      title: 'Tab order does not follow the visual order',
      description: 'Positive tabindex values or CSS reordering (order, row-reverse) send focus back up the page. Remove positive tabindex and keep the DOM order the same as the visual order.',
      nodes: nodes(jumps, 'Focus moved here from an element further down the page.'), total: jumps.length,
    }));

    if (end.reason === 'repeat') {
      const cycle = steps.slice(end.firstIndex);
      const inModal = cycle.every(s => s.el.closest('dialog[open], [aria-modal="true"]'));
      // WCAG 2.1.2 allows another way out if the page tells people about it ("Press Ctrl+M to exit", or a "How to leave"
      // link in the cycle). The scanner can't tell whether that way works, so a person checks it.
      const EXIT_HINT = /\bpress\s+(ctrl|control|alt|shift|esc|escape|f\d+|the \w+ key)\b[^.]{0,30}\b(exit|leave|escape|quit|close|move on)\b|\bhow to (go|get|move|leave|exit)\b/i;
      const exitHint = EXIT_HINT.test(norm(pageText())) || cycle.some(s => EXIT_HINT.test(norm(accName(s.el))));
      // A single stop that Tab cannot leave is a trap too: focus never reaches the browser's own controls.
      if (!inModal && (end.firstIndex > 0 || cycle.length === 1 || cycle.length < tabbables().length * 0.8)) issues.push(wcagIssue('2.1.2', {
        ruleId: 'keyboard-trap', source: 'keyboard', impact: 'critical', kind: exitHint ? 'unverified' : 'violation',
        title: 'Keyboard trap: Tab keeps cycling through the same elements',
        description: 'Keyboard users cannot leave this group of elements. Unless it is a modal dialog, let Tab move on to the rest of the page.',
        nodes: nodes(cycle, exitHint ? 'Part of the repeating focus cycle. The page says how to leave it: check that way works.' : 'Part of the repeating focus cycle.'), total: cycle.length,
      }));
    }

    if (end.reason === 'stuck' && tabbables().length) issues.push(wcagIssue('2.1.1', {
      ruleId: 'keyboard-no-focus', source: 'keyboard', impact: 'critical',
      title: 'Pressing Tab does not reach any control',
      description: 'The page has focusable controls, but Tab never moves focus to them. Something on the page is blocking keyboard focus.',
      nodes: nodesOf(tabbables()),
    }));

    if (end.reason === 'navigated') issues.push(wcagIssue('3.2.1', {
      ruleId: 'focus-changes-context', source: 'keyboard', impact: 'serious',
      title: 'Moving focus opened a different page',
      description: 'Just tabbing onto a control changed the page. Focus alone must never navigate, submit or open new windows.',
      nodes: steps.length ? nodes(steps.slice(-1), 'Last control focused before the page changed.') : [],
    }));

    issues.forEach(i => { i.state = 'Keyboard walk'; });
    return { issues, stops: steps.length, total: tabbables().length, reason: end.reason };
  }

  // ── Reflow, text spacing, motion ───────────────────────────────────────────

  const REFLOW_EXEMPT = 'table, pre, code, canvas, svg, video, iframe, [role="grid"], [role="application"]';

  function scrollsSideways(el) {
    for (let p = el.parentElement; p && p !== docRoot(); p = p.parentElement) {
      if (/auto|scroll/.test(getComputedStyle(p).overflowX)) return true;
    }
    return false;
  }

  // 1.3.4: what the page shows in one orientation, so the panel can compare portrait with landscape.
  const ROTATE_MSG = /\b(rotate|turn) (your |the )?(device|phone|screen|tablet)\b|\b(portrait|landscape) (mode |orientation )?(only|required)\b|\bplease use (portrait|landscape)\b/i;
  function orientationProbe() {
    const words = (document.body?.innerText || '').split(/\s+/).filter(Boolean).length;
    const msg = visibleAll('div, section, p, span, h1, h2, h3, aside, dialog').find(el => ROTATE_MSG.test(itext(el) || '') && (itext(el) || '').length < 300);
    return { words, message: msg ? nodeOf(msg, `Shows: “${itext(msg).trim().slice(0, 120)}”`) : null };
  }

  // 1.4.10 also forbids losing content: text that fits at normal width but is cut off at 320px (a box with a fixed
  // height that gets narrower, so its text wraps onto more lines than it can show).
  const RF = { before: new Set() };
  function reflowBefore() { RF.before = new Set(clippedText()); return true; }

  function reflowCheck() {
    const cut = innermost(clippedText().filter(el => !RF.before.has(el) && !truncatedOnPurpose(el)));
    RF.before = new Set();
    return [...(cut.length ? [wcagIssue('1.4.10', {
      ruleId: 'reflow-text-clipped', source: 'reflow', impact: 'serious', state: 'Viewport 320px wide',
      title: 'Text is cut off at 320px width (400% zoom)',
      description: 'This text fits at normal width, but at 320px its box doesn’t grow with it and part of the text is hidden. Content must not be lost when the page is zoomed: avoid fixed heights and overflow: hidden on text containers.',
      nodes: nodesOf(cut, 'Text is clipped at 320px width.'),
    })] : []), ...sidewaysCheck()];
  }

  function sidewaysCheck() {
    const vw = Math.max(document.documentElement.clientWidth, innerWidth);
    if (document.documentElement.scrollWidth <= vw + 2) return [];
    const clippedAbove = el => { for (let p = el.parentElement; p && p !== docRoot(); p = p.parentElement) if (/hidden|clip|auto|scroll/.test(getComputedStyle(p).overflowX)) return true; return false; };
    const offenders = [];
    for (const el of docRoot().querySelectorAll('*')) {
      if (offenders.length >= MAX_NODES) break;
      const r = el.getBoundingClientRect();
      if (r.right <= vw + 2 || r.width === 0 || el.closest(REFLOW_EXEMPT) || el.closest(`#${OVERLAY_ID}`)) continue;
      const pr = el.parentElement?.getBoundingClientRect();
      if (pr && pr.right > vw + 2 && el.parentElement !== docRoot()) continue;
      if (scrollsSideways(el) || !isVisible(el) || clippedAbove(el)) continue;
      offenders.push(el);
    }
    if (!offenders.length) return []; // nothing on the page causes it (e.g. a scrollbar's width)
    return [wcagIssue('1.4.10', {
      ruleId: 'reflow-320', source: 'reflow', impact: 'serious', state: 'Viewport 320px wide',
      title: 'Page scrolls sideways at 320px width (400% zoom)',
      description: `At 320px the page is ${document.documentElement.scrollWidth}px wide. Content must fit without horizontal scrolling — use flexible widths, wrap long text and let layouts stack. Tables, maps and diagrams are exempt.`,
      nodes: nodesOf(offenders, 'Wider than the 320px viewport.'),
    })];
  }

  const S = { before: new Set() };

  function clippedText() {
    const out = [];
    for (const el of docRoot().querySelectorAll('*')) {
      const cs = getComputedStyle(el);
      const clipX = /hidden|clip/.test(cs.overflowX), clipY = /hidden|clip/.test(cs.overflowY);
      if (!clipX && !clipY) continue;
      if ((clipY && el.scrollHeight > el.clientHeight + 2) || (clipX && el.scrollWidth > el.clientWidth + 2)) {
        // Text hidden on purpose for screen readers (a 1px box, clip / clip-path) is never meant to be seen: it isn't
        // "cut off", even when a narrow layout first shows the menu it is in.
        if (el.textContent.trim() && isVisible(el) && !visuallyHidden(el) && textOutside(el)) out.push(el);
      }
    }
    return out;
  }
  // A box can be wider inside than it shows (a grid row with negative margins) without hiding anything: it counts
  // only when some of its text actually lies outside what it shows (screen-reader-only text aside).
  function textOutside(el) {
    const box = el.getBoundingClientRect();
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    const range = document.createRange();
    let n = 0;
    for (let t = walker.nextNode(); t && n < 400; t = walker.nextNode()) {
      if (!t.nodeValue.trim() || !t.parentElement || visuallyHidden(t.parentElement)) continue;
      n++;
      // Text in a scrolling box inside this one can be scrolled to: only the scrolling box itself has to fit.
      let scroller = null;
      for (let a = t.parentElement; a && a !== el; a = a.parentElement) if (/auto|scroll/.test(getComputedStyle(a).overflowY + getComputedStyle(a).overflowX)) scroller = a;
      if (scroller) range.selectNode(scroller); else range.selectNodeContents(t);
      for (const r of range.getClientRects()) {
        if (r.width && r.height && (r.right > box.right + 2 || r.bottom > box.bottom + 2 || r.left < box.left - 2 || r.top < box.top - 2)) return true;
      }
    }
    return false;
  }

  // Text cut short on purpose, with a visible sign that there is more (an ellipsis or a line clamp).
  const truncatedOnPurpose = el => { const cs = getComputedStyle(el); return cs.textOverflow === 'ellipsis' || (!!cs.webkitLineClamp && cs.webkitLineClamp !== 'none'); };

  function spacingBefore() { S.before = new Set(clippedText()); return true; }

  function spacingAfter() {
    const clipped = innermost(clippedText().filter(el => !S.before.has(el)));
    S.before = new Set();
    if (!clipped.length) return [];
    return [wcagIssue('1.4.12', {
      ruleId: 'text-spacing-clip', source: 'spacing', impact: 'serious', state: 'Increased text spacing',
      title: 'Text gets cut off when spacing is increased',
      description: 'With line height 1.5, letter spacing 0.12em, word spacing 0.16em and paragraph spacing 2em, this text is clipped. Avoid fixed heights and overflow: hidden on text containers.',
      nodes: nodesOf(clipped, 'Text is clipped with increased spacing.'),
    })];
  }

  // 1.4.4 — every piece of text made twice as big (like the browser's text-only zoom): text cut off by boxes that don't
  // grow with it. Text truncated on purpose (an ellipsis, a line clamp) and text already cut off before don't count.
  const Z = { before: new Set(), styled: [] };

  function resizeBefore() {
    Z.before = new Set(clippedText());
    // Every element, not just those holding text: a box sized in em grows with its text, as with the browser's text zoom.
    const els = [...docRoot().querySelectorAll('*')].filter(el => !el.closest(`#${OVERLAY_ID}`));
    const sizes = els.map(el => parseFloat(getComputedStyle(el).fontSize) || 16); // all read first: setting one changes its children
    Z.styled = els.map(el => [el, el.style.getPropertyValue('font-size'), el.style.getPropertyPriority('font-size'), el.hasAttribute('style')]);
    els.forEach((el, i) => el.style.setProperty('font-size', `${sizes[i] * 2}px`, 'important'));
    return true;
  }

  function resizeAfter() {
    const clipped = innermost(clippedText().filter(el => !Z.before.has(el) && !truncatedOnPurpose(el)));
    for (const [el, value, priority, hadStyle] of Z.styled) {
      if (value) el.style.setProperty('font-size', value, priority); else el.style.removeProperty('font-size');
      if (!hadStyle && !el.getAttribute('style')) el.removeAttribute('style');
    }
    Z.styled = [];
    Z.before = new Set();
    if (!clipped.length) return [];
    // A link right after the box to the whole text ("Full text of the poem") may be the way to read what is cut off.
    const fullTextLink = el => { const next = el.nextElementSibling; const a = next?.matches('a[href]') ? next : next?.querySelector(':scope > a[href]:only-child'); return !!a && /\b(full|whole|complete|entire|rest of|read more)\b/i.test(accName(a)); };
    const withLink = clipped.filter(fullTextLink);
    const clipIssue = (kind, list, summary) => wcagIssue('1.4.4', {
      ruleId: 'resize-text-clip', source: 'spacing', kind, impact: 'serious', state: 'Text at 200%',
      title: 'Text gets cut off when it is made twice as big',
      description: 'With every piece of text at twice its size (as when someone sets a larger text size), this text no longer fits its box and is cut off. Let boxes grow with their text: avoid fixed heights and overflow: hidden on text.',
      nodes: nodesOf(list, summary),
    });
    return [
      ...(clipped.length > withLink.length ? [clipIssue('violation', clipped.filter(el => !withLink.includes(el)), 'Text is clipped at 200% text size.')] : []),
      ...(withLink.length ? [clipIssue('unverified', withLink, 'Text is clipped at 200% text size. The link after it may show the whole text: check it does.')] : []),
    ];
  }

  const hasPause = el => [...el.querySelectorAll('button, [role="button"]')].some(b => /pause|stop|play/i.test(accName(b)));
  const CAROUSELS = 'marquee, [aria-roledescription="carousel" i], [class*="carousel" i], [class*="swiper" i], [class*="slick" i], [class*="slider" i]';

  // 2.2.2 part 1 (normal motion settings): watch carousels for 3s to see if they move by themselves.
  async function autoMoveCheck() {
    const carousels = outermost([...document.querySelectorAll(CAROUSELS)].filter(isVisible)).filter(el => !hasPause(el));
    if (!carousels.length) return [];
    const moved = new Set();
    const pos = el => [...el.querySelectorAll('*')].slice(0, 60).map(c => { const r = c.getBoundingClientRect(); return `${Math.round(r.left)},${Math.round(r.top)}`; }).join(';');
    const before = carousels.map(pos);
    const mo = new MutationObserver(list => list.forEach(m => carousels.forEach(c => c.contains(m.target) && moved.add(c))));
    carousels.forEach(c => mo.observe(c, { subtree: true, attributes: true, childList: true }));
    await sleep(3000);
    mo.disconnect();
    carousels.forEach((c, i) => { if (pos(c) !== before[i]) moved.add(c); });
    const autoMoving = carousels.filter(c => moved.has(c));
    if (!autoMoving.length) return [];
    return [wcagIssue('2.2.2', {
      ruleId: 'carousel-no-pause', source: 'motion', impact: 'serious', state: 'Watched for 3 seconds',
      title: 'Content moves by itself with no pause control',
      description: 'This carousel or scrolling area moved on its own while nobody touched the page. Anything that moves automatically for more than 5 seconds needs a visible Pause or Stop button.',
      nodes: nodesOf(autoMoving, 'Changed on its own within 3 seconds.'),
    })];
  }

  // 2.2.2 part 2 (with "reduce motion" on): endless animations that ignore it and can't be paused.
  function motionCheck() {
    const loops = [...new Set(document.getAnimations()
      .filter(a => a.playState === 'running' && a.effect?.getComputedTiming().iterations === Infinity)
      .map(a => a.effect.target)
      .filter(el => el && isVisible(el) && !/spin|load|progress/i.test(el.getAttribute('class') || '') && el.getAttribute('role') !== 'progressbar' && !el.closest('[aria-busy="true"]')))]
      .filter(el => !hasPause(el.parentElement || el));
    if (!loops.length) return [];
    return [wcagIssue('2.2.2', {
      ruleId: 'endless-animation', source: 'motion', impact: 'moderate', state: 'Reduced motion on',
      title: 'Endless animation with no way to stop it',
      description: 'These animations loop forever, even when the user has asked the system to reduce motion, and there is no pause button. Stop them after 5 seconds, add a pause control, or respect prefers-reduced-motion.',
      nodes: nodesOf(outermost(loops)),
    })];
  }

  // ── Explore UI states (open menus, tabs, dialogs; never navigate or submit) ─

  const DANGER = /\b(delete|remove|log[\s\-_]?out|sign[\s\-_]?out|submit|pay|purchase|buy|confirm|approve|reject|send|save|deactivate|unsubscribe|reset|discard|archive|cancel|publish|deploy|go[\s\-_]?live)\b/i;
  // The user's never-click list, remembered from the last test that passed it in (every test that presses things does).
  const NEVER = { re: /(?!)/ };
  const remember = words => { if (Array.isArray(words)) NEVER.re = neverRe(words); return NEVER.re; };
  const forbidden = el => DANGER.test(accName(el)) || NEVER.re.test(accName(el));
  const T = { triggers: [], active: null, dialogTriggers: new Set() };

  // ── Shared regions (side nav, header, footer) ─────────────────────────────
  // A whole-product scan tests each shared region once: it gets a fingerprint (its controls' names, numbers left
  // out), and on later pages a region with a fingerprint already tested is not pressed or clicked again, and its
  // issues are not repeated. A region that changed (new menu items) has a new fingerprint and is tested again.
  const SHARED_SEL = 'nav, header, footer, aside, [role="navigation"], [role="banner"], [role="contentinfo"], [role="complementary"], [role="menubar"], [class*="sidebar" i], [class*="sidenav" i], [class*="side-nav" i], [class*="topbar" i], [class*="navbar" i], [id*="sidebar" i]';
  const R = { skip: new Set(), fp: new WeakMap() };
  const sharedRegionOf = el => {
    let region = null;
    for (let box = el.closest?.(SHARED_SEL); box; box = box.parentElement?.closest(SHARED_SEL)) {
      // Not the page itself, nor a wrapper around the main content (<div class="sidebar-layout"> around everything).
      if (box === docRoot() || box === document.documentElement || box.querySelector('main, [role="main"], h1')) break;
      region = box; // the outermost shared box: a sub-menu belongs to its side nav
    }
    return region;
  };
  const regionFingerprint = region => {
    if (!R.fp.has(region)) {
      const names = [...new Set([...region.querySelectorAll('a, button, [role="menuitem"], [role="tab"], [role="link"], [role="button"], li, summary')]
        .map(c => (accName(c) || c.textContent || '').replace(/\s+/g, ' ').replace(/\d+/g, '#').trim().slice(0, 40)).filter(Boolean))].sort();
      R.fp.set(region, hashString(`${region.localName}|${region.getAttribute('role') || ''}|${names.join('|')}`));
    }
    return R.fp.get(region);
  };
  const inTestedRegion = el => { if (!R.skip.size) return false; const r = sharedRegionOf(el); return !!r && R.skip.has(regionFingerprint(r)); };
  const setSkipRegions = list => { R.skip = new Set(list || []); return R.skip.size; };
  const sharedRegions = () => [...new Set([...document.querySelectorAll(SHARED_SEL)].map(sharedRegionOf).filter(Boolean).map(regionFingerprint))];
  // Which shared region (fingerprint) each issue element is in, or null.
  const regionsOfTargets = targets => Object.fromEntries(targets.map(t => {
    let el = null;
    try { el = document.querySelector(t); } catch { /* not a selector */ }
    const r = el && sharedRegionOf(el);
    return [t, r ? regionFingerprint(r) : null];
  }));

  function safeToPress(el) {
    if (!isVisible(el) || el.disabled || el.getAttribute('aria-disabled') === 'true' || el.closest(`#${OVERLAY_ID}`)) return false;
    if (inTestedRegion(el)) return false; // shared side nav / header already tested on an earlier page
    if (el.localName === 'button' && (el.type === 'submit' || el.type === 'reset') && el.form) return false;
    if (el.localName === 'input' && /submit|reset|image/.test(el.type)) return false;
    return !forbidden(el);
  }

  function listTriggers({ max = Infinity, neverClick } = {}) {
    remember(neverClick);
    const sel = 'button, [role="button"], [aria-expanded], [aria-haspopup], [role="tab"], summary, [aria-controls], a[href="#"], a[href^="javascript:"]';
    const rank = el => (el.hasAttribute('aria-expanded') || el.hasAttribute('aria-haspopup') ? 0 : el.getAttribute('role') === 'tab' || el.localName === 'summary' ? 1 : 2);
    const found = [...document.querySelectorAll(sel)].filter(el => {
      const href = el.getAttribute('href');
      if (el.localName === 'a' && href && !/^(#|javascript:)/i.test(href)) return false;
      return safeToPress(el);
    }).sort((a, b) => rank(a) - rank(b)).slice(0, max);
    T.triggers = found;
    return found.map((el, index) => ({ index, label: accName(el) || el.localName }));
  }

  async function activate(index) {
    const el = T.triggers[index];
    if (!el || !el.isConnected || !isVisible(el)) return { changed: false, skipped: true };
    const href = location.href;
    const dialogsBefore = new Set(visibleDialogs());
    let changes = 0;
    const mo = new MutationObserver(list => {
      for (const m of list) if (!m.target.closest?.(`#${OVERLAY_ID}`)) changes++;
    });
    mo.observe(docRoot(), { subtree: true, childList: true, attributes: true, attributeFilter: ['aria-expanded', 'hidden', 'open', 'aria-hidden', 'aria-selected', 'class', 'style'] });
    T.active = { el, expandedBefore: el.getAttribute('aria-expanded') };
    el.click();
    await sleep(450);
    mo.disconnect();
    if (visibleDialogs().some(d => !dialogsBefore.has(d))) T.dialogTriggers.add(el);
    const hashRouter = /^#!?\//.test(new URL(href).hash);
    const navigated = hashRouter ? location.href !== href : stripHash(location.href) !== stripHash(href);
    if (!navigated && location.href !== href) history.replaceState(history.state, '', href);
    return { changed: changes > 0, navigated };
  }

  const CLOSE = /^\s*(close|dismiss|cancel|[×✕✖xX])(\s+(this\s+)?(dialog|window|modal|pop-?up|panel|menu|message|banner|overlay|notification|lightbox|drawer|sheet|tooltip|preview|image|video|search|filters?))?\s*$/i;
  // A control that is safe to press to close something: a plain close name, and never on a danger or never-click list.
  const closesSafely = el => {
    const name = accName(el) || el.getAttribute('title') || '';
    return CLOSE.test(name) && !NEVER.re.test(name) && !DANGER.test(name.replace(/^\s*cancel\s*$/i, ''));
  };

  async function closeDialog(dlg) {
    const esc = () => new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true });
    (document.activeElement || docRoot()).dispatchEvent(esc());
    document.dispatchEvent(esc());
    await sleep(250);
    if (!isVisible(dlg)) return;
    // Close controls are often links or spans ("X", title="Close"), not only buttons.
    const close = [...dlg.querySelectorAll('button, [role="button"], a, [class*="close" i], [title*="close" i], [aria-label*="close" i]')]
      .find(b => isVisible(b) && closesSafely(b));
    if (close) { close.click(); await sleep(250); }
  }

  async function restore() {
    const { el, expandedBefore } = T.active || {};
    T.active = null;
    if (!el) return true;
    if (el.isConnected && el.getAttribute('aria-expanded') === 'true' && expandedBefore !== 'true') {
      el.click();
      await sleep(250);
      return true;
    }
    const dlg = visibleDialogs()[0];
    if (dlg) await closeDialog(dlg);
    else {
      (document.activeElement || docRoot()).dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(200);
    }
    return true;
  }

  // ── Context-aware keyboard testing ─────────────────────────────────────────
  //
  // Each control is classified by what it is (skip link, tooltip, checkbox,
  // radio, tab, slider, toggle/menu/dialog trigger, dropdown, custom link) and
  // tested with the keys that kind of control must respond to; real buttons and links are pressed with their click
  // caught and cancelled (see patNative), so Next, Save or a link is proven to work without running. The panel
  // presses real keys; each test is an async generator that yields the next
  // keys it wants pressed and checks the result when resumed.

  const K = { items: [], gen: null, ctx: null, mo: null };
  const ROLE_PATTERN = { button: 'button', link: 'link', checkbox: 'checkbox', switch: 'checkbox', menuitemcheckbox: 'checkbox', radio: 'radio', tab: 'tab', slider: 'slider' };
  const PATTERN_RANK = { skip: 0, tooltip: 1, checkbox: 2, radio: 2, tab: 2, slider: 2, button: 3, select: 4, link: 5, native: 6 };

  function isNative(el, role) {
    if (role === 'button') return el.matches('button, input');
    if (role === 'link') return el.matches('a[href]');
    if (/checkbox|radio|switch|slider/.test(role)) return el.localName === 'input';
    return false;
  }

  // within: 'top' limits the test to the newest open dialog or pop-up (used while exploring).
  function kbdCandidates({ max = Infinity, within = 'page', neverClick } = {}) {
    remember(neverClick);
    const root = within === 'top' ? topLayer() : document;
    const items = [];
    const groups = new Set();
    const add = (el, pattern, extra = {}) => {
      if (items.some(i => i.el === el) || !safeToPress(el)) return;
      items.push({ el, pattern, label: accName(el) || el.localName, ...extra });
    };
    for (const a of root.querySelectorAll('a[href^="#"]')) {
      if (a.getAttribute('href').length > 1 && /skip|jump to|main content|मुख्य/i.test(accName(a))) add(a, 'skip');
    }
    for (const el of root.querySelectorAll('[aria-describedby]')) {
      const tip = document.getElementById(el.getAttribute('aria-describedby').split(/\s+/)[0]);
      if (tip && !isVisible(tip) && isVisible(el)) add(el, 'tooltip', { tip });
    }
    for (const el of root.querySelectorAll('[role]')) {
      const role = el.getAttribute('role');
      const pattern = ROLE_PATTERN[role];
      if (!pattern || isNative(el, role) || !isVisible(el)) continue;
      if (pattern === 'radio' || pattern === 'tab') {
        const group = el.closest(pattern === 'tab' ? '[role="tablist"]' : '[role="radiogroup"]') || el.parentElement;
        if (groups.has(group)) continue;
        groups.add(group);
        const members = [...group.querySelectorAll(`[role="${role}"]`)];
        add(el, pattern, { initialOn: members.find(m => m.getAttribute(pattern === 'tab' ? 'aria-selected' : 'aria-checked') === 'true') });
      } else add(el, pattern);
    }
    for (const el of root.querySelectorAll('[aria-expanded], [aria-haspopup], [data-toggle="modal"], [data-bs-toggle="modal"]')) add(el, 'button');
    if (root === document) for (const el of T.dialogTriggers) if (el.isConnected) add(el, 'button');
    for (const el of root.querySelectorAll('select:not([multiple])')) if (el.options.length > 1 && isVisible(el)) add(el, 'select');
    // Real buttons, all of them; real links, one per kind (same place and look), at most 12, since a page can have hundreds.
    for (const el of root.querySelectorAll('button, input[type="button"]')) add(el, 'native');
    const linkKinds = new Set();
    for (const el of root.querySelectorAll('a[href]')) {
      if (linkKinds.size >= 12 || !isVisible(el) || /^(mailto|tel|javascript):/i.test(el.getAttribute('href'))) continue;
      const kind = `${el.closest('header, nav, main, aside, footer, [role="navigation"], [role="banner"], [role="contentinfo"]')?.localName || 'body'}|${el.className}`;
      if (linkKinds.has(kind)) continue;
      const before = items.length;
      add(el, 'native');
      if (items.length > before) linkKinds.add(kind);
    }
    K.items = items.sort((a, b) => PATTERN_RANK[a.pattern] - PATTERN_RANK[b.pattern]).slice(0, max);
    return K.items.map((it, index) => ({ index, pattern: it.pattern, label: it.label }));
  }

  function snap(el) {
    const ctrl = controlled(el);
    return {
      expanded: el.getAttribute('aria-expanded'),
      checked: el.getAttribute('aria-checked') ?? (typeof el.checked === 'boolean' ? String(el.checked) : null),
      selected: el.getAttribute('aria-selected'),
      pressed: el.getAttribute('aria-pressed'),
      value: el.getAttribute('aria-valuenow') ?? (el.value ?? null),
      ctrlVisible: ctrl ? isVisible(ctrl) : null,
      dialogs: visibleDialogs().length,
      popups: visiblePopups().length,
      active: deepActive(),
    };
  }

  function makeCtx(item) {
    const el = item.el;
    const startHref = location.href;
    const hashRouter = /^#!?\//.test(location.hash);
    const c = {
      el, item, startHref, hashRouter, issues: [], muts: 0,
      initial: snap(el), before: snap(el), initialValue: el.value,
      dialogsBefore: new Set(visibleDialogs()), popupsBefore: new Set(visiblePopups()),
      press(key, ifNavigates) { c.before = snap(el); c.muts = 0; return { keys: [key], ifNavigates }; },
      changed() { return c.muts > 0 || c.stateChanged(); },
      stateChanged() {
        const now = snap(el);
        return ['expanded', 'checked', 'selected', 'pressed', 'value', 'ctrlVisible', 'dialogs', 'popups', 'active'].some(k => now[k] !== c.before[k]);
      },
      // The page changed after a key, but only somewhere else on the page: it counts only if the page then stays still
      // (a page still starting up, or a carousel turning, changes by itself).
      async keyActed() {
        if (!c.changed()) return false;
        if (c.stateChanged()) return true;
        c.muts = 0;
        await sleep(700);
        return c.muts === 0;
      },
      navigated() { return hashRouter ? location.href !== startHref : stripHash(location.href) !== stripHash(startHref); },
      newDialog() { return visibleDialogs().find(d => !c.dialogsBefore.has(d)); },
      newPopup() {
        const ctrl = controlled(el);
        if (ctrl && isVisible(ctrl) && !c.initial.ctrlVisible) return ctrl;
        return visiblePopups().find(p => !c.popupsBefore.has(p));
      },
      async clickWorks() {
        c.before = snap(el);
        c.muts = 0;
        el.click();
        await sleep(400);
        return c.changed();
      },
      issueFor(sc, ruleId, node, title, description, impact = 'serious') {
        return wcagIssue(sc, { ruleId, source: 'context', impact, title, description, state: 'Keyboard interaction test', nodes: [nodeOf(node, `Tested “${item.label}” as a ${item.pattern === 'native' ? (el.localName === 'a' ? 'link' : 'button') : item.pattern}.`)] });
      },
      fail(...args) { c.issues.push(c.issueFor(...args)); },
    };
    return c;
  }

  async function* followUp(c) {
    const dlg = c.newDialog();
    if (dlg) return yield* dialogChecks(c, dlg);
    const popup = c.newPopup();
    if (popup) return yield* popupChecks(c, popup);
  }

  async function* dialogChecks(c, dlg) {
    await sleep(150);
    const focusedIn = dlg.contains(deepActive());
    if (!focusedIn) c.fail('2.4.3', 'dialog-focus-not-moved', dlg, 'Focus stays behind the dialog when it opens',
      'When a dialog opens, move keyboard focus into it (to its first control or its heading). Otherwise keyboard and screen-reader users keep working on the page behind it.');
    // A modal (or a lightbox covering the page) must keep focus inside while it is open.
    const modal = dlg.matches('dialog:modal, [aria-modal="true"]') || (dlg.matches(OVERLAY_CLASSES) && !dlg.matches('[role="dialog"]:not([aria-modal="true"])'));
    // Lightboxes that don't move focus in: put focus inside ourselves, then check it stays there.
    if (modal && !focusedIn) [...dlg.querySelectorAll(FOCUSABLE)].find(el => el.tabIndex >= 0 && isVisible(el))?.focus();
    if (modal && dlg.contains(deepActive())) {
      const stops = [...dlg.querySelectorAll(FOCUSABLE)].filter(el => el.tabIndex >= 0 && isVisible(el)).length;
      for (let i = 0; i <= stops; i++) {
        yield c.press('Tab');
        if (!isVisible(dlg)) break;
        // Escaping means reaching the page behind. Past the last control, a modal dialog lets focus go to the
        // browser's own controls (the address bar): the page reports that as the body, and it is allowed.
        const at = deepActive();
        if (!at || at === docRoot() || at === document.documentElement) continue;
        if (!dlg.contains(at)) {
          c.fail('2.4.3', 'dialog-focus-escapes', dlg, 'Focus leaves the open dialog',
            'While this dialog covers the page, Tab moves focus to the page behind it, which people cannot see. Keep focus inside the dialog until it is closed.');
          break;
        }
      }
    }
    yield c.press('Escape');
    if (isVisible(dlg)) c.issues.push(issue({
      ruleId: 'dialog-no-escape', source: 'context', impact: 'moderate', bestPractice: true, state: 'Keyboard interaction test',
      title: 'Escape doesn’t close the dialog', description: 'Keyboard users expect Escape to close a dialog or lightbox. Close it on Escape (and return focus to what opened it).',
      nodes: [nodeOf(dlg, 'Still open after pressing Escape.')],
    }));
    if (isVisible(dlg)) {
      // Escape didn't close it: can the keyboard reach a close button?
      let closed = false;
      for (let i = 0; i < 25 && !closed; i++) {
        yield c.press('Tab');
        const a = deepActive();
        if (!dlg.contains(a)) {
          if (dlg.matches('dialog[open], [aria-modal="true"]')) continue;
          return; // non-modal: focus can leave, so it is not a trap
        }
        if (closesSafely(a)) {
          yield c.press('Enter');
          closed = !isVisible(dlg);
          break;
        }
      }
      if (!closed) {
        c.fail('2.1.2', 'dialog-no-keyboard-close', dlg, 'Dialog can’t be closed with the keyboard',
          'Neither Escape nor a reachable Close button closes this dialog, so keyboard users are stuck in it. Close it on Escape and give it a focusable Close button.', 'critical');
        return;
      }
    }
    await sleep(150);
    const a = deepActive();
    if (!a || a === docRoot() || a === document.documentElement) c.fail('2.4.3', 'dialog-focus-lost', c.el, 'Focus is lost when the dialog closes',
      'After the dialog closes, focus falls back to the top of the page. Send focus back to the control that opened the dialog.');
  }

  async function* popupChecks(c, popup) {
    const items = [...popup.querySelectorAll('[role="menuitem"], [role="menuitemcheckbox"], [role="menuitemradio"], [role="option"], [role="treeitem"], a[href], button')].filter(isVisible);
    if (!items.length) return;
    if (!popup.contains(deepActive())) yield c.press('ArrowDown');
    const reachable = popup.contains(deepActive()) || items.some(i => i.tabIndex >= 0) || !!c.el.getAttribute('aria-activedescendant');
    if (!reachable) c.fail('2.1.1', 'popup-items-unreachable', popup, 'Menu or list opens but its options can’t be reached with the keyboard',
      'After opening, Arrow keys should move into the options (or each option must be reachable with Tab).');
    yield c.press('Escape');
  }

  async function* patButton(c) {
    const link = c.item.pattern === 'link';
    // Anything announced as a button must also work with Space, not just Enter (links with role="button" often don't).
    if (!link && c.el.getAttribute('role') === 'button') {
      // Space that makes the control's click works, even when the page it opens hasn't loaded yet (a slow site): the
      // control acts on that click. A button that ignores Space never gets one.
      let clicked = 0;
      const onClick = e => { if (e.target === c.el || c.el.contains(e.target)) clicked++; };
      addEventListener('click', onClick, true);
      try {
        yield c.press('Space');
      } finally { removeEventListener('click', onClick, true); }
      if (clicked || c.navigated()) return;
      if (await c.keyActed()) return yield* followUp(c);
      // A busy page may still be acting on it (opening the next page) or missed the key: wait, then focus it again and
      // press Space once more before deciding that only Enter works. Not focusable again: not reported.
      await sleep(600);
      if (c.navigated()) return;
      if (await c.keyActed()) return yield* followUp(c);
      c.el.focus();
      if (deepActive() !== c.el) return;
      yield c.press('Space');
      if (c.navigated()) return;
      if (await c.keyActed()) return yield* followUp(c);
      await sleep(600);
      if (c.navigated()) return;
      if (await c.keyActed()) return yield* followUp(c);
      const fail = c.issueFor('2.1.1', 'role-button-no-space', c.el, 'Button doesn’t work with the Space key',
        `“${c.item.label}” is announced as a button but does nothing when Space is pressed. Buttons must respond to both Enter and Space — use a native <button>, or handle Space.`, 'serious');
      yield c.press('Enter', fail);
      if (c.navigated() || c.changed()) { c.issues.push(fail); if (!c.navigated()) yield* followUp(c); return; }
    } else {
      yield c.press('Enter');
      if (c.navigated()) return;
      if (c.changed()) return yield* followUp(c);
      if (!link) {
        yield c.press('Space');
        if (c.navigated()) return;
        if (c.changed()) return yield* followUp(c);
      }
    }
    // A busy page can miss a key press, or its scripts were still starting: focus it again and try once more before
    // blaming it. When it can't be focused again, the keyboard was never really tried, so nothing is reported.
    await sleep(500);
    if (!c.el.isConnected) return;
    c.el.focus();
    if (deepActive() !== c.el) return;
    yield c.press('Enter');
    if (c.navigated()) return;
    if (c.changed()) return yield* followUp(c);
    if (!link) {
      yield c.press('Space');
      if (c.navigated()) return;
      if (c.changed()) return yield* followUp(c);
    }
    const fail = c.issueFor('2.1.1', 'mouse-only-activation', c.el, 'Works with a mouse but not with the keyboard',
      `“${c.item.label}” responds to a click but not to ${link ? 'Enter' : 'Enter or Space'}. Handle keyboard activation — a native ${link ? '<a href>' : '<button>'} does this for free.`, 'critical');
    yield { keys: [], ifNavigates: fail }; // the click below may open another page
    if (await c.clickWorks()) c.issues.push(fail);
  }

  async function* patCheckbox(c) {
    yield c.press('Space');
    if (c.changed()) return;
    if (await c.clickWorks()) c.fail('2.1.1', 'toggle-no-space', c.el, 'Checkbox or switch can’t be toggled with Space',
      'It toggles on click but not with the Space key. Handle Space (or use a native <input type="checkbox">).', 'critical');
  }

  async function* patRadio(c) {
    const group = [...(c.el.closest('[role="radiogroup"]') || c.el.parentElement).querySelectorAll('[role="radio"]')].filter(isVisible);
    if (group.length < 2) return;
    yield c.press('Space');
    if (c.el.getAttribute('aria-checked') !== 'true' && !c.changed() && await c.clickWorks()) c.fail('2.1.1', 'radio-no-space', c.el,
      'Radio option can’t be selected with Space', 'It is selected on click but not with the Space key. Handle Space (or use native radio inputs).', 'critical');
    c.el.focus();
    yield c.press('ArrowDown');
    const a = deepActive();
    if (group.includes(a) && a !== c.el) return;
    if (group.some(r => r !== c.el && r.tabIndex >= 0)) return;
    c.fail('2.1.1', 'radio-group-unreachable', group[1], 'Other options in this radio group can’t be reached with the keyboard',
      'Arrow keys should move between options, or each option must be reachable with Tab.', 'critical');
  }

  async function* patTab(c) {
    const tabs = [...(c.el.closest('[role="tablist"]') || c.el.parentElement).querySelectorAll('[role="tab"]')].filter(isVisible);
    if (tabs.length < 2) return;
    c.el.focus();
    yield c.press('ArrowRight');
    let other = deepActive();
    if (!tabs.includes(other) || other === c.el) {
      other = tabs.find(t => t !== c.el && t.tabIndex >= 0);
      if (!other) return c.fail('2.1.1', 'tabs-unreachable', tabs.find(t => t !== c.el), 'Other tabs can’t be reached with the keyboard',
        'Arrow keys should move between tabs, or each tab must be reachable with Tab.', 'critical');
      other.focus();
    }
    if (other.getAttribute('aria-selected') === 'true') return; // tabs activate as focus moves
    yield c.press('Enter');
    if (other.getAttribute('aria-selected') === 'true') return;
    yield c.press('Space');
    if (other.getAttribute('aria-selected') === 'true') return;
    other.click();
    await sleep(300);
    if (other.getAttribute('aria-selected') === 'true') c.fail('2.1.1', 'tab-no-activation', other, 'Tab can’t be opened with Enter or Space',
      'The tab opens on click but not from the keyboard. Activate tabs on Enter and Space.', 'critical');
  }

  async function* patSlider(c) {
    c.el.focus();
    yield c.press('ArrowRight');
    if (c.changed()) { yield c.press('ArrowLeft'); return; }
    yield c.press('ArrowLeft');
    if (c.changed()) { yield c.press('ArrowRight'); return; }
    c.fail('2.1.1', 'slider-no-arrows', c.el, 'Slider can’t be changed with the arrow keys',
      'Arrow keys must change the slider value (Home/End for min/max are recommended too).', 'critical');
  }

  async function* patSkip(c) {
    const id = decodeURIComponent(c.el.getAttribute('href').slice(1));
    const target = document.getElementById(id) || document.querySelector(`[name="${CSS.escape(id)}"]`);
    if (!target) return c.fail('2.4.1', 'skip-link-broken', c.el, 'Skip link points to something that doesn’t exist',
      `The skip link goes to “#${id}”, but there is no element with that id. Point it at the main content.`);
    if (c.hashRouter) return;
    // A target already on screen at the bottom of the page can't be scrolled any higher: the browser has jumped as far
    // as it can (short pages), and the next Tab starts from there.
    const atEnd = () => { const r = target.getBoundingClientRect(); return scrollY + innerHeight >= document.documentElement.scrollHeight - 2 && r.top >= 0 && r.bottom <= innerHeight; };
    const jumped = y => target.contains(deepActive()) || Math.abs(target.getBoundingClientRect().top) <= 150 || scrollY !== y || atEnd();
    const y0 = scrollY;
    yield c.press('Enter');
    await sleep(150);
    let ok = jumped(y0);
    // Missed key press (a busy page) or the page's scripts were still starting: once more, focused again, before failing.
    if (!ok) {
      await sleep(500);
      c.el.focus();
      if (deepActive() !== c.el) return; // can't be tried again: not reported
      const y1 = scrollY;
      yield c.press('Enter');
      await sleep(150);
      ok = jumped(y1);
    }
    if (!ok) c.fail('2.4.1', 'skip-link-no-effect', c.el, 'Skip link does nothing',
      'Pressing Enter on the skip link did not move focus or scroll to the main content. Make the target focusable (tabindex="-1") and check nothing cancels the jump.');
  }

  async function* patTooltip(c) {
    await sleep(400);
    if (!isVisible(c.item.tip)) return; // nothing appears on focus
    yield c.press('Escape');
    await sleep(150);
    if (isVisible(c.item.tip)) c.fail('1.4.13', 'tooltip-no-dismiss', c.el, 'Pop-up text shown on focus can’t be dismissed',
      'Content that appears on focus or hover must close when Escape is pressed, without moving focus.');
  }

  async function* patSelect(c) {
    const fail = c.issueFor('3.2.2', 'select-changes-page', c.el, 'Choosing an option immediately changes the page',
      'Selecting an option opened another page or submitted the form by itself. Let people choose first, then press a Go / Apply button.');
    yield c.press('ArrowDown', fail);
    await sleep(200);
    if (c.navigated()) c.issues.push(fail);
  }

  // Real buttons and links: the browser turns Enter (and Space on a button) into a click unless the page blocks the
  // keys, or acts on the mouse press itself (which no key makes). Both are checked with the control's click caught and
  // cancelled, so Next, Save or a link does not actually run.
  async function* patNative(c) {
    const link = c.el.localName === 'a';
    const kind = link ? 'link' : 'button';
    let clicks = 0;
    const cancel = e => { if (e.target === c.el || c.el.contains(e.target)) { clicks++; e.preventDefault(); e.stopImmediatePropagation(); } };
    // Changes outside the control (its own ripple or pressed look don't count), or its expanded / pressed state.
    let outside = 0;
    const changed = new Set();
    const mo = new MutationObserver(list => { for (const m of list) if (!m.target.closest?.(`#${OVERLAY_ID}`) && (!c.el.contains(m.target) || /^aria-(expanded|pressed)$/.test(m.attributeName || ''))) { outside++; changed.add(m.target); } });
    const watch = () => { outside = 0; changed.clear(); mo.observe(docRoot(), { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: [...STATE_ATTRS, 'style', 'class'] }); };
    const unwatch = () => { mo.takeRecords(); mo.disconnect(); return outside > 0 || visibleDialogs().length !== c.dialogsBefore.size; };
    addEventListener('click', cancel, true);
    try {
      watch();
      yield c.press('Enter');
      if (!clicks && !link) yield c.press('Space');
      // A busy page can miss a key press: focus it again and try once more before blaming it.
      if (!clicks) {
        await sleep(500);
        if (!c.el.isConnected) return unwatch();
        c.el.focus();
        if (deepActive() !== c.el) return unwatch();
        yield c.press('Enter');
        if (!clicks && !link) yield c.press('Space');
      }
      const keysActed = unwatch();
      if (!clicks && !keysActed) {
        c.fail('2.1.1', 'native-keys-blocked', c.el, `${link ? 'Link' : 'Button'} doesn’t respond to ${link ? 'Enter' : 'Enter or Space'}`,
          `“${c.item.label}” is a real ${kind}, but pressing ${link ? 'Enter' : 'Enter or Space'} on it does nothing: the page stops the key${link ? '' : 's'}. Remove the keydown handler that cancels ${link ? 'Enter' : 'Enter and Space'}.`, 'critical');
        return;
      }
      if (link || keysActed) return;
      // Clicks still cancelled: press and release a mouse button on it. Anything that happens now happens on the press,
      // which the keyboard never makes.
      const fail = c.issueFor('2.1.1', 'native-mouse-press-only', c.el, 'Works with a mouse but not with the keyboard',
        `“${c.item.label}” acts when the mouse button is pressed (mousedown / pointerdown), not on click. Enter and Space only make a click, so keyboard users can’t use it. Act on click instead.`, 'critical');
      yield { keys: [], ifNavigates: fail }; // the press below may open another page
      watch();
      for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) {
        const Ev = type.startsWith('pointer') && typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
        c.el.dispatchEvent(new Ev(type, { bubbles: true, cancelable: true, composed: true, button: 0, buttons: type.endsWith('down') ? 1 : 0, view: window }));
      }
      await sleep(400);
      if (c.navigated()) { c.issues.push(fail); return; }
      if (!unwatch()) return;
      // What changed may change by itself (a carousel that turns, a clock): watch it without pressing anything first.
      const afterPress = new Set(changed);
      watch();
      await sleep(5500);
      unwatch();
      if (![...changed].some(t => afterPress.has(t))) c.issues.push(fail);
    } finally {
      removeEventListener('click', cancel, true);
      mo.disconnect();
    }
  }

  const PATTERNS = { native: patNative, button: patButton, link: patButton, checkbox: patCheckbox, radio: patRadio, tab: patTab, slider: patSlider, skip: patSkip, tooltip: patTooltip, select: patSelect };

  async function kbdNext() {
    const r = await K.gen.next();
    if (r.done) return { done: true, navigated: K.ctx.navigated() };
    return r.value;
  }

  async function kbdBegin(index) {
    const item = K.items[index];
    if (!item || !item.el.isConnected || !isVisible(item.el)) return { skip: true };
    clearOverlay();
    item.el.focus();
    if (deepActive() !== item.el && item.pattern !== 'tooltip') return { skip: true };
    K.ctx = makeCtx(item);
    K.mo = new MutationObserver(list => { for (const m of list) if (!m.target.closest?.(`#${OVERLAY_ID}`)) K.ctx.muts++; });
    K.mo.observe(docRoot(), { subtree: true, childList: true, attributes: true, characterData: true });
    K.gen = PATTERNS[item.pattern](K.ctx);
    return kbdNext();
  }

  async function kbdStep() {
    if (!K.gen) return { lost: true };
    return kbdNext();
  }

  async function kbdEnd() {
    const c = K.ctx;
    K.mo?.disconnect();
    K.gen = null;
    if (!c) return [];
    // Put the page back the way it was.
    for (const d of visibleDialogs()) if (!c.dialogsBefore.has(d)) await closeDialog(d);
    const now = snap(c.el);
    if (c.el.isConnected) {
      if (now.expanded === 'true' && c.initial.expanded !== 'true') { c.el.click(); await sleep(200); }
      else if (c.item.pattern === 'checkbox' && now.checked !== c.initial.checked) { c.el.click(); await sleep(150); }
    }
    const on = c.item.initialOn;
    if (on?.isConnected && on.getAttribute(c.item.pattern === 'tab' ? 'aria-selected' : 'aria-checked') !== 'true') { on.click(); await sleep(150); }
    if (c.item.pattern === 'select' && c.el.isConnected) c.el.value = c.initialValue;
    if (location.href !== c.startHref && !c.hashRouter && stripHash(location.href) === stripHash(c.startHref)) history.replaceState(history.state, '', c.startHref);
    deepActive()?.blur?.();
    K.ctx = null;
    return c.issues;
  }

  // ── Deep interaction: use the app like a person (add, fill, save, open) ─────
  //
  // The panel drives a walk over UI states: it asks for a fingerprint of the
  // current screen, the actions available on it, and any form to fill. Clicks
  // are real mouse clicks sent by the panel at the coordinates given here.

  const ACTION_SEL = 'button, a[href], summary, input[type="checkbox"], input[type="radio"], [role="button"], [role="link"], [role="menuitem"], [role="tab"], [role="option"], [role="checkbox"], [role="switch"], [role="combobox"], [role="treeitem"], [aria-expanded], [aria-haspopup], [onclick]';
  const TEXTLIKE = 'input:not([type]), input[type="text"], input[type="email"], input[type="tel"], input[type="number"], input[type="url"], input[type="search"], input[type="date"], input[type="time"], input[type="datetime-local"], textarea';
  const SET_DIRECTLY = /^(date|time|datetime-local)$/;
  const SUBMIT = /\b(save|submit|create|add|next|done|ok|apply|update|confirm|continue|finish)\b/i;
  const PROMISING = /\b(add|create|new|insert|edit|configure|open|more|options|expand|details|view)\b|^\+$/i;
  const ERR = /required|mandatory|invalid|must|please (enter|select|provide|fill|choose)|cannot be (empty|blank)|can['’]t be (empty|blank)|is not valid|enter (a|an|the|your)\b|error|आवश्यक|अमान्य/i;
  const LIVE = '[role="alert"], [role="status"], [role="log"], [aria-live]:not([aria-live="off"]), output';
  const DIALOG_SEL = `dialog, [role="dialog"], [role="alertdialog"], [aria-modal="true"], ${OVERLAY_CLASSES}`;
  const A = { items: [], fields: [], submit: null, scope: null, pending: null, mo: null, changed: new Set() };

  // Controls that only change how the page is drawn (zoom, fit, full screen): pressing them would leave the page in a
  // view the user didn't choose, and later measurements (target size, contrast, reflow) would judge that view.
  const VIEW_ONLY = ['zoom in', 'zoom out', 'zoom', 'fit to screen', 'fit to view', 'fit view', 'reset zoom', 'reset view', 'full screen', 'fullscreen', 'exit full screen'];

  function neverRe(words = []) {
    const list = [...words, ...VIEW_ONLY].map(w => w.trim()).filter(Boolean).map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/[\s\-_]+/g, '[\\s\\-_]*'));
    // Word edges for any script (\b only knows English letters, so Hindi words like "हटाएं" never matched).
    return list.length ? new RegExp(`(?<![\\p{L}\\p{M}\\p{N}])(${list.join('|')})(?![\\p{L}\\p{M}\\p{N}])`, 'iu') : /(?!)/;
  }

  function topLayer() {
    const dialogs = visibleDialogs();
    if (dialogs.length) return dialogs[dialogs.length - 1];
    const popups = visiblePopups();
    return popups.length ? popups[popups.length - 1] : docRoot();
  }

  // Things with a pointer cursor that are not already controls (canvas nodes, cards, rows).
  // A card may contain its own buttons; prepareAction clicks the card, not them.
  function pointerTargets(root) {
    const out = [];
    for (const el of root.querySelectorAll('div, span, li, td, tr, p, svg, g')) {
      if (el.closest(`#${OVERLAY_ID}`) || getComputedStyle(el).cursor !== 'pointer') continue;
      if (el.parentElement && getComputedStyle(el.parentElement).cursor === 'pointer') continue;
      if (el.closest(ACTION_SEL) || !isVisible(el)) continue;
      out.push(el);
    }
    return out;
  }

  // A card's own text, leaving out the text of controls inside it ("Delete state").
  function ownLabel(el) {
    if (!el.querySelector(ACTION_SEL)) return accName(el);
    let text = '';
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
    for (let t = walker.nextNode(); t; t = walker.nextNode()) {
      const inner = t.parentElement?.closest(ACTION_SEL);
      if (!inner || !el.contains(inner) || inner === el) text += ' ' + t.nodeValue;
    }
    return text.replace(/\s+/g, ' ').trim().slice(0, 80) || accName(el);
  }

  // True when a click at this point lands on `el` itself, not on a control inside it.
  function landsOn(el, t) {
    if (!t || !(t === el || el.contains(t))) return false;
    const inner = t.closest(ACTION_SEL);
    return !inner || inner === el || !el.contains(inner);
  }

  function hashString(s) {
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
  }

  // Identifies a screen by its address, top dialog and the controls on it (not their data).
  function uiFingerprint() {
    const top = topLayer();
    const controls = [...top.querySelectorAll(ACTION_SEL), ...pointerTargets(top)].filter(isVisible).slice(0, 150)
      .map(el => `${el.getAttribute('role') || el.localName}:${accName(el).slice(0, 30)}`);
    const fields = [...top.querySelectorAll(`${TEXTLIKE}, select`)].filter(isVisible).length;
    const where = /^#!?\//.test(location.hash) ? location.href : location.origin + location.pathname + location.search;
    const layer = top === docRoot() ? '' : `${top.getAttribute('role') || top.localName}:${accName(top).slice(0, 40)}`;
    return `${hashString([where, layer, fields, controls.join(',')].join('|'))}:${controls.length}`;
  }

  // What kind of screen this is, not which record it shows: the main content's field labels, column headers,
  // headings levels and buttons, with numbers removed. /complaint/101 and /complaint/102 match; ?key=2 (Employees)
  // and ?key=5 (Payroll) do not. Shared menus, headers and footers are left out: every screen has them.
  function pageLayout() {
    const main = document.querySelector('main, [role="main"]');
    const root = main || docRoot();
    const shared = 'nav, header, footer, aside, [role="navigation"], [role="banner"], [role="contentinfo"], [role="complementary"], [role="menu"], [role="menubar"]';
    const candidates = [...root.querySelectorAll('label, legend, th, [role="columnheader"], h1, h2, h3, h4, button, [role="button"], [role="tab"], input, select, textarea')];
    // Without a main area, menus are often plain divs: boxes named like a menu or sidebar are left out too, but not
    // the page itself or a wrapper around the page's content (<body class="sidebar-mini">, <div id="app" class="menu-open">,
    // a restaurant's "menu" page): a box holding the page's heading or nearly everything on the page is not a menu.
    // (A big sidebar holds many buttons, but not nearly all of them.)
    const named = '[class*="sidebar" i], [class*="sidenav" i], [class*="side-nav" i], [class*="menu" i], [class*="drawer" i], [class*="topbar" i], [class*="navbar" i], [id*="sidebar" i], [id*="menu" i]';
    const heading = document.querySelector('h1');
    const holds = new Map();
    const isWrapper = box => {
      if (!holds.has(box)) holds.set(box, candidates.filter(c => box.contains(c)).length >= candidates.length * 0.9);
      return holds.get(box);
    };
    const menuBox = el => {
      if (main) return false;
      for (let box = el.closest(named); box; box = box.parentElement?.closest(named)) {
        if (box !== docRoot() && box !== document.documentElement && !(heading && box.contains(heading)) && !isWrapper(box)) return true;
      }
      return false;
    };
    const clean = s => (s || '').replace(/\s+/g, ' ').replace(/[\d.,:/#-]+/g, ' ').trim().toLowerCase().slice(0, 60);
    const items = new Set();
    for (const el of candidates) {
      if (el.closest(shared) || menuBox(el) || !isVisible(el)) continue;
      const kind = el.localName;
      if (/^h[1-4]$/.test(kind)) items.add(kind); // heading levels only: their text is often the record's own
      else if (/^(input|select|textarea)$/.test(kind)) items.add(`${kind}:${el.type || ''}:${clean(el.name || el.id)}`);
      else { const t = clean(accName(el)); if (t) items.add(`${el.getAttribute('role') || kind}:${t}`); }
    }
    const h1 = root.querySelector('h1');
    if (h1 && !h1.closest(shared)) items.add(`title:${clean(h1.textContent)}`);
    if (clean(document.title)) items.add(`page:${clean(document.title)}`); // "Payroll - HCM" vs "Employee 101 - HCM"
    return [...items];
  }

  // A control that sends a form: a submit button, or "Save" / "Submit" / "Done"… in a form or dialog that has fields.
  function submitsForm(el) {
    if (el.matches('[type="submit"]') || (el.localName === 'button' && !el.getAttribute('type') && el.form)) return true;
    const box = el.closest(`form, ${DIALOG_SEL}`);
    return !!box && SUBMIT.test(ownLabel(el) || el.value || '') && [...box.querySelectorAll(FIELD_SEL)].some(isVisible);
  }

  function uiActions({ neverClick = [], preferSubmit = false } = {}) {
    const top = topLayer();
    const never = remember(neverClick);
    const scoped = top !== docRoot();
    const els = [...new Set([...top.querySelectorAll(ACTION_SEL), ...pointerTargets(top)])].filter(el => {
      if (!isVisible(el) || el.disabled || el.getAttribute('aria-disabled') === 'true' || el.closest(`#${OVERLAY_ID}`)) return false;
      if (inTestedRegion(el)) return false; // shared side nav / header already tested on an earlier page
      if (never.test(ownLabel(el) || el.value || '')) return false;
      if (submitsForm(el)) return false; // Deep mode never saves: a form's Save / Submit is pressed only by the error checks
      if (el.matches('a[href]')) {
        const u = new URL(hrefOf(el), location.href);
        if (u.origin !== location.origin || el.getAttribute('target') === '_blank' || el.hasAttribute('download') || /^(mailto|tel):/.test(hrefOf(el))) return false;
      }
      return true;
    });
    const rank = el => {
      const label = ownLabel(el);
      if (preferSubmit && SUBMIT.test(label)) return -1;
      if (CLOSE.test(label)) return 6;
      if (PROMISING.test(label)) return scoped ? 0 : 1;
      if (el.matches('[aria-expanded], [aria-haspopup], [role="tab"], summary')) return 2;
      if (el.matches('a[href]')) return 5;
      return scoped ? 0 : 3;
    };
    A.items = els.sort((a, b) => rank(a) - rank(b));
    const where = scoped ? accName(top).slice(0, 30) : '';
    return A.items.map((el, index) => {
      const label = ownLabel(el) || el.value || el.getAttribute('title') || el.localName;
      // Same-label controls (ten "Edit" buttons in a list) share a key, so one stands in for all.
      return { index, label: label.slice(0, 60), key: `${el.getAttribute('role') || el.localName}|${label.slice(0, 40)}|${where}` };
    });
  }

  // ── Live recording ──────────────────────────────────────────────────────────
  // While "Record workflow" is on, each action the person takes is tested as it happens: a control used with the mouse
  // must also be reachable from the keyboard, a message it brings up must be announced, a dialog it opens must take
  // focus, and focus must not be lost when a dialog closes. Only the control's or field's name is kept, never what was
  // typed. The step and its findings go to the panel, which also scans each new screen the step leads to.
  const REC = { on: false };
  const recName = el => (ownLabel(el) || el.getAttribute('title') || el.getAttribute('aria-label') || el.localName).replace(/\s+/g, ' ').trim().slice(0, 60);
  const keyboardUsable = el => el.matches('a[href], button, input, select, textarea, summary, [contenteditable="true"]') || el.tabIndex >= 0;
  // The control a click landed on: a real control, else the outermost box with a pointer cursor (a card, a canvas node).
  function recControl(t) {
    if (!(t instanceof Element) || t.closest(`#${OVERLAY_ID}`)) return null;
    const control = t.closest(ACTION_SEL);
    if (control) return control;
    let box = null;
    for (let n = t; n && n !== docRoot(); n = n.parentElement) if (getComputedStyle(n).cursor === 'pointer') box = n;
    return box;
  }
  const recSend = msg => { try { chrome.runtime.sendMessage({ type: 'ns-recorded', ...msg }).catch(() => {}); } catch { /* the extension was reloaded */ } };

  async function onRecClick(e) {
    const el = recControl(e.target);
    if (!el || !e.isTrusted) return;
    // A click from Enter / Space has no pointer position (detail 0); a mouse click has.
    const via = e.detail === 0 ? 'keyboard' : 'mouse';
    const name = recName(el);
    const before = { dialog: el.closest(DIALOG_SEL), dialogs: new Set(visibleDialogs()), href: location.href };
    const changed = new Set();
    const mo = new MutationObserver(list => {
      for (const m of list) {
        const t = m.type === 'characterData' ? m.target.parentElement : m.target;
        if (t && !t.closest?.(`#${OVERLAY_ID}`)) changed.add(t);
        m.addedNodes.forEach(n => n.nodeType === 1 && changed.add(n));
      }
    });
    mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true, attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'aria-invalid', 'open'] });
    await sleep(50);
    await settle();
    mo.disconnect();
    const step = `${via === 'keyboard' ? 'Pressed' : 'Clicked'} “${name}”`;
    const issues = [];
    if (via === 'mouse' && el.isConnected && !keyboardUsable(el)) issues.push(wcagIssue('2.1.1', {
      ruleId: 'mouse-only-control', source: 'record', impact: 'critical',
      title: 'Clickable element can’t be reached with the keyboard',
      description: 'This was used with the mouse, but it is not in the tab order, so keyboard users can’t use it. Use a native <button> or <a href>, or add tabindex="0" with Enter/Space handling.',
      nodes: [nodeOf(el, `Clicked while recording, but it can’t receive keyboard focus.`)],
    }));
    const silent = newMessages([...changed]).filter(m => !m.closest(LIVE) && !m.querySelector(LIVE) && !m.contains(deepActive()));
    if (silent.length) issues.push(wcagIssue('4.1.3', {
      ruleId: 'status-message-silent', source: 'record', impact: 'serious',
      title: 'Message appears without being announced to screen readers',
      description: 'After this action a message popped up (for example "Saved" or an error), but it is not in a live region, so screen-reader users never hear it. Put messages in a container with role="status" (or role="alert" for errors) that exists before the message is added.',
      nodes: nodesOf(silent, 'Appeared after the action, not in a live region.'),
    }));
    const opened = visibleDialogs().filter(d => !before.dialogs.has(d));
    if (opened.length && !opened.some(d => d.contains(deepActive()))) issues.push(wcagIssue('2.4.3', {
      ruleId: 'dialog-focus-not-moved', source: 'record', impact: 'serious',
      title: 'Focus stays behind the dialog when it opens',
      description: 'When a dialog opens, move keyboard focus into it (to its first control or its heading). Otherwise keyboard and screen-reader users keep working on the page behind it.',
      nodes: [nodeOf(opened[opened.length - 1], `Opened by “${name}”; focus stayed behind it.`)],
    }));
    if (before.dialog && !isVisible(before.dialog)) {
      const a = deepActive();
      if (!a || a === docRoot() || a === document.documentElement) issues.push(wcagIssue('2.4.3', {
        ruleId: 'dialog-focus-lost', source: 'record', impact: 'serious',
        title: 'Focus is lost when the dialog closes',
        description: 'After the dialog closed, focus fell back to the top of the page. Send focus back to the control that opened the dialog, or to the newly created item.',
        nodes: [nodeOf(el, `“${name}” closed the dialog and focus was lost.`)],
      }));
    }
    recSend({ step: { text: step, via, screen: document.title || location.pathname }, issues, navigated: location.href !== before.href });
  }
  // Fields: only which field was filled in or chosen, never the value.
  function onRecChange(e) {
    const el = e.target;
    if (!(el instanceof Element) || !el.matches(FIELD_SEL + ', input[type="checkbox"], input[type="radio"]')) return;
    if (el.type === 'password') return;
    // The field's own label, never its contents (a dropdown's text would list its options, including the one chosen).
    const byIds = ids => (ids || '').split(/\s+/).map(id => id && document.getElementById(id)?.textContent).filter(Boolean).join(' ');
    const label = (el.getAttribute('aria-label') || byIds(el.getAttribute('aria-labelledby')) || el.labels?.[0]?.textContent
      || el.getAttribute('placeholder') || el.name || 'a field').replace(/\s+/g, ' ').trim().slice(0, 60);
    const text = el.matches('select') ? `Chose an option in “${label}”` : el.matches('[type="checkbox"], [type="radio"]') ? `Ticked “${label}”` : `Filled in “${label}”`;
    recSend({ step: { text, via: 'field', screen: document.title || location.pathname }, issues: [], navigated: false });
  }
  function startRecording() {
    if (REC.on) return true;
    REC.on = true;
    document.addEventListener('click', onRecClick, true);
    document.addEventListener('change', onRecChange, true);
    return true;
  }
  function stopRecording() {
    REC.on = false;
    document.removeEventListener('click', onRecClick, true);
    document.removeEventListener('change', onRecChange, true);
    return true;
  }

  function watchChanges() {
    A.changed = new Set();
    A.mo?.disconnect();
    A.mo = new MutationObserver(list => {
      for (const m of list) {
        const t = m.type === 'characterData' ? m.target.parentElement : m.target;
        if (t && !t.closest?.(`#${OVERLAY_ID}`)) A.changed.add(t);
        m.addedNodes.forEach(n => n.nodeType === 1 && A.changed.add(n));
      }
    });
    A.mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true, attributeFilter: ['class', 'style', 'hidden', 'aria-hidden', 'aria-invalid', 'open'] });
  }

  function stopWatching() {
    A.mo?.disconnect();
    A.mo = null;
    const out = new Set();
    for (const el of A.changed) {
      if (!el.isConnected) continue;
      out.add(el);
      el.querySelectorAll?.('*').forEach((c, i) => i < 50 && out.add(c));
    }
    return [...out];
  }

  // Resolves once the page has been quiet for `quiet` ms (or after `max`).
  function settle(max = 2500, quiet = 300) {
    return new Promise(resolve => {
      let t;
      const done = () => { mo.disconnect(); clearTimeout(t); clearTimeout(cap); resolve(); };
      const mo = new MutationObserver(() => { clearTimeout(t); t = setTimeout(done, quiet); });
      mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
      t = setTimeout(done, quiet);
      const cap = setTimeout(done, max);
    });
  }

  function prepareAction(index) {
    const el = A.items[index];
    if (!el?.isConnected || !isVisible(el)) return { skip: true };
    clearOverlay();
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    const r = el.getBoundingClientRect();
    const hit = [[0.5, 0.5], [0.25, 0.5], [0.75, 0.5], [0.5, 0.3], [0.5, 0.7], [0.1, 0.1], [0.9, 0.1], [0.1, 0.9], [0.5, 0.1]]
      .map(([fx, fy]) => [r.left + r.width * fx, r.top + r.height * fy])
      .find(([x, y]) => landsOn(el, document.elementFromPoint(x, y)));
    A.pending = { el, href: location.href, dialog: el.closest(DIALOG_SEL), synthetic: !hit };
    watchChanges();
    return hit ? { x: hit[0], y: hit[1] } : { synthetic: true };
  }

  function fixedAncestor(el) {
    for (let n = el; n && n !== docRoot() && n.nodeType === 1; n = n.parentElement) {
      if (/fixed|sticky/.test(getComputedStyle(n).position)) return n;
    }
    return null;
  }

  // Messages that pop up after an action (toasts, banners) must reach screen readers.
  // Side panels and drawers are not messages: their container holds its own controls.
  const CONTROLS = 'input, select, textarea, button, a[href], [role="button"], [role="link"]';
  function newMessages(changed) {
    return outermost(changed.filter(el => {
      if (!(el instanceof HTMLElement) || !isVisible(el) || el.closest(DIALOG_SEL) || el.matches(CONTROLS) || el.querySelector(CONTROLS)) return false;
      const text = itext(el).trim();
      if (text.length < 3 || text.length > 200) return false;
      const cls = [el, el.parentElement, el.parentElement?.parentElement].map(n => n?.getAttribute?.('class') || '').join(' ');
      if (/toast|snack|notif|alert|flash|message/i.test(cls)) return true;
      const box = fixedAncestor(el);
      return !!box && !box.querySelector(CONTROLS);
    }));
  }

  async function finishAction() {
    const p = A.pending;
    A.pending = null;
    if (!p) return { issues: [] };
    if (p.synthetic) p.el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    await settle();
    const changed = stopWatching();
    const issues = [];
    const silent = newMessages(changed).filter(m => !m.closest(LIVE) && !m.querySelector(LIVE) && !m.contains(deepActive()));
    if (silent.length) issues.push(wcagIssue('4.1.3', {
      ruleId: 'status-message-silent', source: 'interact', impact: 'serious',
      title: 'Message appears without being announced to screen readers',
      description: 'After this action a message popped up (for example "Saved" or an error), but it is not in a live region, so screen-reader users never hear it. Put messages in a container with role="status" (or role="alert" for errors) that exists before the message is added.',
      nodes: nodesOf(silent, 'Appeared after the action, not in a live region.'),
    }));
    if (p.dialog && !isVisible(p.dialog)) {
      const a = deepActive();
      if (!a || a === docRoot() || a === document.documentElement) issues.push(wcagIssue('2.4.3', {
        ruleId: 'dialog-focus-lost', source: 'interact', impact: 'serious',
        title: 'Focus is lost when the dialog closes',
        description: 'After the dialog closed, focus fell back to the top of the page. Send focus back to the control that opened the dialog, or to the newly created item.',
        nodes: [nodeOf(p.el, 'Pressed inside the dialog; the dialog closed and focus was lost.')],
      }));
    }
    return { issues, navigated: location.href !== p.href };
  }

  // Test data is easy to find and delete afterwards: the record's name is "<Thing> accessibility test <date time>"
  // ("Campaign accessibility test 31 Oct 2026 02:40" on "Create Campaign"), other text says "Accessibility test".
  const NAME_FIELD = /\b(name|title|label|subject)\b/;
  function entityName(scope) {
    const strip = t => (t || '').replace(/\s+/g, ' ').trim()
      .replace(/^(create|add|new|edit|update|set ?up|register|configure|enter)\s+(a |an |the |new )?/i, '')
      .replace(/\s+(form|details|page|screen|wizard)$/i, '').split(' ').slice(0, 3).join(' ');
    const heading = scope.querySelector?.('h1, h2, h3, [role="heading"], legend')?.textContent || document.querySelector('h1, h2')?.textContent;
    const thing = strip(heading) || strip(document.title.split(/\s+[|–—-]\s+/)[0]) || 'Item';
    return thing.charAt(0).toUpperCase() + thing.slice(1);
  }
  const stampNow = () => new Date().toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(',', '');

  function testValue(el, n, { thing = 'Item', stamp = stampNow(), isName = false } = {}) {
    const hint = `${el.type} ${fieldLabel(el)}`.toLowerCase();
    let v;
    if (/email/.test(hint)) v = 'accessibility.test@example.com';
    else if (/\btel\b|phone|mobile/.test(hint)) v = '9876543210';
    else if (/pin ?code|postal|zip/.test(hint)) v = '110001';
    else if (el.type === 'number') v = String(el.min && +el.min > 0 ? el.min : 1);
    else if (el.type === 'date') v = new Date().toISOString().slice(0, 10);
    else if (/\bdate\b|\bdob\b/.test(hint)) v = new Date().toLocaleDateString('en-GB'); // a date typed into a text box (date pickers)
    else if (el.type === 'time') v = '10:00';
    else if (el.type === 'datetime-local') v = new Date().toISOString().slice(0, 16);
    else if (el.type === 'url' || /\burl\b|website/.test(hint)) v = 'https://example.com';
    else if (/\bcode\b|\bkey\b|\bid\b/.test(hint)) v = `A11Y_TEST_${n + 1}`;
    else if (isName) v = `${thing} accessibility test ${stamp}`;
    else if (el.localName === 'textarea' || /description|comment|remark|note/.test(hint)) v = 'Accessibility test data added by the accessibility scanner. Safe to delete.';
    else v = `Accessibility test ${(fieldLabel(el).replace(/[^\w ]/g, '').split(/\s+/).filter(Boolean).slice(0, 2).join(' ') || 'item').toLowerCase()} ${n + 1}`;
    return el.maxLength > 0 ? v.slice(0, el.maxLength) : v;
  }

  // A text box that opens a list to choose from (DIGIT's dropdowns are text inputs that open a role="listbox").
  const isPicker = el => el.localName === 'input' && (el.matches('[role="combobox"], [aria-haspopup="listbox"], [aria-autocomplete]') ||
    !!el.closest('[class*="dropdown" i], [class*="select" i], [class*="combobox" i], [class*="multiselect" i]'));
  // Fields still to fill: empty text boxes, selects and pickers, radio groups with nothing chosen, required checkboxes.
  // Not search boxes, nor fields in the top bar, header or side nav (DIGIT's city dropdown).
  function emptyFields(root) {
    const out = [];
    const groups = new Set();
    for (const el of root.querySelectorAll(`${TEXTLIKE}, select, input[type="radio"], input[type="checkbox"]`)) {
      if (!isVisible(el) || el.disabled || el.type === 'search' || el.closest(SHARED_BOX) || el.closest(`#${OVERLAY_ID}`)) continue;
      if (el.type === 'radio') {
        const group = el.name ? [...root.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`)] : [el];
        if (groups.has(el.name || el) || group.some(r => r.checked)) continue;
        groups.add(el.name || el);
        out.push(el);
      } else if (el.type === 'checkbox') {
        if (!el.checked && (el.required || el.getAttribute('aria-required') === 'true')) out.push(el);
      } else if (!el.value && (!el.readOnly || isPicker(el))) out.push(el);
    }
    // Choice cards built as role="radio" (pick a template): the first one, when none of its group is chosen.
    for (const el of root.querySelectorAll('[role="radio"]')) {
      const group = el.closest('[role="radiogroup"]') || el.parentElement;
      if (!isVisible(el) || el.getAttribute('aria-disabled') === 'true' || el.closest(SHARED_BOX) || groups.has(group)) continue;
      groups.add(group);
      if (!group.querySelector('[role="radio"][aria-checked="true"]')) out.push(el);
    }
    return out;
  }
  const fieldMode = el => (el.type === 'radio' || el.type === 'checkbox' || el.getAttribute('role') === 'radio' ? 'check' : isPicker(el) ? 'pick' : el.localName === 'select' || SET_DIRECTLY.test(el.type) ? 'set' : 'type');
  const describeField = (el, index) => ({
    index, mode: fieldMode(el), value: testValue(el, index, { thing: A.thing, stamp: A.stamp, isName: el === A.nameField }),
    label: fieldLabel(el).replace(/\s+/g, ' ').trim().toLowerCase().slice(0, 60), type: el.type || el.localName,
  });

  // The form on top: inside the newest dialog, a <form> on the page, or the main screen's fields (forms built
  // without a <form>). Its button to send it can be anywhere on the screen (an action bar at the bottom).
  // Sign-in forms are never touched.
  function formInfo({ neverClick = [] } = {}) {
    const top = topLayer();
    const main = document.querySelector('main, [role="main"]') || docRoot();
    const scope = top !== docRoot() ? top : [...document.forms].find(f => isVisible(f) && emptyFields(f).length) || (emptyFields(main).length ? main : null);
    A.fields = [];
    A.submit = null;
    if (!scope || scope.querySelector('input[type="password"]')) return { fields: [] };
    const never = remember(neverClick);
    A.scope = scope;
    A.fields = emptyFields(scope);
    // Cancel / Close / Back are never the form's submit, even as the first submit-type button in it.
    const usable = b => isVisible(b) && !b.disabled && !b.closest(SHARED_BOX) && !never.test(accName(b) || b.value || '') && !CLOSE.test(accName(b) || b.value || '') && !/^\s*(back|previous|reset|clear)\b/i.test(accName(b) || b.value || '');
    const sel = 'button, [role="button"], input[type="submit"]';
    const buttons = [...scope.querySelectorAll(sel)].filter(usable);
    const anywhere = top === docRoot() ? [...document.querySelectorAll(sel)].filter(b => usable(b) && !scope.contains(b)) : [];
    A.submit = buttons.find(b => b.type === 'submit' && b.form) || buttons.find(b => SUBMIT.test(accName(b) || b.value || '')) ||
      anywhere.find(b => SUBMIT.test(accName(b) || b.value || '')) || null;
    // The record's name: the first field labelled name / title, else the first plain text field.
    const plain = el => (el.localName === 'input' && /^(text|)$/.test(el.type) && !isPicker(el)) || el.localName === 'textarea';
    A.nameField = A.fields.find(el => plain(el) && NAME_FIELD.test(fieldLabel(el).toLowerCase())) || A.fields.find(el => el.localName === 'input' && plain(el));
    A.thing = entityName(scope);
    A.stamp = stampNow();
    const fields = A.fields.map(describeField);
    return {
      fields,
      submit: A.submit ? { label: accName(A.submit) || A.submit.value } : null,
      record: A.nameField ? { thing: A.thing, name: fields[A.fields.indexOf(A.nameField)].value } : null,
    };
  }

  // Fields that appeared after others were filled (choosing a campaign type shows more fields).
  function moreFields() {
    if (!A.scope?.isConnected) return { fields: [] };
    const extra = emptyFields(A.scope).filter(el => !A.fields.includes(el));
    const plain = el => (el.localName === 'input' && /^(text|)$/.test(el.type) && !isPicker(el)) || el.localName === 'textarea';
    const named = !A.nameField && (extra.find(el => plain(el) && NAME_FIELD.test(fieldLabel(el).toLowerCase())) || extra.find(el => el.localName === 'input' && plain(el)));
    if (named) A.nameField = named;
    const start = A.fields.length;
    A.fields.push(...extra);
    const fields = extra.map((el, i) => describeField(el, start + i));
    return { fields, record: named ? { thing: A.thing, name: fields[extra.indexOf(named)].value } : null };
  }

  // Opens a dropdown and chooses the option named `want` (sign-in: the tenant the user typed), else its first real
  // option (not "Select…"). false when no list of options opened, or none has that name.
  async function pickOption(index, want = '') {
    const el = A.fields[index];
    if (!el?.isConnected) return false;
    const named = o => !want || normText(o.textContent) === normText(want) || normText(o.textContent).includes(normText(want));
    if (el.localName === 'select') {
      const opt = [...el.options].find(o => o.value && !o.disabled && named(o));
      if (!opt) return false;
      el.value = opt.value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
    const OPTION = '[role="option"], [class*="dropdown-item" i]';
    const usable = o => isVisible(o) && !o.contains(el) && o.getAttribute('aria-disabled') !== 'true' && (o.textContent || '').trim() &&
      !/^\s*(select|choose|--|none\b|no (options|results|data))/i.test(o.textContent || '');
    // Already open with the option showing (after typing into a searchable dropdown).
    let options = want ? [...document.querySelectorAll(OPTION)].filter(o => usable(o) && named(o)) : [];
    if (!options.length) {
      document.activeElement?.blur?.();
      await settle(600, 150);
      const before = new Set([...document.querySelectorAll(OPTION)].filter(isVisible));
      const listed = () => [...document.querySelectorAll(OPTION)].filter(o => usable(o) && !before.has(o));
      el.scrollIntoView({ block: 'center', behavior: 'instant' });
      // Dropdowns open on focus (DIGIT's: a click then closes it again), on a click, or on a click on their box.
      const box = el.closest('[class*="dropdown" i], [class*="select" i], [class*="combobox" i]') || el.parentElement;
      const ways = [() => el.focus(), () => el.click(), () => el.click(), () => box?.click()];
      for (const open of ways) {
        open();
        await settle(1200, 200);
        options = listed();
        if (options.length) break;
      }
      options = options.filter(named);
    }
    if (!options.length) return false;
    const opt = options.find(o => normText(o.textContent) === normText(want)) || options[0];
    opt.scrollIntoView({ block: 'nearest', behavior: 'instant' });
    for (const type of ['mousedown', 'mouseup']) opt.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    opt.click();
    await settle(1500, 200);
    return true;
  }

  // What a field holds now.
  const fieldValue = index => (A.fields[index]?.value || '').trim();

  function checkField(index) {
    const el = A.fields[index];
    if (!el?.isConnected || el.checked || el.getAttribute('aria-checked') === 'true') return false;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    el.click();
    return el.localName === 'input' ? el.checked : true;
  }

  function focusField(index) {
    const el = A.fields[index];
    if (!el?.isConnected) return false;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    el.focus();
    el.select?.();
    return deepActive() === el;
  }

  function setField(index, value) {
    const el = A.fields[index];
    if (!el?.isConnected) return false;
    if (el.localName === 'select') {
      const opt = [...el.options].find(o => o.value && !o.disabled);
      if (!opt) return false;
      el.value = opt.value;
    } else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  const fieldLook = f => { const cs = getComputedStyle(f); return [cs.borderColor, cs.outlineColor, cs.boxShadow, cs.backgroundColor].join('|'); };

  // 3.3.1 / 4.1.3 / 1.3.1: press the form's submit button with the fields still empty.
  async function validationTest() {
    const { scope, submit, fields } = A;
    if (!submit?.isConnected || !isVisible(submit) || submit.disabled || submit.getAttribute('aria-disabled') === 'true') return { issues: [], ran: false };
    const required = fields.filter(f => f.required || f.getAttribute('aria-required') === 'true' || /\*/.test(f.labels?.[0]?.textContent || ''));
    const looks = fields.map(fieldLook);
    watchChanges();
    submit.focus();
    submit.click();
    await settle();
    const changed = stopWatching();
    if (!scope.isConnected || !isVisible(scope)) return { issues: [], ran: true, accepted: true };
    const issues = [];
    const nativeBlocked = fields.some(f => f.willValidate && !f.validity.valid);
    const errors = innermost(changed.filter(el => el instanceof HTMLElement && isVisible(el) && itext(el).trim().length < 200 && ERR.test(itext(el))));
    if (!errors.length && !nativeBlocked) {
      const marked = fields.filter((f, i) => f.getAttribute('aria-invalid') === 'true' || fieldLook(f) !== looks[i]);
      if (marked.length) issues.push(wcagIssue('3.3.1', {
        wcag: ['3.3.1', '1.4.1'], ruleId: 'error-colour-only', source: 'forms', impact: 'serious',
        title: 'Form errors are shown only by colour or styling',
        description: 'After submitting with empty fields, the fields changed colour or were marked invalid, but no error text appeared. Describe each error in text next to its field.',
        nodes: nodesOf(marked, 'Changed style after an empty submit; no error text.'),
      }));
      else if (required.length) issues.push(wcagIssue('3.3.1', {
        ruleId: 'error-not-shown', source: 'forms', impact: 'serious',
        title: 'Submitting with required fields empty shows no error',
        description: `Pressing “${accName(submit)}” with required fields empty did nothing visible. Tell people, in text, which fields are missing.`,
        nodes: [nodeOf(submit, 'Pressed with required fields empty.')],
      }));
    } else if (errors.length) {
      const active = deepActive();
      const announced = errors.some(e => e.closest(LIVE)) || fields.includes(active) || errors.some(e => e.contains(active));
      if (!announced) issues.push(wcagIssue('4.1.3', {
        ruleId: 'errors-not-announced', source: 'forms', impact: 'serious',
        title: 'Form error messages are not announced to screen readers',
        description: 'The error text appears silently: it is not in a live region (role="alert") and focus does not move to it or to the first invalid field.',
        nodes: nodesOf(errors, 'Error text that appeared after submitting.'),
      }));
      const near = (f, e) => { for (let p = f.parentElement, i = 0; p && i < 3; p = p.parentElement, i++) if (p.contains(e)) return true; return false; };
      const unlinked = fields.filter(f => {
        const e = errors.find(x => near(f, x));
        if (!e) return false;
        const ids = `${f.getAttribute('aria-describedby') || ''} ${f.getAttribute('aria-errormessage') || ''}`.split(/\s+/).filter(Boolean);
        return !ids.some(id => { const t = document.getElementById(id); return t && (t.contains(e) || e.contains(t)); }) && !f.labels?.[0]?.contains(e);
      });
      if (unlinked.length) issues.push(wcagIssue('1.3.1', {
        ruleId: 'error-not-linked', source: 'forms', impact: 'moderate',
        title: 'Error message is not connected to its field',
        description: 'The error is shown next to the field but not linked to it, so screen readers don’t read it with the field. Link it with aria-describedby or aria-errormessage.',
        nodes: nodesOf(unlinked, 'Has an error message nearby that is not linked.'),
      }));
    }
    return { issues, ran: true };
  }

  async function closeTop() {
    const top = topLayer();
    if (top === docRoot()) return false;
    if (top.matches(DIALOG_SEL)) await closeDialog(top);
    else {
      (document.activeElement || docRoot()).dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(250);
    }
    return !isVisible(top);
  }

  const topIsLayer = () => topLayer() !== docRoot();

  // ── Signing in with the user's own setup ───────────────────────────────────
  // Each field is found by the text the user typed: its label, placeholder or name, or the short text right around
  // it (forms that show the label in a separate block). An exact match wins over one that only contains the text.
  const normText = s => (s || '').replace(/[*:]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const nearText = el => {
    for (let n = el.parentElement, i = 0; n && i < 3; n = n.parentElement, i++) {
      const t = (n.innerText || '').trim();
      if (t && t.length <= 80) return t;
    }
    return '';
  };
  const textsOf = el => [fieldLabel(el), accName(el), el.getAttribute('placeholder'), el.getAttribute('aria-label'), el.name, el.id, nearText(el)].filter(Boolean);
  function findByText(els, text, textsFor) {
    const want = normText(text);
    if (!want) return null;
    return els.find(e => textsFor(e).some(t => normText(t) === want)) || els.find(e => textsFor(e).some(t => normText(t).includes(want))) || null;
  }

  function loginField(label, type) {
    const sel = type === 'checkbox' ? 'input[type="checkbox"], [role="checkbox"]'
      : type === 'dropdown' ? 'select, input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="password"]), [role="combobox"]'
        : type === 'password' ? 'input[type="password"]'
          : 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="password"]):not([type="submit"]):not([type="button"]), textarea';
    const els = [...document.querySelectorAll(sel)].filter(isVisible);
    const el = findByText(els, label, textsOf) || (type === 'password' && els.length === 1 ? els[0] : null);
    if (!el) return { found: false };
    A.fields = [el];
    return { found: true, index: 0, checked: !!el.checked || el.getAttribute('aria-checked') === 'true' };
  }

  function clickField(index) {
    const el = A.fields[index];
    if (!el?.isConnected) return false;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    el.click();
    return true;
  }

  // The button to press, found by its text; coordinates for a real click.
  function prepareButton(text) {
    const els = [...document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"], a')].filter(isVisible);
    const el = findByText(els, text, b => [accName(b), b.value, b.textContent].filter(Boolean));
    if (!el) return { skip: true };
    A.items = [el];
    return prepareAction(0);
  }

  // ── Panel-driven checks: 2.1.4, 2.5.2, hover-only content and menus, 2.3.1, 3.3.3 ──

  const P = { mo: null, changes: 0, before: null, items: [], hover: [], menus: [], regions: [], noisy: false };
  const STATE_ATTRS = ['aria-expanded', 'aria-checked', 'aria-selected', 'aria-pressed', 'hidden', 'open'];

  // Counts meaningful changes only: content added or removed, or a state attribute flipped (not hover styling).
  function watchMeaningful() {
    P.changes = 0;
    P.mo?.disconnect();
    P.mo = new MutationObserver(list => {
      for (const m of list) {
        if (m.target.closest?.(`#${OVERLAY_ID}`)) continue;
        if (m.type === 'attributes' || [...m.addedNodes, ...m.removedNodes].some(n => n.nodeType === 1 || (n.nodeType === 3 && n.nodeValue.trim()))) P.changes++;
      }
    });
    P.mo.observe(docRoot(), { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: STATE_ATTRS });
    P.before = { href: location.href, active: deepActive(), scroll: scrollY, dialogs: visibleDialogs().length };
  }

  function strongChange({ ignoreFocus = false } = {}) {
    const b = P.before;
    const a = deepActive();
    return location.href !== b.href || visibleDialogs().length !== b.dialogs || Math.abs(scrollY - b.scroll) > 40 ||
      (!ignoreFocus && a !== b.active && a !== docRoot());
  }

  function endWatch({ ignoreFocus = false } = {}) {
    P.mo?.disconnect();
    return P.changes > 0 || strongChange({ ignoreFocus });
  }

  async function putBack() {
    const before = P.before;
    for (const d of visibleDialogs()) await closeDialog(d);
    (document.activeElement || docRoot()).dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
    if (before && Math.abs(scrollY - before.scroll) > 40) scrollTo(0, before.scroll);
    deepActive()?.blur?.();
    return true;
  }

  // 2.1.4 — first watch the idle page, so pages that update by themselves (clocks, feeds) don't count as shortcuts.
  async function shortcutBaseline() {
    deepActive()?.blur?.();
    watchMeaningful();
    await sleep(800);
    P.mo?.disconnect();
    P.noisy = P.changes > 0;
    return P.noisy;
  }

  function shortcutArm() {
    deepActive()?.blur?.();
    watchMeaningful();
    return true;
  }

  async function shortcutCheck() {
    await sleep(350);
    const hit = P.noisy ? (P.mo?.disconnect(), strongChange()) : endWatch();
    const navigated = location.href !== P.before.href;
    if (hit && !navigated) await putBack();
    return { hit, navigated, from: P.before.href };
  }

  function shortcutIssue(keys) {
    return wcagIssue('2.1.4', {
      ruleId: 'single-key-shortcut', source: 'shortcuts', impact: 'serious',
      title: 'Single-key keyboard shortcut',
      description: `Pressing ${keys.map(k => `“${k}”`).join(', ')} on its own makes the page do something. Speech-input users trigger these by accident. Unless there is a setting to turn the shortcut off or change it to use Ctrl/Alt, make it work only with a modifier key or only when a control has focus.`,
      nodes: [{ target: 'body', html: '<body>', summary: `Keys that triggered an action: ${keys.join(' ')}` }],
    });
  }

  // 2.5.2 — custom controls: does the action fire on mouse *down*, before the button is released?
  function pointerCandidates({ max = Infinity, neverClick } = {}) {
    remember(neverClick);
    const sel = '[role="button"]:not(button):not(input), [role="link"]:not(a), [role="tab"], [role="menuitem"], [role="option"], [onmousedown], [onpointerdown], [data-ns-pd]';
    P.items = [...document.querySelectorAll(sel)].filter(el => isVisible(el) && safeToPress(el)).slice(0, max);
    document.querySelectorAll('[data-ns-pd]').forEach(el => el.removeAttribute('data-ns-pd'));
    return P.items.map((el, index) => ({ index, label: accName(el) || el.localName }));
  }

  function pointPressable(el) {
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    const r = el.getBoundingClientRect();
    const hit = [[0.5, 0.5], [0.25, 0.5], [0.75, 0.5], [0.5, 0.3], [0.5, 0.7]]
      .map(([fx, fy]) => [r.left + r.width * fx, r.top + r.height * fy])
      .find(([x, y]) => { const t = document.elementFromPoint(x, y); return t && (t === el || el.contains(t)); });
    return hit ? { x: hit[0], y: hit[1], away: { x: 2, y: Math.max(2, innerHeight - 4) } } : null;
  }

  function pointerArm(index) {
    const el = P.items[index];
    if (!el?.isConnected || !isVisible(el)) return null;
    clearOverlay();
    const pt = pointPressable(el);
    if (pt) watchMeaningful();
    return pt;
  }

  async function pointerCheck() {
    await sleep(350);
    return endWatch({ ignoreFocus: true });
  }

  function pointerIssue(indices) {
    return wcagIssue('2.5.2', {
      ruleId: 'action-on-pointer-down', source: 'pointer', impact: 'serious',
      title: 'Action happens as soon as the mouse button is pressed',
      description: 'These controls act on mouse-down, so people cannot slide away to cancel an accidental press. Trigger the action on click (mouse-up) instead.',
      nodes: nodesOf(indices.map(i => P.items[i]).filter(Boolean), 'Acted on mouse-down before the button was released.'),
    });
  }

  // Elements Chrome reported click / hover handlers for (tagged by the panel with data-ns-l).
  function judgeListeners({ click = [], hover = [] } = {}) {
    const q = i => document.querySelector(`[data-ns-l="${i}"]`);
    const unreachable = el => el.tabIndex < 0 && !el.closest(`${FOCUSABLE}, label, summary`) && !el.querySelector(FOCUSABLE);
    const clicks = click.map(q).filter(el => el && el !== docRoot() && el !== document.documentElement && isVisible(el) && unreachable(el) && !hasKeyboardEquivalent(el) && !el.closest(`#${OVERLAY_ID}`));
    const cssTips = visibleAll('[class*="tooltip" i], [class*="tip-icon" i], [data-tooltip], [data-tip], [class*="popover" i]').filter(el => el.tabIndex < 0 && !el.closest(FOCUSABLE) && !el.querySelector(FOCUSABLE));
    P.hover = [...new Set([...hover.map(q), ...cssTips])].filter(el => el && el !== docRoot() && isVisible(el) && (unreachable(el) || cssTips.includes(el)));
    document.querySelectorAll('[data-ns-l]').forEach(el => el.removeAttribute('data-ns-l'));
    const issues = clicks.length ? [wcagIssue('2.1.1', {
      ruleId: 'mouse-only-control', source: 'listeners', impact: 'critical',
      title: 'Clickable element can’t be reached with the keyboard',
      description: 'Chrome reports a click handler on these elements, but they cannot receive keyboard focus, so keyboard users cannot use them. Use a native <button> or <a href>, or add tabindex="0" with Enter and Space handling.',
      nodes: nodesOf(outermost(clicks), 'Has a click handler but cannot receive keyboard focus.'),
    })] : [];
    return { issues, hover: P.hover.length };
  }

  const visibleTexts = () => new Set([...docRoot().querySelectorAll('*')].filter(el => el.childElementCount === 0 && el.textContent.trim() && isVisible(el)));

  function hoverArm(index, list = 'hover') {
    const el = P[list][index]?.el ?? P[list][index];
    if (!el?.isConnected || !isVisible(el)) return null;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    const r = el.getBoundingClientRect();
    P.visBefore = visibleTexts();
    return { x: r.left + Math.min(r.width / 2, 20), y: r.top + r.height / 2 };
  }

  async function hoverRevealed(index) {
    await sleep(400);
    const el = P.hover[index];
    const added = [...visibleTexts()].filter(n => !P.visBefore.has(n) && !el.contains(n));
    return added.length > 0;
  }

  function hoverIssue(indices) {
    return wcagIssue('2.1.1', {
      ruleId: 'hover-only-content', source: 'listeners', impact: 'serious',
      title: 'Content appears on mouse hover only',
      description: 'Moving the mouse over these elements shows extra content (for example a tooltip), but they cannot receive keyboard focus, so keyboard users never see it. Make the trigger focusable and show the content on focus too.',
      nodes: nodesOf(indices.map(i => P.hover[i]).filter(Boolean), 'Shows content on hover; not reachable with the keyboard.'),
    });
  }

  // Navigation menus whose sub-items only appear on hover.
  function hoverMenuCandidates() {
    const items = [];
    for (const li of document.querySelectorAll('nav li, [role="navigation"] li, header li, [role="menubar"] > *, [class*="menu" i] li')) {
      const trigger = [...li.children].find(c => c.matches('a[href], button, [role="menuitem"], [tabindex]')) ?? li.querySelector('a[href], button');
      const hidden = [...li.querySelectorAll('a[href], button, [role="menuitem"]')].filter(x => x !== trigger && !isVisible(x));
      if (trigger && isVisible(trigger) && hidden.length && !inTestedRegion(li) && !items.some(i => i.el.contains(li))) items.push({ el: li, trigger, hidden });
    }
    P.menus = items;
    return items.length;
  }

  async function menuRevealedByHover(index) {
    await sleep(400);
    return P.menus[index].hidden.some(isVisible);
  }

  function menuKeyboardArm(index) {
    P.menus[index].trigger.focus();
    return deepActive() === P.menus[index].trigger;
  }

  async function menuKeyboardCheck(index) {
    await sleep(250);
    const m = P.menus[index];
    return m.hidden.some(isVisible) || m.hidden.includes(deepActive());
  }

  function menuIssue(indices) {
    return wcagIssue('2.1.1', {
      ruleId: 'submenu-hover-only', source: 'listeners', impact: 'serious',
      title: 'Sub-menu opens on mouse hover only',
      description: 'These menus show their sub-items when the mouse hovers, but not when the menu item has keyboard focus, so keyboard users can only reach the top level. Show sub-items on focus (:focus-within) or with an expand button.',
      nodes: nodesOf(indices.map(i => P.menus[i]?.trigger).filter(Boolean), 'Sub-items appear on hover but not with the keyboard.'),
    });
  }

  // 2.3.1 / 2.2.2 — where things may flash or move; the panel takes the screenshots.
  function motionRegions() {
    const media = [...document.querySelectorAll('video, img[src*=".gif" i], img[src*=".webp" i], canvas, marquee, blink')].filter(isVisible);
    P.regions = media;
    return {
      hasMotion: document.getAnimations().some(a => a.playState === 'running') || media.length > 0,
      regions: media.map((el, index) => { const r = el.getBoundingClientRect(); return { index, x: r.left, y: r.top, w: r.width, h: r.height, image: el.localName === 'img', hasPause: hasPause(el.parentElement || el) }; }),
    };
  }

  function animatedImageIssue(indices) {
    return wcagIssue('2.2.2', {
      ruleId: 'animated-image-no-pause', source: 'motion', impact: 'moderate',
      title: 'Animated image with no way to stop it',
      description: 'This image keeps animating and there is no pause control. Animations that last more than 5 seconds need a way to pause them — or use a still image.',
      nodes: nodesOf(indices.map(i => P.regions[i]).filter(Boolean), 'Changed between screenshots taken over 3 seconds.'),
    });
  }

  function flashIssue(detail) {
    return wcagIssue('2.3.1', {
      ruleId: 'flashing-content', source: 'motion', impact: 'critical',
      title: 'Content flashes more than three times a second',
      description: `Part of the page flashes ${detail}. Flashing faster than three times a second can cause seizures. Slow it down, make the flashing area much smaller, or remove it.`,
      nodes: [{ target: 'body', html: '<body>', summary: `Measured from screenshots: ${detail}.` }],
    });
  }

  // 3.3.3 — deliberately wrong values for fields that have a format.
  function invalidValues() {
    const out = [];
    A.fields.forEach((el, index) => {
      if (el.localName === 'select' || el.type === 'radio' || el.type === 'checkbox' || isPicker(el)) return;
      const hint = `${el.type} ${fieldLabel(el)}`.toLowerCase();
      let value = null;
      if (el.type === 'email' || /e-?mail/.test(hint)) value = 'not-an-email';
      else if (el.type === 'tel' || /phone|mobile/.test(hint)) value = '12';
      else if (el.type === 'url' || /website|\burl\b/.test(hint)) value = 'not a web address';
      else if (/pin ?code|postal|zip/.test(hint)) value = '12';
      if (value) out.push({ index, value });
    });
    return out;
  }

  const SUGGESTS = /e\.g\.|for example|format|such as|like\s|must|should|at least|at most|between|only|digits?|characters?|@|\d|valid (e-?mail|phone|mobile|number|address|url|web|pin)|enter (a|an|your|the)\s+\w+|include/i;

  async function submitForErrors() {
    const { submit, scope, fields } = A;
    if (!submit?.isConnected || !isVisible(submit) || submit.disabled) return { ran: false };
    watchChanges();
    submit.click();
    await settle();
    const changed = stopWatching();
    const native = fields.filter(f => f.isConnected && f.value && f.willValidate && !f.validity.valid).map(f => ({ el: f, text: f.validationMessage }));
    const shown = innermost(changed.filter(el => el instanceof HTMLElement && isVisible(el) && itext(el).trim().length < 200 && ERR.test(itext(el)))).map(el => ({ el, text: itext(el).trim() }));
    const errors = [...shown, ...native].filter(e => e.text);
    const generic = errors.filter(e => !SUGGESTS.test(e.text));
    const issues = generic.length ? [wcagIssue('3.3.3', {
      ruleId: 'error-no-suggestion', source: 'forms', impact: 'moderate',
      title: 'Error message doesn’t say how to fix the problem',
      description: 'After a wrongly formatted value was entered, the error only says something is wrong. Say what is expected, for example "Enter an email address like name@example.com".',
      nodes: generic.slice(0, MAX_NODES).map(e => nodeOf(e.el, `Error shown: “${e.text}”`)),
    })] : [];
    return { ran: true, errors: errors.length, accepted: !scope?.isConnected || !isVisible(scope), issues };
  }

  function fieldNode(index) {
    return A.fields[index] ? nodeOf(A.fields[index]) : null;
  }

  // ── Finding pages for "Scan whole product" ─────────────────────────────────

  const FILE_LINK = /\.(pdf|zip|rar|7z|docx?|xlsx?|pptx?|csv|txt|png|jpe?g|gif|svg|webp|mp4|mp3|apk|exe|dmg)$/i;

  function discoverLinks({ neverClick = [] } = {}) {
    const never = remember(neverClick);
    const out = new Set();
    for (const a of document.querySelectorAll('a[href], area[href]')) {
      let u;
      try { u = new URL(a.getAttribute('href'), location.href); } catch { continue; }
      if (u.origin !== location.origin || !/^https?:$/.test(u.protocol) || FILE_LINK.test(u.pathname) || a.hasAttribute('download')) continue;
      if (never.test(accName(a))) continue;
      if (!/^#!?\//.test(u.hash)) u.hash = '';
      out.add(u.href);
    }
    return [...out];
  }

  // Menu and sidebar items that are not links (single-page apps route with click handlers).
  const NAV_ROOTS = 'nav, [role="navigation"], [role="menubar"], [role="menu"], [role="tree"], aside, header, [class*="sidebar" i], [class*="sidenav" i], [class*="side-nav" i], [class*="menu" i], [class*="drawer" i]';

  function navCandidates({ neverClick = [] } = {}) {
    const never = remember(neverClick);
    const els = new Set();
    for (const root of document.querySelectorAll(NAV_ROOTS)) {
      if (!isVisible(root)) continue;
      for (const el of root.querySelectorAll('button, [role="menuitem"], [role="treeitem"], [role="link"], [role="tab"], [role="button"], li, div, span')) {
        if (el.closest('a[href]') || el.querySelector('a[href]') || !isVisible(el)) continue;
        const pointer = getComputedStyle(el).cursor === 'pointer';
        if (!pointer && !el.matches('button, [role="menuitem"], [role="treeitem"], [role="link"], [role="tab"], [role="button"]')) continue;
        if (el.parentElement && getComputedStyle(el.parentElement).cursor === 'pointer' && !el.matches('button, [role]')) continue;
        const label = ownLabel(el);
        if (!label || label.length > 40 || never.test(label) || DANGER.test(label) || el.closest(`#${OVERLAY_ID}`)) continue;
        els.add(el);
      }
    }
    // Keep the innermost clickable item, so "Employees" is clicked rather than its whole <li>.
    const navItems = innermost([...els]);
    // Link-like text in the page content that is not a link (DIGIT home cards: "→ Create Campaign" opens a page
    // through a click handler). Short clickable text only: no form controls, forms or dialogs.
    // Plain buttons too (DIGIT's card entries are <button type="button">), but only on pages with nothing to fill in,
    // so a "Create" that saves a form is never pressed. Fields in the top bar, header or side nav (DIGIT's city
    // dropdown is a text input) are not the page's own.
    const fillable = [...document.querySelectorAll('input:not([type="hidden"]):not([type="search"]), select, textarea, [contenteditable="true"]')]
      .some(f => isVisible(f) && !f.closest(NAV_ROOTS) && !f.closest(SHARED_SEL));
    const NOT_A_PAGE = /\b(download|export|print|upload|import|share|copy)\b/i;
    const content = new Set();
    for (const el of docRoot().querySelectorAll('[role="link"], button, [role="button"], li, div, span, p, h2, h3, h4')) {
      const isButton = el.matches('button, [role="button"]');
      if (isButton && (fillable || el.type === 'submit' || el.type === 'reset' || el.disabled || el.hasAttribute('aria-expanded') || el.hasAttribute('aria-haspopup'))) continue;
      if (el.closest(NAV_ROOTS) || (isButton && el.closest(SHARED_SEL)) || el.closest(`a[href], form, dialog, [role="dialog"], [aria-modal="true"], #${OVERLAY_ID}`)) continue;
      if (!isButton && el.closest('button, [role="button"]')) continue;
      if (el.querySelector('a[href], button, input, select, textarea, [role="button"]') || !isVisible(el)) continue;
      const pointer = getComputedStyle(el).cursor === 'pointer';
      if (!pointer && !el.matches('[role="link"]') && !isButton) continue;
      if (!isButton && el.parentElement && getComputedStyle(el.parentElement).cursor === 'pointer' && !el.matches('[role]')) continue;
      const label = ownLabel(el);
      if (!label || label.length > 60 || never.test(label) || DANGER.test(label) || (isButton && NOT_A_PAGE.test(label))) continue;
      content.add(el);
    }
    const contentItems = innermost([...content]).filter(el => !navItems.some(n => n.contains(el) || el.contains(n)));
    const list = [...navItems, ...contentItems];
    A.items = list;
    // Content items are told apart by their card's heading too ("Boundary Management" is in two cards).
    const where = el => el.closest('section, article, [class*="card" i]')?.querySelector('h1, h2, h3, h4, [role="heading"]')?.textContent.trim().slice(0, 40) || '';
    return list.map((el, index) => {
      const inContent = index >= navItems.length;
      return { index, label: ownLabel(el), content: inContent, key: `${inContent ? `content|${where(el)}|` : ''}${el.getAttribute('role') || el.localName}|${ownLabel(el)}` };
    });
  }

  // A visible password field with little else to do on the page: a sign-in screen.
  function isSignIn() {
    const pw = [...document.querySelectorAll('input[type="password"]')].some(isVisible);
    const otp = [...document.querySelectorAll('input[autocomplete="one-time-code"]')].some(isVisible);
    return (pw || otp) && [...document.querySelectorAll('a[href], button, [role="button"]')].filter(isVisible).length < 25;
  }

  // ── Overlays ───────────────────────────────────────────────────────────────

  function overlay() {
    let o = document.getElementById(OVERLAY_ID);
    if (!o) {
      // An SVG file shows HTML only inside a foreignObject.
      o = document.body ? htmlEl('div') : document.createElementNS('http://www.w3.org/2000/svg', 'foreignObject');
      o.id = OVERLAY_ID;
      o.setAttribute('aria-hidden', 'true');
      if (document.body) Object.assign(o.style, { position: 'absolute', top: '0', left: '0', width: '0', height: '0', zIndex: '2147483647', pointerEvents: 'none' });
      else { for (const [k, v] of Object.entries({ x: 0, y: 0, width: '100%', height: '100%' })) o.setAttribute(k, v); o.style.pointerEvents = 'none'; }
      document.documentElement.appendChild(o);
    }
    return o;
  }

  function clearOverlay() { document.getElementById(OVERLAY_ID)?.remove(); }

  function drawBox(el, { color = '#E11D48', badge = '' } = {}) {
    const r = el.getBoundingClientRect();
    const b = htmlEl('div');
    Object.assign(b.style, {
      position: 'absolute', left: `${r.left + scrollX - 3}px`, top: `${r.top + scrollY - 3}px`,
      width: `${r.width + 6}px`, height: `${r.height + 6}px`, outline: `3px solid ${color}`, borderRadius: '4px', boxSizing: 'border-box',
    });
    if (badge) {
      const t = htmlEl('span');
      t.textContent = badge;
      Object.assign(t.style, {
        position: 'absolute', top: '-12px', left: '-12px', minWidth: '22px', height: '22px', padding: '0 5px', borderRadius: '11px',
        background: color, color: '#fff', font: '700 12px/22px system-ui, sans-serif', textAlign: 'center', boxSizing: 'border-box',
      });
      b.appendChild(t);
    }
    overlay().appendChild(b);
  }

  function highlight(target) {
    clearOverlay();
    let el;
    try { el = document.querySelector(target); } catch { return false; }
    if (!el) return false;
    el.scrollIntoView({ block: 'center', behavior: 'instant' });
    drawBox(el);
    return true;
  }

  function showTabOrder() {
    clearOverlay();
    const steps = W.steps.filter(s => s.el.isConnected);
    steps.forEach((s, i) => drawBox(s.el, { color: s.indicator ? '#4F46E5' : '#E11D48', badge: String(i + 1) }));
    return steps.length;
  }

  window.__nsScanner = {
    version: VERSION,
    scan, highlight, clear: clearOverlay, showTabOrder,
    contrastPrep, contrastHide, contrastWhere, settleAnimations, startRecording, stopRecording, pageLayout,
    walkReset, walkStep, walkFinish,
    reflowBefore, reflowCheck, orientationProbe, spacingBefore, spacingAfter, resizeBefore, resizeAfter, autoMoveCheck, motionCheck,
    listTriggers, activate, restore,
    kbdCandidates, kbdBegin, kbdStep, kbdEnd,
    uiFingerprint, uiActions, prepareAction, finishAction, formInfo, focusField, setField, validationTest, closeTop, topIsLayer,
    discoverLinks, navCandidates, isSignIn, settle: () => settle(4000, 500), moreFields, pickOption, checkField, fieldValue, loginField, clickField, prepareButton,
    setSkipRegions, sharedRegions, regionsOfTargets,
    shortcutBaseline, shortcutArm, shortcutCheck, shortcutIssue, putBack,
    pointerCandidates, pointerArm, pointerCheck, pointerIssue,
    judgeListeners, hoverArm, hoverRevealed, hoverIssue,
    hoverMenuCandidates, menuRevealedByHover, menuKeyboardArm, menuKeyboardCheck, menuIssue,
    motionRegions, animatedImageIssue, flashIssue,
    invalidValues, submitForErrors, fieldNode, aiCandidates, roleCandidates, blockedPage,
  };
})();

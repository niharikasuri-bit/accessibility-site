// Shared by DIGIT Accessibility Scanner and DIGIT Accessibility Scanner Admin: clicking the toolbar icon opens the
// scanner in the browser's side panel, and the scanner's website can find the extension and open its dashboard.
// Recording goes on with the side panel closed (lib/background-recorder.js).
import './lib/background-recorder.js';

const openPanelOnClick = () => chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
chrome.runtime.onInstalled.addListener(openPanelOnClick);
chrome.runtime.onStartup.addListener(openPanelOnClick);

// The scanner's website (listed under externally_connectable): "Use the scanner" turns the website's tab into the
// dashboard, which asks for a new project when there is none yet.
async function openScanner(sender) {
  const url = chrome.runtime.getURL('dashboard.html?start=1');
  if (sender.tab?.id != null) await chrome.tabs.update(sender.tab.id, { url });
  else await chrome.tabs.create({ url });
}

chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  if (msg?.type === 'ping') {
    reply({ ok: true, version: chrome.runtime.getManifest().version });
    return false;
  }
  if (msg?.type === 'open-scanner') {
    openScanner(sender).then(() => reply({ ok: true }), e => reply({ ok: false, error: e.message }));
    return true;
  }
  return false;
});

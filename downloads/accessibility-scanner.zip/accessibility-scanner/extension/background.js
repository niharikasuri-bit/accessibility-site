// DIGIT Accessibility Scanner (the website download). Scheduled scans and report emails are only in
// DIGIT Accessibility Scanner Admin, so this extension has no scheduling code at all.
import './background-common.js';

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === 'run-project') reply({ ok: false, error: 'Scheduled scans are only in DIGIT Accessibility Scanner Admin.' });
  return false;
});

# Command line / CI runner

Runs **DIGIT Accessibility Scanner** without anyone at the keyboard. It runs the same tests as the side panel: rules, real keyboard presses, reflow, phone, screen reader preview and "use the app". Use it in a CI pipeline to stop a release that adds High or Severe accessibility failures, or to run a check from a scheduled job.

No paid service is involved. It runs on your computer, or in GitHub Actions (free for public repositories, with free minutes for private ones).

## Install

```sh
cd cli
npm install
npx playwright install chromium
```

## Use

```sh
# Pages
node a11y-scan.mjs --url https://example.gov.in/ --url https://example.gov.in/apply

# Signed-in pages: one --url per page (each step of a form can be its own page)
node a11y-scan.mjs --url https://app.example.org/home --url "https://app.example.org/create?key=1" --url "https://app.example.org/create?key=2" --storage-state auth.json
```

There is no time limit: the scan runs until every page and test is done. The command ends with one of three exit codes:
- **0:** passed.
- **1:** issues at or above `--fail-on` were found. Severities are `severe`, `high`, `medium` and `low`; the default is `high` (High and Severe fail the build). Use `none` to report only.
- **2:** the scan could not run, a page could not be tested, or the product signed out partway. The reports still cover every page that was tested.

The reports folder (default `a11y-results/`) gets:

| File | What it is |
|---|---|
| `report.html` | The full report, the same as "Download report" in the panel |
| `results.json` | Every result, the same as "Export JSON" |
| `junit.xml` | One test case per WCAG 2.2 criterion (fail / pass / skipped), shown by CI dashboards |
| `issues.csv` | One row per issue type, ready for Jira (System → External system import → CSV) |
| `acr-draft.html` | A draft Accessibility Conformance Report (VPAT® 2.5 layout) for an expert to finish |
| `review-tasks.html` | What the Design and Engineering teams still need to check by hand |

## Signed-in products

Save the signed-in session once with Playwright, then pass it with `--storage-state`:

```sh
npx playwright codegen --save-storage=auth.json https://app.example.org/login
```

Sign in in the window that opens, then close it. In CI, store the file's contents as a secret (`A11Y_STORAGE_STATE`). Sessions expire, so refresh the secret when the run reports "signed out".

## GitHub Actions

Copy `accessibility.yml` to `.github/workflows/` in the product repository. Then change the `--url` line and the path to where you put the `extension` and `cli` folders.

## Options

`node a11y-scan.mjs --help` lists every option. They include `--tests quick|standard|everything`, `--never-click <words>` and `--extension <dir>`. The scanner tests the pages you list: there is no crawl.

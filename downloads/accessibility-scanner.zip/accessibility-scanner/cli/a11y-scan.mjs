#!/usr/bin/env node
/*
 * DIGIT Accessibility Scanner — command line / CI runner.
 *
 * Runs the real extension in headless Chromium (the same tests as the side panel: rules, real
 * keyboard presses, reflow, phone, screen reader preview, "use the app"), then writes the reports
 * and exits non-zero when failures at or above --fail-on are found.
 *
 *   node a11y-scan.mjs --url https://example.gov.in/ --url https://example.gov.in/apply
 *   node a11y-scan.mjs --url https://app.example.org/home --url https://app.example.org/apply?key=2 --storage-state auth.json
 *
 * Options:
 *   --url <address>          page to test; repeat it for every page (the scanner tests the pages you list)
 *   --tests quick|standard|everything   default: standard. quick = rules only, otherwise the full test.
 *   --fail-on severe|high|medium|low|none   default: high
 *   --storage-state <file>   Playwright storage state with the signed-in session (cookies, localStorage)
 *   --never-click <words>    comma-separated words never to click, added to the defaults
 *   --out <dir>              reports folder (default: a11y-results)
 *   --extension <dir>        extension folder (default: ../extension next to this file)
 *
 * There is no time limit: the scan runs until every page and test is done.
 *
 * Exit codes: 0 passed · 1 issues at or above --fail-on · 2 could not run, a page could not be tested, or signed out
 *             partway (reports still cover what was tested)
 */
import { chromium } from 'playwright';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const IMPACTS = ['critical', 'serious', 'moderate', 'minor'];
const SEVERITY = { critical: 'Severe', serious: 'High', moderate: 'Medium', minor: 'Low' };
const BY_NAME = { severe: 'critical', high: 'serious', medium: 'moderate', low: 'minor' }; // what people type → axe's values

function parseArgs(argv) {
  const o = { urls: [], tests: 'standard', failOn: 'high', out: 'a11y-results', neverClick: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const next = () => { if (i + 1 >= argv.length) throw new Error(`${a} needs a value`); return argv[++i]; };
    if (a === '--url') o.urls.push(next());
    else if (a === '--crawl' || a === '--max-pages') throw new Error(`${a} is no longer supported: the scanner tests the pages you list. Give each page with --url (repeat it for every page).`);
    else if (a === '--tests') o.tests = next();
    else if (a === '--fail-on') o.failOn = next();
    else if (a === '--storage-state') o.storageState = next();
    else if (a === '--never-click') o.neverClick.push(...next().split(',').map(w => w.trim()).filter(Boolean));
    else if (a === '--out') o.out = next();
    else if (a === '--extension') o.extension = next();
    else if (a === '--help' || a === '-h') o.help = true;
    else throw new Error(`Unknown option ${a}`);
  }
  if (!o.help) {
    if (!o.urls.length) throw new Error('Give at least one --url');
    for (const u of o.urls) if (!/^https?:\/\//i.test(u)) throw new Error(`Not a web address: ${u}`);
    if (!['quick', 'standard', 'everything'].includes(o.tests)) throw new Error('--tests must be quick, standard or everything');
    o.failOn = o.failOn.toLowerCase();
    if (![...Object.keys(BY_NAME), ...IMPACTS, 'none'].includes(o.failOn)) throw new Error('--fail-on must be severe, high, medium, low or none');
    o.failOn = BY_NAME[o.failOn] || o.failOn;
  }
  return o;
}

const xml = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// One JUnit test case per WCAG criterion: fail → failure, not decided → skipped, so CI dashboards show the checklist.
export function junitXml(data) {
  const issues = allIssues(data);
  const cases = (data.checklist || []).map(c => {
    const own = issues.filter(i => i.kind === 'violation' && !i.bestPractice && i.wcag?.includes(c.id));
    const name = `${c.id} ${c.name} (${c.level})`;
    if (c.status === 'fail') {
      const text = own.map(i => `${i.title} — ${i.page}\n${(i.nodes || []).slice(0, 5).map(n => `  ${n.html || n.target || ''}`).join('\n')}`).join('\n\n');
      return `    <testcase classname="WCAG 2.2" name="${xml(name)}"><failure message="${xml(`${own.length} issue type(s)`)}">${xml(text)}</failure></testcase>`;
    }
    if (c.status === 'pass' || c.status === 'reviewed') return `    <testcase classname="WCAG 2.2" name="${xml(name)}"/>`;
    return `    <testcase classname="WCAG 2.2" name="${xml(name)}"><skipped message="${xml(c.status === 'na' ? 'Not applicable' : 'Needs review by a person')}"/></testcase>`;
  });
  const failures = (data.checklist || []).filter(c => c.status === 'fail').length;
  const skipped = (data.checklist || []).filter(c => !['fail', 'pass', 'reviewed'].includes(c.status)).length;
  return `<?xml version="1.0" encoding="UTF-8"?>\n<testsuites>\n  <testsuite name="Accessibility (WCAG 2.2 AA)" tests="${cases.length}" failures="${failures}" skipped="${skipped}">\n${cases.join('\n')}\n  </testsuite>\n</testsuites>\n`;
}

// Every finding with the page it is on; site-wide ones (multiple ways, GIGW) are "whole site".
function allIssues(data) {
  return [
    ...(data.pages || []).flatMap(p => Object.values(p.results || {}).flat().map(i => ({ ...i, page: p.url }))),
    ...(data.sessionIssues || []).map(i => ({ ...i, page: 'Whole site' })),
  ];
}

// Failures at or above the threshold (best-practice advice never fails a build).
export function blocking(data, failOn) {
  if (failOn === 'none') return [];
  const limit = IMPACTS.indexOf(failOn);
  const seen = new Map();
  for (const i of allIssues(data)) {
    if (i.kind !== 'violation' || i.bestPractice || IMPACTS.indexOf(i.impact) > limit) continue;
    const g = seen.get(i.ruleId) || { ruleId: i.ruleId, title: i.title, impact: i.impact, wcag: i.wcag || [], pages: new Set() };
    g.pages.add(i.page);
    seen.set(i.ruleId, g);
  }
  return [...seen.values()].sort((a, b) => IMPACTS.indexOf(a.impact) - IMPACTS.indexOf(b.impact));
}

async function main() {
  const o = parseArgs(process.argv.slice(2));
  if (o.help) { console.log(fs.readFileSync(fileURLToPath(import.meta.url), 'utf8').split(' */')[0].split('\n').slice(2).map(l => l.replace(/^ \* ?/, '')).join('\n')); return 0; }
  const ext = path.resolve(o.extension || path.join(HERE, '..', 'extension'));
  if (!fs.existsSync(path.join(ext, 'manifest.json'))) throw new Error(`No extension found at ${ext}`);
  const out = path.resolve(o.out);
  fs.mkdirSync(out, { recursive: true });
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'a11y-scan-'));
  const cleanUp = () => { try { fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 500 }); } catch { /* Windows may still hold a file; the OS temp folder is cleaned later */ } };
  let ctx;
  try {
    ctx = await chromium.launchPersistentContext(profile, {
      headless: false, args: ['--headless=new', `--disable-extensions-except=${ext}`, `--load-extension=${ext}`],
      viewport: { width: 1280, height: 900 }, acceptDownloads: true,
    });
  } catch (e) {
    cleanUp();
    throw e;
  }
  try {
    if (o.storageState) {
      const state = JSON.parse(fs.readFileSync(o.storageState, 'utf8'));
      if (state.cookies?.length) await ctx.addCookies(state.cookies);
      for (const { origin, localStorage = [] } of state.origins || []) {
        await ctx.addInitScript(([org, items]) => {
          if (location.origin !== org || window !== window.top || sessionStorage.getItem('__a11yStateApplied')) return;
          for (const { name, value } of items) localStorage.setItem(name, value);
          sessionStorage.setItem('__a11yStateApplied', '1');
        }, [origin, localStorage]);
      }
    }
    let [sw] = ctx.serviceWorkers();
    if (!sw) sw = await ctx.waitForEvent('serviceworker');
    const id = sw.url().split('/')[2];
    const site = ctx.pages()[0] || await ctx.newPage();
    site.on('dialog', d => d.dismiss().catch(() => {}));
    const panel = await ctx.newPage();
    await panel.goto(`chrome-extension://${id}/sidepanel.html`);
    await panel.evaluate(async ({ tests, neverClick }) => {
      const { DEFAULT_SETTINGS } = await import('./lib/defaults.js');
      await chrome.storage.local.set({ settings: { ...DEFAULT_SETTINGS, noLimits: true, crawlTests: tests, neverClick: [...new Set([...DEFAULT_SETTINGS.neverClick, ...neverClick])], ai: false } });
    }, { tests: o.tests, neverClick: o.neverClick });
    await panel.reload();
    // Panel messages answer confirm() prompts (Deep mode is never on here, so none are expected).
    panel.on('dialog', d => d.dismiss().catch(() => {}));
    let signedOut = false;
    // Finished = a final status and the panel idle again (Stop hidden), or paused waiting for someone to sign in.
    const isDone = () => {
      const s = document.getElementById('status');
      return (/status (ok|error)/.test(s.className) && document.getElementById('btn-stop').hidden) || !document.getElementById('btn-continue').hidden;
    };
    // The panel runs the ticked tests with one Scan button: none ticked = the quick page scan, all = the full test.
    const start = async all => {
      await panel.evaluate(all => {
        const s = document.getElementById('status'); s.className = 'status'; s.textContent = '';
        document.querySelectorAll('[data-pick]').forEach(c => { c.checked = all; });
      }, all);
      await panel.click('#btn-run');
    };
    const finished = async () => {
      await panel.waitForFunction(isDone, null, { timeout: 0, polling: 1000 }); // no time limit
      // Paused for sign-in: nobody can sign in here, so stop and report what was tested.
      if (!(await panel.isHidden('#btn-continue'))) {
        signedOut = true;
        await panel.click('#btn-stop').catch(() => {});
        await panel.waitForFunction(isDone, null, { timeout: 180000 }).catch(() => {});
      }
    };
    // Pages that could not be tested; the others are still reported (exit code 2 at the end).
    const pageErrors = [];
    const outcome = async url => {
      if (signedOut) return 'Stopped: the product signed out partway.';
      const status = await panel.textContent('#status');
      if ((await panel.getAttribute('#status', 'class')).includes('error')) {
        pageErrors.push(`${url}: ${status}`);
        return `could not be tested — ${status}`;
      }
      return status;
    };
    const fullTest = o.tests !== 'quick';
    for (const url of o.urls) {
      if (signedOut) break; // the rest would only show the sign-in page
      try {
        await site.goto(url, { waitUntil: 'load', timeout: 60000 });
      } catch (e) {
        pageErrors.push(`${url}: ${e.message.split('\n')[0]}`);
        console.log(`${url}: could not be opened — ${e.message.split('\n')[0]}`);
        continue;
      }
      // Sent to a sign-in page instead: the session has ended, and nobody can sign in here.
      if (site.url() !== url && await site.locator('input[type="password"]').first().isVisible().catch(() => false)) {
        signedOut = true;
        console.log(`${url}: the product showed its sign-in page instead (signed out)`);
        break;
      }
      await site.bringToFront();
      await panel.waitForTimeout(300);
      await start(fullTest);
      await finished();
      console.log(`${url}: ${await outcome(url)}`);
    }
    const tested = await panel.evaluate(async () => ((await chrome.storage.local.get('session')).session?.pages || []).filter(p => p.scannedAt).length);
    if (!tested) {
      console.log(`\nNo page could be tested.${pageErrors.length ? `\n  ${pageErrors.join('\n  ')}` : ''}`);
      return 2;
    }
    // The panel's own exports, so CI files match what people download by hand.
    const save = async (btn, name) => {
      // Export choices sit in the Issues tab's Export menu: pressed directly, whichever tab is showing.
      const [dl] = await Promise.all([panel.waitForEvent('download', { timeout: 30000 }), panel.$eval(btn, b => b.click())]);
      await dl.saveAs(path.join(out, name));
      return path.join(out, name);
    };
    const jsonFile = await save('#btn-export-json', 'results.json');
    await save('#btn-export-html', 'report.html');
    await save('#btn-export-csv', 'issues.csv');
    await save('#btn-export-acr', 'acr-draft.html');
    await save('#btn-export-review', 'review-tasks.html');
    const data = JSON.parse(fs.readFileSync(jsonFile, 'utf8'));
    for (const p of data.pages || []) if (p.note && !pageErrors.some(e => e.startsWith(`${p.url}:`))) pageErrors.push(`${p.url}: ${p.note}`); // tested only partly
    fs.writeFileSync(path.join(out, 'junit.xml'), junitXml(data));
    const fails = blocking(data, o.failOn);
    const failing = (data.checklist || []).filter(c => c.status === 'fail').length;
    console.log(`\n${data.pages.length} page(s) tested · ${failing} of ${(data.checklist || []).length} WCAG 2.2 A/AA criteria fail · reports in ${out}`);
    // The issues found are always listed; then the exit code says what went wrong, most serious first.
    if (fails.length) {
      console.log(`\n${fails.length} issue type(s) at or above "${SEVERITY[o.failOn]}":`);
      for (const f of fails) console.log(`  [${SEVERITY[f.impact] || f.impact}] ${f.title}${f.wcag.length ? ` (WCAG ${f.wcag.join(', ')})` : ''} — ${f.pages.size} page(s)`);
    }
    if (pageErrors.length) {
      console.log(`\n${pageErrors.length} page(s) could not be tested, or only partly:\n  ${pageErrors.join('\n  ')}`);
      return 2;
    }
    if (signedOut) {
      console.log('\nThe product signed out partway, so these results are partial. Refresh the --storage-state file and run again.');
      return 2;
    }
    if (fails.length) return 1;
    console.log(o.failOn === 'none' ? '\nNot failing the build (--fail-on none).' : `\nNo issues at or above "${SEVERITY[o.failOn]}".`);
    return 0;
  } finally {
    await ctx.close().catch(() => {});
    cleanUp();
  }
}

const invokedPath = () => { try { return fs.realpathSync(process.argv[1]); } catch { return path.resolve(process.argv[1]); } };
if (process.argv[1] && invokedPath() === fs.realpathSync(fileURLToPath(import.meta.url))) {
  main().then(code => process.exit(code), e => { console.error(`Error: ${e.message}`); process.exit(2); });
}

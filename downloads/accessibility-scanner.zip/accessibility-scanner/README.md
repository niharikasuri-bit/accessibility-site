# DIGIT Accessibility Scanner

A browser extension that tests web pages against **WCAG 2.2 Level AA**, and maps every
finding to **ADA, GIGW 3.0 and SESMag**, in the style of BrowserStack Accessibility.
Everything runs inside the user's own browser: no server, no API keys, nothing to
switch on or off, and nothing costs money.

There are two extensions, built from one source:

| | **DIGIT Accessibility Scanner** ("A" icon) | **DIGIT Accessibility Scanner Admin** ("N" icon) |
|---|---|---|
| Who | Everyone: the website download | The admin only: the `extension/` folder, never published |
| Scanning, Deep mode, live recording, dashboard, reports | ✅ | ✅ |
| Scheduled scans, report emails, relay, Slack, admin page | ❌ no code for them at all | ✅ |
| Extension ID | `llblpimelojllmohcbklacgddnbloecc` (the website finds it by this) | `hggncokbhbfedcfecjhjmfjoikjpghml` |

`site/build.py` makes the download from `extension/`: it leaves out the admin page, the Scheduled scans page and the
scheduling and email code, and puts in the files from `site/public-build/` (a background without scheduling, an admin
check that is always "no", the "A" icons) and its own name, ID and permissions.

## Install (free, no store needed)

Works in **Microsoft Edge** and **Google Chrome**.

1. Open `edge://extensions` (Edge) or `chrome://extensions` (Chrome).
2. Switch on **Developer mode**.
3. Click **Load unpacked** and choose the `extension` folder.
4. Pin the extension, open any website, and click the icon. The scanner opens in the side panel.

To scan local `file://` pages, open the extension's **Details** and switch on **Allow access to file URLs**.

**After updating the files**, press **Reload** on the extension in `edge://extensions` / `chrome://extensions`. The browser keeps running the old background code (the scheduler) until you do.

## The website (`site/`)

A one-page website in the DIGIT Design System site's theme (design.digit.org: navy #0E165D, DM Sans and Open
Sans), in this order: the hero, **Get the scanner** (a card each for the Claude skill and the Chrome extension, like
design.digit.org's "Explore" cards: a tinted banner with its logo, one plain paragraph, **View Install Steps →**, which
opens the steps in a dialog, and a Download text button),
**What the scanner tests** (3 square cards, Page check, Keyboard and Screen reader, like design.digit.org's "DIGIT Design
Philosophy": a picture and title, with the details on hover or keyboard focus) and
**Checklists for your team** (a
card each, with a picture, for the developer, design and content checklists: what to check while building, each item
with the standards it supports: WCAG 2.2, ADA, GIGW 3.0 and SESMag). A card's **Download PDF** opens the
browser's print dialog with that checklist styled like the report emails, an empty box per item; choose "Save as PDF".

- **Use the scanner** (top bar, hero and the extension card): with the extension installed, the website's tab turns
  into the scanner's **dashboard** (the Scan log). Without it, the install steps
  appear (download, Load unpacked, pin), and the page opens the dashboard by itself once the extension is installed. The site talks to
  the extension by its fixed ID; only the addresses in the manifest's `externally_connectable` (localhost, 127.0.0.1
  and niharikasuri-bit.github.io) can.
- Run it on this computer: `cd site`, `python -m http.server 5600`, open `http://localhost:5600/`.
- Rebuild the downloads after changing the extension, the CLI or the skill: `python build.py` in `site/`. It makes
  `downloads/accessibility-scanner.zip` (DIGIT Accessibility Scanner: `extension/` without the admin page, scheduled
  scans or report emails, with `site/public-build/`; and `cli/`) and `downloads/accessibility-scanner-claude-skill.zip` (`SKILL.md` and `site/checklists.js`).
  `python build.py --check` lists any file where a zip no longer matches the folders.

## Claude skill (`claude-skill/accessibility-scanner/`)

A Claude Code skill that checks **code**: ask Claude Code to check code, components, a folder or a pull request, and
it reads the source and reports problems by file and line, working through the developer checklist (`site/checklists.js`
is copied into the zip as `checklists.js`). Pages, including an app on `localhost`, are tested with the extension.
Each problem comes with its WCAG criterion, the standards it affects (WCAG 2.2 AA, ADA, GIGW 3.0, SESMag), its
severity and a short code fix; Claude changes code only when asked. Install by unzipping it into `~/.claude/skills/`;
nothing else needs installing.

Findings from the extension can be pasted into Claude Code: the skill finds where each element comes from in the source
(by its text, `id`, labels and readable class names, narrowed by the page and the recorded step) and fixes it there. It
gives a file and line only when it is sure, and lists the likely files otherwise.

## Projects (scheduled emails, Admin only)

Projects exist only for **scheduled report emails**, in the Admin extension's dashboard under **Scheduled emails**.
A project has a name, whether the product has a login (the login page link, each field of the login page, the button
to press and the page address after signing in) and the links to scan, one per line (each step of a form can be its
own line). The scheduled scan opens each link, signs in with the project's login when a page shows the login page,
tests it and emails the reports. Login values are kept only in this browser and never appear in results, reports,
exports or the status line; use a test account. The dashboard itself no longer scans listed pages.

## Standards checklist (dashboard)

A pass / fail list for each standard, picked at the top of the view:

- **WCAG 2.2 AA**: the 55 Level A and AA success criteria.
- **ADA**: WCAG 2.1 Level A and AA (the Title II rule) — the 2.2 list without the 6 criteria new in 2.2 (49).
- **GIGW 3.0**: its 12 required items (privacy, terms, copyright and hyperlinking policies, accessibility statement,
  help, contact us, sitemap, feedback, Hindi / English switch, skip link, "last updated" date), then WCAG 2.1 A/AA.
- **SESMag**: its seven checks (page weight, reading ease, raw technical text, very small text, icon-only buttons,
  personal data without an explanation, media that plays by itself).

Each item is No failures found, Fails, Couldn't verify, Needs review, Passed in review or Not applicable. A check
with nothing to look at on the scanned pages (no form fields, no media, too little English text) is Not applicable,
never a pass; a page weight hidden by other sites' files is Couldn't verify. A GIGW policy left to the site's policy
page is Couldn't verify until a person reviews that page, then Passed in review or Fails. The checklist ignores the
Issues tab's Test, type and standard filters (only the page filter applies), so it reflects every test that ran. The downloaded report, the scheduled
report PDF, the JSON export and the compliance percentages (dashboard, emails, PDFs) all come from these same lists:
items passed (by the tests or in review) out of items passed or failed.

## Admin page (DIGIT Accessibility Scanner Admin only)

`admin.html` in the extension: a password chosen the first time (at least 10 characters, kept only as a salted hash
in this browser). Unlocked, it opens the projects page (every project, Run now, the scan logs) and **Settings**: the
sender email (Google sign-in, no password stored) and the **email relay**; Slack stays there too. **Lock admin** locks
it again; it also locks when the browser closes. Without the password the projects page goes to the password screen,
and the dashboard's Scheduled scans never shows Settings. DIGIT Accessibility Scanner (the download) has none of it:
no admin page and no **scheduled scans**. Only the Admin extension has the Scheduled scans tab and button, the
one-minute schedule alarm and Run now; the download scans on demand.

**Email relay** (optional, for the admin's copy): instead of the Google sign-in, the admin's scheduled scans can send
report emails through a small free Google Apps Script in the admin's Google account, which
sends from the admin's address. Settings → **Copy relay script** (the key is filled in) → script.google.com, new
project, paste, save → Deploy → New deployment → Web app, Execute as: Me, Who has access: Anyone → paste the Web app
URL → **Check relay**. Never put a `relay.json` in the public download: its key would be public. The relay only
sends the scanner's own emails (report, review-task and failed-scan emails, with the scanner's footer), to at most 50
addresses each, at most 80 a day (`MAX_PER_DAY` in the script), and only with the key; **Make a new key** switches off
every old copy. On the admin's own computer the Google sign-in is used first, and the relay when it has expired.

## The dashboard

Open the side panel (the scanner's toolbar icon) and press the **Open dashboard** icon. The dashboard opens in a tab
(an open one is reused).

- **Scan log** (everyone): every scan started with the side panel's **Scan this page** button and every recorded
  workflow, newest first; the latest 25 are kept. Each scan is named after its product and numbered per product
  (`HCM Console Scan001`, `Scan002` …; recordings `HCM Console Recording001` …; numbers are never reused). Filters (search, product, tests, Severe issues) and a table: scan and date, page, tests (Full
  test, Page scan or the number of tests, with Safe / Deep when "Use the app" ran), issues by severity, average
  adherence and **Download report** for each row. Tick rows to **Download** or **Delete** several at once.
- **A scan's dashboard** (open its name): **Overview** (average adherence gauge, adherence by standard, issues by
  severity), **Issues**, **Standards checklist**, **Review tasks** and **Screen reader** for that scan only, with
  **Download report**, **More exports** (review tasks, Jira CSV, ACR / VPAT draft, JSON) and **Delete this scan**.
  Review decisions made here are saved into the scan.
- **Scheduled emails** and **Sender details** (Admin extension only): the projects, schedules, recipients and email
  log, and the sender (Gmail sign-in or relay, Slack), inside the dashboard.

The side panel has three tabs: **Scan** (tick the tests, **Record workflow**, one **Scan this page** button),
**Issues** (the side panel's own results, with exports) and **Settings** (interaction mode, never-click list,
most actions per run, AI review).

## Record a workflow

Turn on **Record workflow** (side panel or dashboard) and use the product as you normally would: every page you
open in that tab is scanned, and **every action you take is tested as you take it**:

- a control you used with the mouse must also be reachable from the keyboard (2.1.1);
- a dialog it opens must take focus, and focus must not be lost when a dialog closes (2.4.3);
- a message it brings up ("Saved", an error) must be announced to screen readers (4.1.3);
- each new screen it leads to (a dialog, a panel, a new view) is scanned once.

Each finding says which step it came from (*Recorded step 3: Pressed "Assign"*). The steps keep only the name of the
control or field ("Filled in "Mobile number""), never what you typed or chose. The scanner never clicks anything while
you record, and its own test actions are not recorded. Use it for real tasks you click through yourself, including the
screens after saving that the automated Deep mode never reaches.

Recording goes on with the side panel closed: the extension's background tests each action and scans each page, and
the panel shows it all when opened again. **REC** on the toolbar icon shows a recording is on. When you stop
recording, click **Clear**, or close the recorded tab, the recording is saved to the Scan log as one entry with every
page it covered.

## Scheduled scans and report emails

Only in DIGIT Accessibility Scanner Admin (the download has no scheduled scans). Pick the project in the dashboard and open **Scheduled scans** (the side panel's **Scheduled scans** button opens it
too). The project's links and login are already there; add the recipients and the time, and save. The admin page
lists every project with Run now and the logs.

- **Schedule**: Product Owner (To),
  Engineering Team and Additional Recipients (CC), schedule (Today, Daily, Weekly on chosen days, Monthly on a
  date or e.g. "first Monday"; time, timezone, Ends), email and Slack notifications. Pause or activate
  from the list.
- **Emails**: subject "Accessibility Report of …". The first email is an initial report; later emails compare
  with the previous run (average adherence, severity and per-standard adherence changes, plus the issue types that are **new** and
  **fixed**). PDFs attached: Full Report, Issues, and Issues by page for whole-site scans. Failure emails go to
  the Product Owner once a first report has been sent.
- **Adherence (no score)**: there is no 0–100 score. The headline is **average adherence**: the mean of the adherence of WCAG 2.2 AA, ADA, GIGW 3.0 and SESMag (the standards that were tested). Pages are listed by their most severe issues. **Scope**: the scanner reports only WCAG 2.2
  Level A and AA and what ADA and GIGW 3.0 require (plus SESMag); AAA and best-practice checks are not run or
  reported (`AXE_TAGS` in `content/engine.js`, `inScope` in `lib/runner.js`). Links shown by colour alone at 3:1 or more
  go to "needs a person" under 1.4.1 (they pass only if they also change on hover and focus).
  Adherence per standard is the share of its WCAG criteria tested on these pages that passed, plus the
  standard's own checks (GIGW elements, SESMag's seven checks).
- **Email Send Log** per project: status, live progress stages, and PDF downloads (last 5 sends kept).
- **Slack**: a summary is posted to the project's webhook (or the default one in Settings), and "Test
  Connection" really sends a test message.

How it runs: a timer in the extension checks every minute. When a project is due, a background tab opens
(nothing pops up in front of you; a window of its own only when no browser window is open), tests the project's links (signing in with its login), builds the PDFs and sends the email: from the admin's
Gmail account on the admin's computer, through the admin's email relay everywhere else.
Needs the computer on and Edge or Chrome open; scans missed while the browser was closed run when it next
opens. If the product shows a sign-in page, the run is logged as "Scan Failed" and a notification appears.

**Email setup (one time, free, admin page)**: Settings → Email Delivery. Create a Google OAuth client ID (steps are on the
page), add the redirect URI shown there, paste the client ID, press **Sign in with Google**, then **Send Test**.
The Admin extension has a fixed ID (`hggncokbhbfedcfecjhjmfjoikjpghml`), so the redirect URI never changes.

This project is independent: it shares no code with digit-a11y-agent. Reports, emails and PDFs are built by
`extension/lib/reporting.js`.

## Results: failures, not "please review"

Each finding is either a **failure** (a definite test failed) or, rarely, **couldn't verify**
(the page gave the test nothing it could measure). The **Standards checklist** tab shows
all 55 Level A and AA criteria as *Fails*, *No failures found*, *Not applicable* or
*Needs judgement*.

## Tests

| Test | What it does | WCAG 2.2 criteria |
|---|---|---|
| **Scan page** | axe-core rules for WCAG 2.0 / 2.1 / 2.2 A and AA, plus: actually pastes into password and OTP fields; finds CAPTCHAs with no alternative; drag-only items; the WCAG 24px target-spacing test; elements that look clickable but can't be focused. Contrast that axe can't decide (text on images, gradients, overlaps) is **measured from a real screenshot** of the background. | 1.4.3, 2.1.1, 2.5.7, 2.5.8, 3.3.8 and everything axe covers |
| **Keyboard walk** | Presses the real Tab key through the page: missing focus indicators, focus hidden behind sticky bars, focus on invisible elements, tab order changed by positive tabindex or CSS, keyboard traps, focus that changes the page. **Show tab order** draws numbered boxes. | 2.1.1, 2.1.2, 2.4.3, 2.4.7, 2.4.11, 3.2.1 |
| **Keyboard interactions** | Works out what each control *is* and tests it with the keys that kind of control must answer to. Custom buttons and links: Enter/Space, compared with a mouse click. Real buttons (every one) and real links (one of each kind, up to 12): Enter (and Space on buttons) must reach them and they must not act only on a mouse press; their click is caught and cancelled, so Next, Save or a link is checked without running. Checkboxes and switches: Space. Radio groups and tabs: Space/Enter and arrow keys. Sliders: arrow keys. Menus and pop-ups: open, reach the options, Escape. Dialogs: focus moves in, Escape or a reachable Close button closes it, focus returns. Skip links: the target exists and Enter moves there. Tooltips shown on focus: Escape dismisses them. Dropdowns: choosing an option doesn't change the page by itself. | 1.4.13, 2.1.1, 2.1.2, 2.4.1, 2.4.3, 3.2.2 |
| **Use the app** (Safe mode) | Opens menus, tabs, accordions and dialogs one by one and scans each new state. Never saves anything. | everything axe covers, in hidden UI |
| **Use the app** (Deep mode) | Uses the app like a person testing it, on any kind of app (a workflow configurator, a form builder, a dashboard): clicks "Add", "New", "Edit", cards and canvas nodes with real mouse clicks; in every form it presses Save with the fields empty, then with wrongly formatted values, to test the error messages, and then closes the form **without saving** (Cancel). It never creates test data. Every new screen is scanned, and every new dialog gets the keyboard interaction tests. It also checks that pop-up messages ("Saved", errors) are announced to screen readers, and that focus isn't lost when a dialog closes. Each finding shows the path that led to it, for example *Start → + Add state → Save*. | 1.3.1, 1.4.1, 2.4.3, 3.3.1, 4.1.3, plus everything above on each new screen |
| **Reflow at 320px** | Resizes to 320px (equal to 400% zoom) and finds what scrolls sideways. | 1.4.10 |
| **Phone** | Emulates a phone (390 × 844, touch), scans again (target size, content hidden on small screens), then turns it to landscape: content that only works in one orientation, or "please rotate your device" messages, fail. | 1.3.4, 2.5.8 and everything the scan covers |
| **Screen reader preview** | Lists what a screen reader announces, in reading order, from Chrome's accessibility tree (the information NVDA, JAWS, VoiceOver and TalkBack read): landmarks, headings, links, buttons, fields with their states, images. Filter to "only items with no name". Shown in the **Screen reader** tab. | Helps review 1.3.1, 1.3.2, 2.4.6, 4.1.2 |
| **Text spacing** | Applies the WCAG spacing values and finds text that gets cut off. | 1.4.12 |
| **Motion** | Watches carousels for 3 seconds to see if they move by themselves, then turns on "reduce motion" and finds endless animations, each without a pause control. | 2.2.2 |
| **Record workflow** | Scans every page you visit in the tab and tests every action you take (keyboard reach of what you clicked, focus into and out of dialogs, announced messages), scanning each new screen; builds one session across a journey. Also checks that help is offered consistently across pages. | 2.1.1, 2.4.3, 3.2.6, 4.1.3 |
| **GIGW 3.0** | Across all scanned pages: privacy, terms, copyright and hyperlinking policies, accessibility statement, help, contact, sitemap, feedback, Hindi/English switch, skip link, "last updated" date. A "Website Policies" page counts for all four policies; a site-named policy page ("DigiLocker Policy") becomes a review task to confirm what it covers. | — |
| **SESMag** | Page weight, reading level, raw technical errors, icon-only buttons, tiny text, unexplained requests for personal data, autoplay. | — |

### Interaction settings

- **Safe** (default): never presses Delete, Remove, Logout, Submit, Pay, Save, Send, Approve, Reject or similar buttons, and never submits forms.
- **Deep**: also opens "Add" forms and tests their error messages (empty and wrongly formatted values), then cancels. It **never saves** and never presses a form's Save / Submit otherwise, so no test data is created. It asks for confirmation once per site; an app that accepts an empty or wrong form could still save it, so a test or UAT site is safest.
- **Never click**: an editable list of words. Deep mode never clicks a button or link containing them (default: delete, remove, log out, sign out, pay, purchase, buy, deactivate, unsubscribe, archive, discard, reset, publish, deploy, go live, send, approve, reject).
- **Most actions per run**: default 0 = no limit (it keeps going until every control has been used). Each control is used at most twice per run, so "+ Add" adds two items, not sixty.
- Deep mode never fills in or submits sign-in forms, never follows links to other websites, and returns to the starting page when it finishes.

### How findings map to standards

- **WCAG 2.2 AA**: any finding tied to a WCAG 2.2 Level A or AA criterion.
- **ADA**: WCAG 2.0 and 2.1 Level A/AA findings. The US DOJ 2024 Title II rule adopts WCAG 2.1 AA.
- **GIGW 3.0**: WCAG 2.0 and 2.1 A/AA findings plus the GIGW-only checks above. This assumes GIGW 3.0 aligns with WCAG 2.1 AA; confirm against the official GIGW 3.0 document.
- **SESMag**: findings tagged with the facet they affect.

## No limits

Nothing is cut short by time or by a count: every page found, every control, every element and every finding is
tested and listed. Long scans of big products can take a while; **Stop** ends one at any time and keeps everything
tested so far. Two things are deliberately not repeated: records with the same layout (`/complaint/101`,
`/complaint/102`, …) are tested twice, not once each (a different screen behind the same kind of address, such as
`?key=5`, is still tested), and each control is used at most twice in Deep mode.

## Reports and integrations

- **Download report** (HTML; print to PDF), **Export JSON**, **Download review tasks** (Design / Engineering).
- **Export issues CSV (Jira)**: one row per issue type with priority, WCAG labels, pages, elements and the
  suggested fix. Import in Jira with System → External system import → CSV (also opens in Excel / Sheets).
- **Download ACR / VPAT draft**: an Accessibility Conformance Report in the VPAT® 2.5 WCAG layout. It is a
  draft for an expert to finish: "Supports" is only used where the team passed the criterion in review;
  automated results alone are reported as "Not Evaluated" with what the tests found.
- **Command line / CI** (`cli/`): runs the same tests headlessly in a pipeline (GitHub Actions template
  included), writes all the reports plus `junit.xml`, and fails the build on High and Severe issues. See `cli/README.md`.

## Honest limits

- 5 criteria have no automated test at all (1.2.3, 1.2.4, 1.2.5 audio description and live captions,
  1.4.5 images of text, 3.3.4 error prevention for legal / financial submissions); they become review tasks.
  Judgement calls (is this alt text *meaningful*?) use the on-device AI when the computer supports it,
  otherwise they also become review tasks.
- "No failures found" means the tests covering that criterion found nothing; it is not proof of conformance.
  A conformance claim (the ACR) still needs an expert's review.
- **Native mobile apps** (iOS / Android) are not tested — only websites and web apps, including at phone size.
  That needs real devices or emulators driven by a cloud service (BrowserStack App Accessibility, for example).
- The **screen reader preview** reads Chrome's accessibility tree; it is not NVDA, JAWS, VoiceOver or TalkBack.
  Real screen reader quirks and spoken live updates still need a person with a screen reader
  (the "Screen reader pass" review task).
- PDFs and other documents linked from pages are not checked.
- Pages that block automated browsers (access denied, bot checks) or return an error page (404, 5xx) are
  reported as "could not be tested", never scanned as if they were the real page. Some government portals
  (india.gov.in, uidai.gov.in) block the headless browser the command line uses; in your own Chrome they
  usually open normally.
- Only the top page is scanned; content inside iframes is not.
- Keyboard, contrast, reflow and motion tests use Chrome's debugging API (to press real keys, take
  screenshots and resize the page), so Chrome shows a "started debugging this browser" bar while they
  run. They cannot run while DevTools is open on the same tab.
- If a control opens another page during the keyboard interaction test, the test stops there and says so.
- Firefox needs a small port.

## Accuracy (measured 30 Oct 2026)

**Benchmark: GOV.UK Accessibility Tool Audit** — 142 test pages, each with one known barrier, built by the UK
Government Digital Service to compare automated checkers. Scored strictly: a case counts only when the scanner
flags *that* barrier (the rule that fired must match the barrier), not something else on the page.

| Tool | Barriers found (of 142) |
|---|---|
| **This scanner (rules only, no AI)** | **116 as failures, plus 5 more as Design/Engineering review tasks** |
| axe-core 4.11 (run on the same pages, same strict scoring) | 37 |
| IBM Equal Access (same) | 36 |
| HTML_CodeSniffer / Pa11y (same) | 28 |
| SortSite (best published, 2018) | 50 |
| All 13 published tools combined (2018) | 98 |

The published results are GDS's 2018 runs of older tool versions; axe-core, IBM and Pa11y were run here on the
same pages. The AI review was not part of this run (the test browser has no on-device model), so on a capable
machine AI findings come on top.

Before the false-alarm work this was 122 failures. Six barriers moved on purpose, because the same rules raised
false alarms on real, well-built sites: three short foreign-language phrases, bold text used as a heading and a
wrong focus order are now review tasks (a person confirms them), and a table with two levels of row headers is
now best-practice advice.

**False alarms**: 15 pages of sites built to a very high standard (GOV.UK, GOV.UK Design System, NHS, W3C WAI,
the A11Y Project, USWDS, digital.gov) were scanned with every test. Every WCAG failure reported was checked by
hand against WCAG; all were real (for example 19px step links directly under a button on GOV.UK "Register to
vote", French list items marked as English on W3C WAI). Each test round checks that no new ones appear.

**Coverage**: 50 of the 55 WCAG 2.2 A/AA criteria have automated or AI tests. The other 5 (audio description,
live captions, images of text, error prevention for legal/financial submissions) become Design/Engineering review tasks.

## Review tasks for the Design and Engineering teams

Anything automated tests and AI cannot decide becomes a task, tagged **Design**, **Engineering** or **Design + Engineering**, with the exact
elements to check. The **Review tasks** tab in the panel lets the team mark each one Pass / Fail / Not applicable
(with notes). A Fail becomes an issue in the report; a Pass marks that criterion "Passed in review" in the checklist.
**Download review tasks** exports them; scheduled scans email the Design Team and Engineering Team their own task PDF.

## AI agents

Uses Chrome's built-in AI (Gemini Nano via the Prompt API) — free, on this computer, no API key, page content never
leaves the machine. Works like BrowserStack's two agents:

**Issue detection agent** — judges what rules can't (looking at a screenshot of the element where it helps):

| Judgement | WCAG | BrowserStack equivalent |
|---|---|---|
| Image description matches the image | 1.1.1 | image-alt quality |
| Image hidden as decoration actually carries information | 1.1.1 | decorative-image |
| Chart, diagram or map has no long description | 1.1.1 | missing-long-alt |
| Text acts as a heading but isn't marked up | 1.3.1 | missing-heading |
| Heading markup used for a sentence | 1.3.1 | incorrect-heading |
| Icon control's name doesn't say what it does | 4.1.2, 2.5.3 | accessible-name |
| Clickable element with no role or keyboard access (double-checks the rule; a confident pass removes the false alarm) | 2.1.1, 4.1.2 | keyboard-interactive, role-required |
| Link text, headings, labels, page title, sensory instructions, plain language | 2.4.4, 2.4.6, 2.4.2, 1.3.3 | link-purpose and others |

Confident failures become issues labelled AI-reviewed; unsure answers become Design/Engineering review tasks.

**Remediation agent** — every failing element gets a **Suggested fix** with code (panel, HTML report and PDFs, with
a *Copy fix* button). About 90 rules have a template fix that works with AI off; with AI on, the agent rewrites every
failing element using the page's real content, most serious first.

Needs desktop Chrome 138+ with about 22 GB free disk and 16 GB RAM or a GPU with more than 4 GB memory; turn it on in
Interaction settings. On other machines the judgement checks go to the review tasks and fixes come from templates.

## Project layout

```
extension/
  manifest.json        Extension definition (Manifest V3)
  background.js        Opens the side panel when the icon is clicked
  sidepanel.html/.css  The scanner UI
  sidepanel.js         Runs tests, presses keys, measures contrast, groups results, exports
  content/engine.js    Runs inside the page: all checks, keyboard walk and interaction tests, explore
  lib/axe.min.js       axe-core 4.11.4 (MPL-2.0, see lib/axe-LICENSE.txt)
  lib/wcag22.js        The 55 WCAG 2.2 A/AA criteria and how each status is decided
  lib/standards.js     Standard mapping, GIGW and consistent-help session checks
  lib/report.js        HTML report builder (includes the checklist)
  lib/runner.js        Shared test runner (panel and scheduler)
  lib/ai.js            Detection agent judgements (Chrome built-in AI)
  lib/remediate.js     Remediation agent: template and AI code fixes
  lib/review.js        Design / Engineering review tasks
  lib/reporting.js     Adherence, emails and PDFs for scheduled scans
  lib/scheduler.js     Projects, schedules, Gmail and Slack delivery
  lib/screenreader.js  Screen reader preview from the accessibility tree
  lib/acr.js           ACR / VPAT draft and Jira CSV
cli/
  a11y-scan.mjs        Command line / CI runner (drives the extension headlessly)
  accessibility.yml    GitHub Actions template
  icons/               Toolbar icons
```

## Next phases

1. **Website on Vercel (free)**: landing page, install guide, shared report viewer.
2. **Login and saved reports (Supabase free plan)**: email OTP sign-in.
3. **Report emails (Resend free plan)**.
4. **Scheduled scans for the team's own sites (GitHub Actions, free)**.
5. **Form testing**: submit forms empty and with wrongly formatted values to check error messages, then cancel without saving (3.3.1, 3.3.3).
